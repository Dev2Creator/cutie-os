import re
import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "tool_pride" in s:
    print("already patched ✓")
    sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label)
        print("  ✗", label)
        return
    s = s.replace(old, new, 1)
    print("  ✓", label)

def rx(pat, repl, label):
    global s
    s2, n = re.subn(pat, repl, s, count=1)
    if n == 0:
        fails.append(label)
        print("  ✗", label)
        return
    s = s2
    print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label)
        print("  ✗", label)
        return
    s = s[:a] + new + s[a:]
    print("  ✓", label)

rx(r'VERSION\s*=\s*"[^"]*"', 'VERSION      = "v3.3.0"', "version")
rx(r'EDITION\s*=\s*"[^"]*"', 'EDITION      = "PRIDE EDITION"', "edition")

rep('''    ("fw10", "Pyromaniac", "10 fireworks chalaye"),''',
    '''    ("fw10", "Pyromaniac", "10 fireworks chalaye"),
    ("pride", "Pride Soul", "pride mode on kiya"),
    ("hrt30", "Journey Keeper", "30 HRT logs"),
    ("dysncare", "Gentle Heart", "dysphoria din pe khud ko gentle rakha"),''',
    "pride achievements")

rep('''        self.fancy = None''', '''        self.fancy = None
        self.pridepage = None''', "pride init")

rep('''        if self.fancy:
            self.handle_fancy_event(ev)
            return''', '''        if self.pridepage:
            self.handle_pride_event(ev)
            return
        if self.fancy:
            self.handle_fancy_event(ev)
            return''', "pride routing")

rep('''        if self.fancy:
            cv.clear()
            return self.build_fancy_frame(t)''', '''        if self.pridepage:
            cv.clear()
            return self.build_pride_frame(t)
        if self.fancy:
            cv.clear()
            return self.build_fancy_frame(t)''', "pride frames")

rep('''    Tool("synthwave", ["synth", "retro"], "RETRO SUN + moving grid 🌆", "fun", tool_synthwave),''',
    '''    Tool("synthwave", ["synth", "retro"], "RETRO SUN + moving grid 🌆", "fun", tool_synthwave),
    Tool("pride", ["trans", "nb"], "🏳️‍⚧️ HRT tracker + affirm journal + pronouns", "life", tool_pride),''',
    "pride registry")

DATA = '''HRT_KINDS = {"e": "Estrogen", "t": "Testosterone", "b": "Blocker",
             "p": "Progesterone", "o": "Other"}


def _pr_load():
    return _jload("pride.json", {"hrt": [], "pronouns": "",
                                 "name": "", "journal": []})


def _pr_save(d3):
    _jsave("pride.json", d3)


AFFIRM = (
    "tera naam wahi hai jo TUNE chuna — aur wo perfect hai",
    "tera identity valid hai. hamesha thi, hamesha rahegi",
    "body ka journey apna hota hai — teri pace, tere rules",
    "tu jis me se guzri hai, wo himmat har din celebrate honi chahiye",
    "dysphoria jhooth bolti hai — mirror me jo hai wahi tu hai, aur kaafi hai",
    "community tere saath hai — tu akeli kabhi nahi",
    "jo bhi step liya (chhota ya bada) — wo courage tha",
    "tera past tera mission statement nahi hai — tera future tera hai",
    "khud ko dekh ke smile aana — wo moment aayega, ya aa chuka hai",
    "tum sirf survive nahi kar rahi — thrive kar rahi ho",
)


def tool_pride(app, args):
    T = app.term
    d3 = _pr_load()
    if args and args[0] == "hrt":
        if len(args) >= 2 and args[1].lower() in HRT_KINDS:
            d3["hrt"].append({"d": time.strftime("%Y-%m-%d"),
                              "k": args[1].lower()})
            d3["hrt"] = d3["hrt"][-120:]
            _pr_save(d3)
            if len(d3["hrt"]) >= 30:
                app.award("hrt30")
            T.push([("  💗 logged » ", C_DIM),
                    (HRT_KINDS[args[1].lower()] + " — " + time.strftime("%Y-%m-%d"),
                     C_VALUE)])
            T.dim("  journey har dose me ek din aage badhta hai 🏳️‍⚧️")
            return
        T.dim("  usage: pride hrt e|t|b|p|o   (E/T-blocker/Proge/Other)")
        return
    if args and args[0] == "pron" and len(args) >= 2:
        d3["pronouns"] = " ".join(args[1:])[:24]
        _pr_save(d3)
        T.push([("  💗 pronouns » ", C_DIM), (d3["pronouns"], C_GOLD)])
        return
    if args and args[0] == "name" and len(args) >= 2:
        d3["name"] = " ".join(args[1:])[:24]
        _pr_save(d3)
        T.push([("  💗 chosen name » ", C_DIM), (d3["name"], C_FUCHSIA),
                ("  (saari pride page pe yahi dikhega)", C_DIM)])
        return
    if args and args[0] == "affirm":
        T.push([("  ╭─", C_SLATE), (" 🏳️‍⚧️ ", C_CYAN), ("─" * 28, C_SLATE)])
        T.push([("  │ ", C_SLATE), (random.choice(AFFIRM), C_VALUE)])
        T.push([("  ╰", C_SLATE), ("─" * 34, C_SLATE), ("╯", C_SLATE)])
        app.add_xp(1)
        return
    if args and args[0] == "journal" and len(args) >= 2:
        d3["journal"].append({"d": time.strftime("%Y-%m-%d"),
                              "t": " ".join(args[1:])[:200]})
        _pr_save(d3)
        T.push([("  📖 journaled » ", C_DIM), ("har likha hua shabd halka karta hai", C_DIM)])
        return
    app.pridepage = {"tab": 0, "msg": "", "msg_t": 0.0, "open_t": time.monotonic()}


'''

block("def tool_music(app, args):", DATA, "pride tools")

DIV2 = "# ───────────────────────────── self check / main"
block(DIV2, '''    # ── v3.3.0: PRIDE PAGE ──

    def handle_pride_event(self, ev):
        kind, ch = ev[0], ev[1]
        cp = self.pridepage
        if kind == "EOF":
            self.running = False
            return
        if kind in ("CTRL_C", "CTRL_Q", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
            self.pridepage = None
            return
        if kind == "CHAR" and ch:
            low = ch.lower()
            d3 = _pr_load()
            td = time.strftime("%Y-%m-%d")
            if low == "h":
                d3["hrt"].append({"d": td, "k": "e"})
                d3["hrt"] = d3["hrt"][-120:]
                _pr_save(d3)
                if len(d3["hrt"]) >= 30:
                    self.award("hrt30")
                cp["msg"] = "💗 HRT logged — journey aage badhi"
                cp["msg_t"] = time.monotonic()
                self.add_xp(2)
            elif low == "a":
                cp["msg"] = random.choice(AFFIRM)
                cp["msg_t"] = time.monotonic()
                self.add_xp(1)
            elif low == "j":
                cp["msg"] = "jaldi: pride journal <baat> (panel me seedha jaldi likhna next update)"
                cp["msg_t"] = time.monotonic()
            elif low == "p":
                cp["msg"] = "pride mode: rainbow petal rain ON 🏳️‍🌈"
                cp["pride_on"] = True
                cp["msg_t"] = time.monotonic()
                self.award("pride")

    def build_pride_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        b = C_TERM_BORDER
        cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", b)
        cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", b)
        for yy in range(1, H - 1):
            cv.put(0, yy, "│", b)
            cv.put(W - 1, yy, "│", b)
        cp = self.pridepage
        pride_on = cp.get("pride_on", False)
        PCOLS = [(91, 33, 180), (224, 90, 160), (255, 255, 255), (140, 200, 255)]
        for k in range(10):
            px2 = (k * 83 + int(t * (5.0 + k * 0.5))) % (W + 8) - 4
            py2 = (k * 41 + int(t * (2.0 + k * 0.3))) % (H + 6) - 3
            xx = int(px2 + math.sin(t * 1.1 + k) * 2.0)
            yy = int(py2)
            if 1 <= yy < H - 2 and 2 <= xx < W - 3:
                col = PCOLS[k % 4] if pride_on else \
                    [(244, 114, 182), C_VIOLET, (140, 200, 255)][k % 3]
                cv.set(xx, yy, ["·", "✿", "✦", "*"][k % 4],
                       scale(col, 0.22 + 0.10 * math.sin(t + k)))
        title = "🏳️‍⚧️ CUTIE PRIDE 🏳️‍⚧️"
        cv.put(max(2, (W - disp_width(title)) // 2), 1, title,
               mix(C_CYAN, C_PINK, 0.5 + 0.4 * math.sin(t * 2.0)))
        d3 = _pr_load()
        nm = d3.get("name") or ""
        pr = d3.get("pronouns") or ""
        if nm:
            line2 = "✦ " + nm + ("  •  " + pr if pr else "")
            cv.put(max(2, (W - disp_width(line2)) // 2), 3, line2, C_FUCHSIA)
        else:
            line2 = "apna naam set karo — pride name <naam>"
            cv.put(max(2, (W - disp_width(line2)) // 2), 3, line2, C_DIM)
        hrt = d3["hrt"]
        cx2 = W // 2
        cv.put(cx2 - 12, 6, "◆ HRT JOURNEY", C_TITLE)
        if hrt:
            cnt = {}
            for e3 in hrt:
                cnt[e3["k"]] = cnt.get(e3["k"], 0) + 1
            ry2 = 8
            for k2, v2 in sorted(cnt.items(), key=lambda x: -x[1]):
                nm2 = HRT_KINDS.get(k2, k2)
                cv.put(cx2 - 12, ry2, nm2.ljust(13), C_LABEL)
                cv.put(cx2 + 2, ry2, "▓" * clamp(v2, 1, 20), C_PINK)
                cv.put(cx2 + 23, ry2, str(v2), C_VALUE)
                ry2 += 1
            lastd = hrt[-1]["d"]
            cv.put(cx2 - 12, ry2 + 1, "last dose: " + lastd, C_SLATE)
            cv.put(cx2 - 12, ry2 + 2, "total logs: " + str(len(hrt)), C_LABEL)
        else:
            cv.put(cx2 - 12, 8, "(abhi koi log nahi)", C_DIM)
            cv.put(cx2 - 12, 9, "pride hrt e  —  e/t/b/p/o", C_SLATE)
        mx2 = max(2, W - 34)
        cv.put(mx2, 6, "◆ AFFIRM", C_TITLE)
        af = random.choice(AFFIRM)
        cv.put(mx2, 8, "✿ " + af[:24], C_VALUE)
        cv.put(mx2, 9, "  " + af[24:48], C_VALUE)
        cv.put(mx2, 11, "◆ KEYS", C_FUCHSIA)
        cv.put(mx2, 12, "H = hrt dose log", C_LABEL)
        cv.put(mx2, 13, "A = affirmation", C_LABEL)
        cv.put(mx2, 14, "J = journal note", C_LABEL)
        cv.put(mx2, 15, "P = pride petals 🏳️‍🌈", C_LABEL)
        msg = cp.get("msg") or ""
        if msg and (time.monotonic() - cp.get("msg_t", 0)) < 6.0:
            cv.put(max(2, (W - disp_width(msg)) // 2), H - 5,
                   clip(msg, W - 6), C_GOLD)
        cv.put(3, H - 3, "( ^..^ )", C_PINK)
        cv.put(12, H - 3, "momo: tu yahan aane layak hai, isi liye banaya tha ♡", C_LABEL)
        cv.put(max(2, (W - 30) // 2), H - 2,
               "H hrt • A affirm • P pride • Q exit", C_SLATE)
        return cv.render()


''' + DIV2, "pride page methods")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v32")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v3.3.0 PRIDE patched ✓  (backup: %s.bak-v32)" % P)

