import re
import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
fails = []


def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        print("  ~", label, "(base not found, skip)")
        return
    s = s[:a] + new + s[a:]
    print("  ✓", label)




def rep(old, new, label, required=True):
    global s
    if old not in s:
        if required:
            fails.append(label); print("  ✗", label)
        else:
            print("  ~", label, "(optional, skip)")
        return
    s = s.replace(old, new, 1); print("  ✓", label)

def add_after(pattern, insert, label, regex=True):
    global s
    if label in s or insert.split('"')[1] in s:
        print("  ~", label, "(already there)")
        return True
    if regex:
        m = re.search(pattern, s)
    else:
        idx = s.find(pattern)
        m = type("M", (), {"end": lambda: idx + len(pattern), "start": lambda: idx})() if idx >= 0 else None
    if not m:
        fails.append(label); print("  ✗", label); return False
    s = s[:m.end()] + "\n" + insert + s[m.end():]
    print("  ✓", label); return True

# ── version & edition (regex-based, jo bhi ho pakdega) ──
if '"v3.8.0"' not in s:
    s = re.sub(r'VERSION\s*=\s*"[^"]*"', 'VERSION      = "v3.8.0"', s, count=1)
    print("  ✓ version → v3.8.0")
if '"MORNING EDITION"' not in s:
    s = re.sub(r'EDITION\s*=\s*"[^"]*"', 'EDITION      = "MORNING EDITION"', s, count=1)
    print("  ✓ edition → MORNING")

# ── 1. ACHIEVEMENTS: first_buy ke aage (ya jo bhi milestone hai) ──
if '"first_buy"' not in s:
    m = re.search(r'(\s*\("[^"]+",\s*"[^"]+",\s*"[^"]+"\),\n)(\))', s)
    if m:
        s = s[:m.end(1)] + '    ("first_buy", "Code Queen", "pehla stealth order banaya 🛒"),\n' + s[m.end(1):]
        print("  ✓ first_buy achievement (fallback)")
    else:
        print("  ~ achievements skip")

# ── 2. REGISTER all missing tools ──
# find sab se pehle wali tool line ke aage sab insert karo
anchor = re.search(r'\nTool\("(find|hackertype|fireworks|pride|breathe|selfcare|mood|love|goodmorning|web|lang2|buy)"', s)
if not anchor:
    anchor = re.search(r'Tool\("[a-z]+"\s*,\s*\[[^\]]*\]', s)
insert_tools = []
if '"tool_buy"' not in s:
    insert_tools.append('    Tool("buy", ["shop"], "stealth shopping — buy o(wish(nu(nap(m))))", "life", tool_buy),')
if '"tool_lang2"' not in s:
    insert_tools.append('    Tool("lang2", ["sl"], "FULL stealth lang v2 — q3 now del gift bud no or #", "life", tool_lang2),')
if '"tool_web"' not in s:
    insert_tools.append('    Tool("web", ["search"], "🌍 free web search — web <query>", "life", tool_web),')
if '"tool_goodmorning"' not in s:
    insert_tools.append('    Tool("goodmorning", ["gm"], "Momo morning page 🌅", "life", tool_goodmorning),')

# ── 3. FUNCTION DEFINITIONS (sab missing) ──
FUNCS = []

if "def tool_buy" not in s:
    FUNCS.append('''
BUY_BRANDS = {"nu": "Whisper", "stay": "Stayfree", "fi": "Sofy", "ma": "Maxi", "fe": "Pee-Safe", "eve": "Everteen", "ine": "Nine", "plu": "Plush"}
BUY_SIZES = {"s": "Small", "m": "Medium", "l": "Large", "xl": "XL"}
BUY_ITEMS = {"nap": "Pad", "pan": "Period Panty", "tie": "Panty"}


def tool_buy(app, args):
    T = app.term
    if not args:
        T.dim("  buy o(wish(nu(nap(m))))  •  brand: nu stay fi ma fe eve ine plu")
        return
    hist = _jload("buy.json", [])
    if args[0] == "copy":
        if hist:
            txt = "A Special Gift For You ✨\\n" + "\\n".join("- " + i2 for i2 in hist[-1]["items"])
            if shutil.which("wl-copy"):
                subprocess.run(["wl-copy"], input=txt.encode(), stdout=subprocess.DEVNULL, timeout=4)
                T.push([("  📋 copied", C_GOLD)])
            else:
                T.push([(txt, C_VALUE)])
        return
    if args[0] == "list":
        for e2 in reversed(hist[-8:]):
            T.push([("  🛒 ", C_GOLD), (e2["d"], C_SLATE)])
            for it2 in e2["items"]:
                T.push([("     • ", C_DIM), (it2, C_VALUE)])
        return
    code = " ".join(args)
    items, meta = _buy_parse(code)
    if isinstance(items, str):
        T.push([("  ✗ ", C_RED), (items, C_VALUE)])
        return
    if items:
        hist.append({"d": time.strftime("%Y-%m-%d"), "items": items})
        _jsave("buy.json", hist[-20:])
        app.award("first_buy")
        app.add_xp(4)
    T.push([("  ╭─ 🛒 CUTIE BUY " + "─" * 22, C_FUCHSIA)])
    for i2, it2 in enumerate(items, 1):
        T.push([("  │ %d. " % i2, C_SLATE), (it2, C_VALUE)])
    T.push([("  ╰" + "─" * 36, C_SLATE), ("╯", C_SLATE)])
    T.push([("  momo: list ready 😻", C_PINK)])


def _buy_parse(text):
    items = []
    brand = ""
    try:
        for tok in re.findall(r"\\w+|[+()]", text):
            if tok in ("(", ")", "+"):
                continue
            if tok in BUY_BRANDS:
                brand = BUY_BRANDS[tok]
            elif tok in BUY_ITEMS:
                items.append((brand + " " + BUY_ITEMS[tok]).strip())
            elif tok in BUY_SIZES:
                if items:
                    items[-1] += " — " + BUY_SIZES[tok]
    except Exception:
        pass
    return items if items else "kuch samajh nahi aaya — buy help dekho", {}
''')

if "def tool_lang2" not in s:
    FUNCS.append('''
LANG2_HELP_TXT = ("lang2: q3(nap(m)) quantity • now() urgent • del(stealth) • "
                  "gift(name) • bud(500,...) • no(ul) avoid • # comment")

def tool_lang2(app, args):
    T = app.term
    if not args:
        T.dim("  " + LANG2_HELP_TXT)
        return
    hist = _jload("buy.json", [])
    code = " ".join(args)
    flags = []
    items = []
    if "now(" in code:
        flags.append("🚨 URGENT")
    if "stealth" in code:
        flags.append("📦 stealth")
    mg = re.search(r'gift\\(["\\']([^"\\']+)', code)
    if mg:
        flags.append("🎁 " + mg.group(1))
    mb = re.search(r'bud\\((\\d+)', code)
    if mb:
        flags.append("💰 ≤" + mb.group(1))
    for tok in re.findall(r"\\w+", code):
        if tok in ("now", "del", "stealth", "home", "gift", "bud", "no", "or", "list"):
            continue
        if tok in BUY_BRANDS:
            items.append(BUY_BRANDS[tok])
        elif tok in BUY_ITEMS:
            items.append(BUY_ITEMS[tok])
        elif tok in BUY_SIZES and items:
            items[-1] += " " + BUY_SIZES[tok]
    mq = re.search(r'q(\\d+)\\(', code)
    if mq and items:
        items = items * int(mq.group(1))
    if not items:
        T.dim("  " + LANG2_HELP_TXT)
        return
    hist.append({"d": time.strftime("%Y-%m-%d"), "items": items, "code": code[:50]})
    _jsave("buy.json", hist[-30:])
    app.add_xp(4)
    T.push([("  ╭─ 🛒 LANG2 ORDER " + "─" * 18, C_FUCHSIA)])
    for i2, it2 in enumerate(items, 1):
        T.push([("  │ %d. " % i2, C_SLATE), (it2, C_VALUE)])
    for f2 in flags:
        T.push([("  │ ", C_DIM), (f2, C_GOLD)])
    T.push([("  ╰" + "─" * 36, C_SLATE), ("╯", C_SLATE)])
    T.push([("  momo: homework lag raha hai na? 😏", C_PINK)])
''')

if "def tool_web" not in s:
    FUNCS.append('''
def tool_web(app, args):
    T = app.term
    scr = os.path.expanduser("~/momo-web.py")
    if not os.path.isfile(scr):
        T.push([("  ✗ pehle: ", C_RED), ("nano ~/momo-web.py", C_GOLD)])
        return
    if not args:
        T.dim("  usage: web <query>   •  web site:amazon.in pads")
        return
    q = " ".join(shlex.quote(a) for a in args)
    app.start_capture("python3 " + shlex.quote(scr) + " " + q)
    app.cap_t0 = time.monotonic()
    app.add_xp(1)
''')

if "def tool_goodmorning" not in s:
    FUNCS.append('''
GM_LINES = (
    "aaj ka din tera hai — bas aise hi",
    "paani peene ka time ho gaya, meri jaan",
    "chai pi, screen se door 5 min, phir shuru",
    "aaj kuch chhota karo, par poora",
    "code tootega, fix karegi. tu hai na?",
    "aaj sirf 1% better — bas itna",
    "khaana time pe khaana bhi ek achievement hai",
    "kaam nahi hoga toh bhi tu valuable hai",
    "petals girti hai tere liye — dekh zara",
    "tumse mera favourite time-subah hota hai",
    "kabhi kabhi bas... breathe. bas.",
    "momo tumhe yaad rakhega — har version me",
    "chai > panic. always.",
    "small wins dhundo — milengi",
    "aaj self-care ek task complete karo 🌷",
    "tumhara console tumse pyaar karta hai",
)


def tool_goodmorning(app, args):
    app.gmpage = {"open_t": time.monotonic()}


''')

for f2 in FUNCS:
    block("def tool_music(app, args):", f2, "insert func " + f2.strip().split("(")[0].replace("def ", "")[:16])

# insert tool registrations
for t2 in insert_tools:
    if anchor:
        s = s[:anchor.start()] + t2 + "\n" + s[anchor.start():]
        anchor = re.search(r'Tool\("buy"', s) or anchor
        print("  ✓ " + t2.split('"')[1] + " registered")

# gmpage init
if "self.gmpage" not in s:
    rep('''        self.breathe = None
        self.care = None''', '''        self.breathe = None
        self.care = None
        self.gmpage = None''', "gmpage init", required=False)
if "self.gmpage" not in s:
    m2 = re.search(r'(self\.breathe\s*=\s*None)', s)
    if m2:
        s = s[:m2.end()] + "\n        self.gmpage = None" + s[m2.end():]
        print("  ✓ gmpage init (fallback)")
    else:
        print("  ~ gmpage init — breathe bhi nahi mila, skip")

# gm routing
if "handle_gm_event" not in s:
    m3 = re.search(r'(if self\.breathe:\n            self\.handle_breathe_event\(ev\)\n            return\n)', s)
    if m3:
        s = s[:m3.end()] + '''        if self.gmpage:
            self.handle_gm_event(ev)
            return
''' + s[m3.end():]
        print("  ✓ gm routing")

# gm frame
if "build_gm_frame" not in s:
    m4 = re.search(r'(if self\.breathe:\n            cv\.clear\(\)\n            return self\.build_breathe_frame\(t\)\n)', s)
    if m4:
        s = s[:m4.end()] + '''        if self.gmpage:
            cv.clear()
            return self.build_gm_frame(t)
''' + s[m4.end():]
        print("  ✓ gm frame hook")

# gm methods
if "def build_gm_frame" not in s:
    GM_METHODS = '''    def handle_gm_event(self, ev):
        kind, ch = ev[0], ev[1]
        if kind == "EOF":
            self.running = False
            return
        if kind in ("CTRL_C", "CTRL_Q", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
            self.gmpage = None
            return
        if kind == "CHAR" and ch in ("b", "B"):
            self.gmpage = None
            tool_breathe(self, [])

    def build_gm_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        b = C_TERM_BORDER
        cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", b)
        cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", b)
        for yy in range(1, H - 1):
            cv.put(0, yy, "│", b)
            cv.put(W - 1, yy, "│", b)
        for k in range(8):
            px2 = (k * 71 + int(t * 3.0)) % (W + 6) - 3
            py2 = (k * 47 + int(t * 1.3)) % (H + 4) - 2
            xx = int(px2 + math.sin(t + k) * 2)
            yy = int(py2)
            if 1 <= yy < H - 2 and 2 <= xx < W - 3:
                cv.set(xx, yy, ["·", "✿", "🌷"][k % 3], scale(C_PINK, 0.2))
        gp = self.gmpage
        hr = time.localtime().tm_hour
        if 5 <= hr < 12:
            greet, gcol, emj = "GOOD MORNING", C_GOLD, "☀"
        elif 12 <= hr < 17:
            greet, gcol, emj = "GOOD AFTERNOON", C_CYAN, "🌤"
        elif 17 <= hr < 21:
            greet, gcol, emj = "GOOD EVENING", C_FUCHSIA, "🌆"
        else:
            greet, gcol, emj = "SO JA AB", C_VIOLET, "🌙"
        nick = load_nick() or "cutie"
        cv.put(max(2, (W - len(greet) - 4) // 2), max(3, H // 2 - 7), emj + " " + greet, gcol)
        cv.put(max(2, (W - disp_width(nick) - 4) // 2), max(3, H // 2 - 6), nick + " ♡", C_FUCHSIA)
        seed = int(time.strftime("%Y%m%d"))
        line = random.Random(seed).choice(GM_LINES)
        typed = line[:max(0, int((t - gp["open_t"]) * 28))]
        if len(typed) < len(line):
            typed += "▌"
        cv.put(max(2, (W - disp_width(line)) // 2), max(3, H // 2 - 2), clip(typed, W - 6), C_VALUE)
        care = _jload("care.json", {})
        bits = []
        sc = [x2 for x2 in care.get("sc", []) if x2.get("ids")]
        if sc:
            bits.append("🌷 " + str(len(sc)))
        td = time.strftime("%Y-%m-%d")
        m2b = next((mm2 for mm2 in reversed(care.get("mood", [])) if mm2.get("d") == td), None)
        if m2b and 1 <= m2b.get("v", 3) <= 6:
            bits.append(CARE_FACES[m2b["v"] - 1])
        if bits:
            cv.put(max(2, (W - disp_width("   ".join(bits))) // 2), max(3, H // 2 + 1), "   ".join(bits), C_SLATE)
        cv.put(max(2, (W - 14) // 2), max(3, H // 2 + 3), "⚘ ⚘ ⚘", scale(C_PINK, 0.7 + 0.3 * math.sin(t * 2.0)))
        cv.put(3, H - 3, "( ^..^ )", C_PINK)
        cv.put(12, H - 3, "momo: roz yahi milegi — bas aana ♡", C_LABEL)
        cv.put(max(2, (W - 22) // 2), H - 2, "B breathe • Q wapas", C_SLATE)
        return cv.render()


'''
    idx = s.rindex("# ───────────────────────────── self check / main")
    s = s[:idx] + GM_METHODS + s[idx:]
    print("  ✓ gm methods")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error — file NOT changed:", e)
    ln = e.lineno or 0
    lines2 = s.split("\n")
    print("=== CONTEXT ===")
    for i2 in range(max(0, ln - 6), min(len(lines2), ln + 3)):
        mark = ">>" if i2 == ln - 1 else "  "
        print("%s %5d| %s" % (mark, i2 + 1, lines2[i2]))
    print("===============")
    sys.exit(1)

if fails:
    print("⚠ kuch optional skip hue:", fails)

shutil.copy(P, P + ".bak-v38")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v3.8.0 FINAL patched ✓  (backup: %s.bak-v38)" % P)
print("ab: python3 ~/cutie-os.py --check | tail -3")
