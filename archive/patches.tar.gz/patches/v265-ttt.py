import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "tool_ttt" in s:
    print("already patched ✓"); sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[a:]; print("  ✓", label)

rep('VERSION      = "v26"', 'VERSION      = "v26.5"', "version")
rep('EDITION      = "PLAY EDITION"', 'EDITION      = "ARCADE EDITION"', "edition")

rep('''    ("n2048", "2048 Unlocked", "2048 tile bana diya"),
)''', '''    ("n2048", "2048 Unlocked", "2048 tile bana diya"),
    ("ttt_l3", "Level 3 Clear", "tic-tac-toe L3 jeeta"),
    ("ttt_l6", "Impossible Slayer", "L6 Momo ko draw tak bhi nahi aane diya... "
     "(ya jeet gayi?!)"),
    ("ttt_win5", "X Master", "tic-tac-toe 5 jeet"),
)''', "ttt achievements")

rep('''    Tool("2048", ["g2048"], "2048 — arrows merge, best score", "fun", tool_2048),''',
    '''    Tool("2048", ["g2048"], "2048 — arrows merge, best score", "fun", tool_2048),
    Tool("ttt", ["tictactoe"], "3D BLOCK tic-tac-toe vs Momo — 6 levels!", "fun", tool_ttt),''',
    "ttt registry")

DATA = '''TTT_3D = {
    "X": ("███████╗", "██╔════╝", "██║  ██╗", "║  ██║", "╚█████╔╝", " ╚════╝"),
    "O": (" ██████╗ ", "██╔═══██╗", "██║   ██║", "██║   ██║", "╚██████╔╝", " ╚═════╝ "),
    " ": ("        ", "        ", "        ", "        ", "        ", "        "),
}
_TTT_L_NAMES = ("Seedhi Bacchi", "Chhoti Bacchi", "School Champion",
                "Bhavishya Darshi", "Chess Master", "IMPOSSIBLE")
_TTT_L_DEPTH = (1, 2, 4, 6, 8, 20)
_TTT_TAUNTS = (
    ("hehe yeh toh aasaan hai 😼", "dhyaan se khelo!", "=^.^= zzz…",
     "Momo so rahi thi, ab jaagi"),
    ("achha chal raha hai…", "sochne de mujhe 🤔", "hmm interesting",
     "abhi toh warmup hai"),
    ("not bad not bad 😼", "ab ghabra mat", "plan B nikalo",
     "dekho aur seekho"),
    ("strong move 🔥", "main bhi soch rahi hoon", "trap dekha maine",
     "attack best defence hai"),
    ("ooh dhang se khel rahi ho", "mere neurons jal rahe ⚡",
     "ab atka tum", "grandmaster vibes"),
    ("IMPOSSIBLE mode: thoda mushkil hoga 😼",
     "main jeetungi, bas time ki baat", "sos: udd raha hai",
     "tumhara confidence dekho!"),
)


def _ttt_winner(bd):
    wins = ((0, 1, 2), (3, 4, 5), (6, 7, 8),
            (0, 3, 6), (1, 4, 7), (2, 5, 8),
            (0, 4, 8), (2, 4, 6))
    for a, b, c2 in wins:
        if bd[a] != " " and bd[a] == bd[b] == bd[c2]:
            return bd[a], (a, b, c2)
    if all(x != " " for x in bd):
        return "draw", None
    return None, None


def _ttt_minimax(bd, turn, depth, lvl, me, opp, alpha, beta):
    w, _l = _ttt_winner(bd)
    if w == me:
        return 10 - depth, None
    if w == opp:
        return depth - 10, None
    if w == "draw":
        return 0, None
    best = (-99, None) if turn == me else (99, None)
    for i in range(9):
        if bd[i] != " ":
            continue
        bd[i] = turn
        sc, _m = _ttt_minimax(bd, opp, depth + 1, lvl, me, opp, alpha, beta)
        bd[i] = " "
        if turn == me:
            if sc > best[0]:
                best = (sc, i)
            alpha = max(alpha, sc)
        else:
            if sc < best[0]:
                best = (sc, i)
            beta = min(beta, sc)
        if beta <= alpha:
            break
    return best


def _ttt_momo_pick(bd, lvl, me, opp):
    empty = [i for i in range(9) if bd[i] == " "]
    if not empty:
        return None
    depth = _TTT_L_DEPTH[min(lvl, 5)]
    if depth <= 2:
        if random.random() < 0.65:
            return random.choice(empty)
    elif depth <= 4:
        if random.random() < 0.30:
            return random.choice(empty)
    elif depth <= 6:
        if random.random() < 0.12:
            return random.choice(empty)
    _sc, mv = _ttt_minimax(list(bd), me, 0, lvl, me, opp, -99, 99)
    return mv if mv is not None else random.choice(empty)


def _ttt_paint(cv, x0, y0, bd, win_line, t):
    for cell_i in range(9):
        r, c2 = divmod(cell_i, 3)
        ox = x0 + c2 * 10
        oy = y0 + r * 7
        mark = bd[cell_i]
        glyph = TTT_3D.get(mark, TTT_3D[" "])
        flash = False
        if win_line and cell_i in win_line:
            flash = True
        for ry, line in enumerate(glyph):
            for i, ch in enumerate(line):
                if ch == " ":
                    continue
                if flash:
                    cc = grad((cell_i / 8.0 + 0.4 * math.sin(t * 6.0)) % 1.0)
                elif mark == "X":
                    cc = grad(0.15 + (r + c2) * 0.04)
                else:
                    cc = scale(C_CYAN, 0.85 + 0.15 * math.sin(t * 2.0 + cell_i))
                cv.set(ox + i, oy + ry, ch, cc)
    for k in (1, 2):
        vx = x0 + k * 10 - 1
        for yy in range(y0, y0 + 21):
            cv.set(vx, yy, "│", scale(C_SLATE, 0.55))
    for k in (1, 2):
        vy = y0 + k * 7 - 1
        for xx in range(x0, x0 + 29):
            cv.set(xx, vy, "─", scale(C_SLATE, 0.55))


def tool_ttt(app, args):
    T = app.term
    lvl = 2
    if args and args[0].isdigit():
        lvl = clamp(int(args[0]), 1, 6) - 1
    stats = load_profile().get("ttt_stats") or {"w": 0, "l": 0, "d": 0}
    wins = stats.get("w", 0)
    app.suspend_hud()
    result_note = None
    try:
        enter_raw(app.fd)
        app.keys.pend = b""
        W, H = app.size()
        out = app.out
        out.write(ALT_ON + CUR_HIDE)
        out.flush()
        me, opp = "X", "O"
        bd = [" "] * 9
        turn = me
        over = False
        win_line = None
        res = None
        quitf = False
        msg = "❯ tumhara move (1-9) • L level badlo • Q quit"
        taunt_i = 0
        taunt = _TTT_TAUNTS[lvl][0]
        taunt_t = 0.0
        last_momo = 0.0
        cv = Canvas(W, H)
        gx0 = max(3, (W - 30) // 2 - 6)
        gy0 = max(3, (H - 24) // 2)

        def render(t2):
            cv.clear()
            bcol = C_TERM_BORDER
            cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", bcol)
            cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", bcol)
            for yy in range(1, H - 1):
                cv.put(0, yy, "│", bcol)
                cv.put(W - 1, yy, "│", bcol)
            cv.put(2, 1, "✿ TIC TAC TOE", C_TITLE)
            cv.put(17, 1, "— LVL %d: %s" % (lvl + 1, _TTT_L_NAMES[lvl]),
                   C_GOLD if lvl == 5 else C_LABEL)
            put_segs(cv, W - 2 - 24, 1,
                     [("✗ %d " % stats.get("w", 0), C_GOLD),
                      ("◉ %d " % stats.get("d", 0), C_SLATE),
                      ("○ %d" % stats.get("l", 0), C_RED)])
            _ttt_paint(cv, gx0, gy0, bd, win_line, t2)
            n = 0
            for i in range(9):
                if bd[i] == " ":
                    n += 1
                    r, c2 = divmod(i, 3)
                    hint = str(i + 1)
                    cv.put(gx0 + c2 * 10 + 3, gy0 + r * 7 + 5, hint,
                           scale(C_SLATE, 0.55))
            put_segs(cv, gx0, gy0 + 22,
                     [("MOMO ", C_LABEL), ("◉ O", C_CYAN),
                      ("   tum ", C_LABEL), ("✗ X", C_GOLD),
                      ("   khaali: %d" % n, C_SLATE)])
            cv.put(gx0, gy0 + 23, clip(taunt, max(10, W - gx0 - 6)),
                   C_PINK if (t2 % 1.0) < 0.85 else C_WHITE)
            cv.put(gx0, gy0 + 25, clip(msg, max(10, W - gx0 - 6)),
                   C_VALUE if not over else C_GOLD)
            if over:
                box = res or "—"
                bw2 = disp_width(box) + 8
                bx2 = max(2, (W - bw2) // 2)
                by2 = max(4, H // 2 + 10)
                cv.put(bx2, by2, "╭" + "─" * (bw2 - 2) + "╮", C_FUCHSIA)
                cv.put(bx2, by2 + 2, "╰" + "─" * (bw2 - 2) + "╯", C_FUCHSIA)
                cv.put(bx2, by2 + 1, "│  ", C_FUCHSIA)
                cv.put(bx2 + bw2 - 3, by2 + 1, "│", C_FUCHSIA)
                cv.put(bx2 + 3, by2 + 1, box, C_GOLD if "jeet" in box.lower() else
                       (C_CYAN if "draw" in box.lower() else C_RED))
            try:
                out.write(HOME + cv.render())
                out.flush()
            except Exception:
                pass

        def finish(winner, line):
            nonlocal over, res, win_line, msg, taunt
            over = True
            win_line = line
            if winner == me:
                stats["w"] = stats.get("w", 0) + 1
                res = "✦ TUM JEET GAYI! ✦"
                msg = "ENTER = phir se • Q quit"
                app.add_xp(6)
                app.award("ttt_win5") if stats["w"] >= 5 else None
                if lvl >= 2:
                    app.award("ttt_l3")
                if lvl == 5:
                    app.award("ttt_l6")
                app.confetti_until = time.monotonic() + 3.5
                cols = list(GRAD_STOPS) + [C_GOLD, C_WHITE]
                app.confetti = [{"x": random.uniform(0, W), "y": random.uniform(-24, 0),
                                 "vy": random.uniform(10, 26),
                                 "c": random.choice(cols),
                                 "ch": random.choice("✦*·+•")} for _ in range(70)]
                taunt = "nyaa?! kaise?! 😿"
            elif winner == opp:
                stats["l"] = stats.get("l", 0) + 1
                res = "MOMO JEET GAYI 😼"
                msg = "ENTER = revenge • Q quit"
                taunt = "hehehe 😼😌"
            else:
                stats["d"] = stats.get("d", 0) + 1
                res = "DRAW — dono solid!"
                msg = "ENTER = phir se • Q quit"
                taunt = "theek hai… barabari 🤝"
            save_profile_field("ttt_stats", stats)

        def momo_turn():
            nonlocal last_momo, taunt_i
            mv = _ttt_momo_pick(bd, lvl, opp, me)
            if mv is not None:
                bd[mv] = opp
            taunt_i = (taunt_i + 1) % len(_TTT_TAUNTS[lvl])
            taunt = _TTT_TAUNTS[lvl][taunt_i]
            w, ln = _ttt_winner(bd)
            if w:
                finish(w, ln)
            last_momo = time.monotonic()

        render(time.monotonic())
        while not quitf:
            now = time.monotonic()
            for ev in app.keys.poll(0.03):
                kind, ch = ev[0], ev[1]
                if kind == "EOF":
                    quitf = True
                elif kind in ("CTRL_C", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
                    quitf = True
                elif over and kind == "ENTER":
                    bd = [" "] * 9
                    over = False
                    win_line = None
                    res = None
                    turn = me
                    taunt = "naya round! 😼"
                    msg = "❯ tumhara move (1-9)"
                    last_momo = 0.0
                elif over:
                    continue
                elif kind == "CHAR" and ch and ch.isdigit() and ch != "0":
                    i = int(ch) - 1
                    if bd[i] != " ":
                        msg = "✗ wo cell bhara hai!"
                        taunt_t = now
                        continue
                    bd[i] = me
                    msg = "❯ Momo soch rahi hai…"
                    render(now)
                    time.sleep(0.18 + random.random() * 0.25)
                    w, ln = _ttt_winner(bd)
                    if w:
                        finish(w, ln)
                    elif not all(x != " " for x in bd):
                        momo_turn()
                        msg = "❯ tumhara move (1-9) • L level • Q quit"
                elif kind == "CHAR" and ch in ("l", "L"):
                    lvl = (lvl + 1) % 6
                    taunt = _TTT_TAUNTS[lvl][0]
                    msg = "→ LVL %d: %s" % (lvl + 1, _TTT_L_NAMES[lvl])
            render(now)
            time.sleep(0.005)
    finally:
        app.resume_hud()
    T.push([("  ⭕ tic-tac-toe » ", C_DIM),
            ("✗ %d  ◉ %d  ○ %d" % (stats.get("w", 0), stats.get("d", 0),
                                   stats.get("l", 0)), C_VALUE),
            ("  •  LVL %d" % (lvl + 1), C_SLATE)])


'''

block("def tool_music(app, args):", DATA, "ttt engine")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v26")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v26.5 TTT patched ✓  (backup: %s.bak-v26)" % P)
