import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "SHINE_BAND" in s:
    print("already applied ✓")
    sys.exit(0)

NEW = '''def _ttt_paint(cv, x0, y0, bd, win_line, t, last_move):  # SHINE_BAND
    CW, CH = 11, 8
    fw, fh = 3 * CW, 3 * CH
    dim = scale(C_SLATE, 0.55)
    for cell_i in range(9):
        r, c2 = divmod(cell_i, 3)
        ox = x0 + c2 * CW
        oy = y0 + r * CH
        tint = 0.05 + 0.02 * math.sin(t * 1.3 + cell_i * 0.9)
        if win_line and cell_i in win_line:
            tint = 0.13 + 0.06 * math.sin(t * 5.0)
        col = scale(grad((r * 3 + c2) / 8.0), tint)
        for j in range(1, CH - 1):
            for i in range(1, CW):
                cv.set(ox + i, oy + j, "░", col)
    for i in range(fw):
        col = scale(grad(i / max(1, fw - 1)), 0.95)
        cv.set(x0 + i, y0 - 1, "─", col)
        cv.set(x0 + i, y0 + fh, "─", col)
    for j in range(fh):
        col = scale(grad(j / max(1, fh - 1)), 0.95)
        cv.set(x0 - 1, y0 + j, "│", col)
        cv.set(x0 + fw, y0 + j, "│", col)
    cv.set(x0 - 1, y0 - 1, "╭", scale(grad(0.0), 0.95))
    cv.set(x0 + fw, y0 - 1, "╮", scale(grad(0.5), 0.95))
    cv.set(x0 - 1, y0 + fh, "╰", scale(grad(0.5), 0.95))
    cv.set(x0 + fw, y0 + fh, "╯", scale(grad(1.0), 0.95))
    for k in (1, 2):
        gx2 = x0 + k * CW
        cv.set(gx2, y0 - 1, "┬", dim)
        cv.set(gx2, y0 + fh, "┴", dim)
        for j in range(fh):
            cv.set(gx2, y0 + j, "│", dim)
        gy2 = y0 + k * CH
        cv.set(x0 - 1, gy2, "├", dim)
        cv.set(x0 + fw, gy2, "┤", dim)
        for i in range(fw):
            cv.set(x0 + i, gy2, "─", dim)
        for k2 in (1, 2):
            cv.set(x0 + k2 * CW, gy2, "┼", dim)
    shine_pos = (t * 14.0) % (CW + CH + 6) - 3
    if win_line:
        for cell_i in win_line:
            r, c2 = divmod(cell_i, 3)
            px2 = x0 + c2 * CW + CW // 2
            py2 = y0 + r * CH + CH // 2
            ph = (t * 1.4 + cell_i * 0.33) % 1.0
            rr = 2 + ph * 3.0
            for ang in range(12):
                a2 = ang / 12.0 * 6.283
                sx2 = int(px2 + math.cos(a2) * rr)
                sy2 = int(py2 + math.sin(a2) * rr * 0.55)
                cv.set(sx2, sy2, "·", scale(C_GOLD, 0.9 - ph * 0.5))
    for cell_i in range(9):
        r, c2 = divmod(cell_i, 3)
        ox = x0 + c2 * CW + 1
        oy = y0 + r * CH + 1
        mark = bd[cell_i]
        glyph = TTT_3D.get(mark, TTT_3D[" "])
        is_win = bool(win_line and cell_i in win_line)
        is_last = (cell_i == last_move) and not win_line
        if mark == " ":
            sh = 0.45 + 0.22 * math.sin(t * 2.0 + cell_i * 1.3)
            cv.put(ox + CW - 4, oy + CH - 2, str(cell_i + 1), scale(C_SLATE, sh))
            continue
        if mark == "X":
            base = mix(C_GOLD, C_PINK, (r * 3 + c2) / 8.0)
        else:
            base = mix(C_CYAN, C_VIOLET, (r * 3 + c2) / 8.0)
        faded = bool(win_line) and not is_win
        body = scale(base, 0.45) if faded else base
        for ry, line in enumerate(glyph):
            for i, ch in enumerate(line):
                if ch != " ":
                    cv.set(ox + i + 1, oy + ry + 1, ch, scale(body, 0.22))
        for ry, line in enumerate(glyph):
            for i, ch in enumerate(line):
                if ch == " ":
                    continue
                if faded:
                    cc = body
                else:
                    d = abs((i + ry * 1.5) - shine_pos)
                    gl = 0.55 * max(0.0, 1.0 - d / 3.0)
                    if is_win:
                        pulse = 0.65 + 0.35 * math.sin(t * 6.0 + cell_i)
                        cc = mix(base, C_WHITE, min(1.0, pulse * 0.75 + gl))
                    elif is_last:
                        cc = mix(base, C_WHITE,
                                 min(1.0, 0.30 + 0.22 * math.sin(t * 5.0) + gl))
                    else:
                        cc = mix(base, C_WHITE, gl)
                cv.set(ox + i, oy + ry, ch, cc)
    if win_line:
        a, b, c3 = win_line
        if b == a + 1 and c3 == a + 2:
            yy = y0 + (a // 3) * CH + CH // 2
            for k in range(fw - 1):
                if (k + int(t * 12)) % 4 == 0:
                    cv.set(x0 + 1 + k, yy, "·", C_GOLD)
        elif b == a + 3 and c3 == a + 6:
            xx = x0 + (a % 3) * CW + CW // 2
            for k in range(fh - 1):
                if (k + int(t * 12)) % 4 == 0:
                    cv.set(xx, y0 + 1 + k, "·", C_GOLD)
        else:
            for k in range(1, fw - 1):
                if (k + int(t * 12)) % 4 == 0:
                    if a == 0:
                        yy = y0 + int(k / (fw - 1.0) * (fh - 1))
                    else:
                        yy = y0 + (fh - 1) - int(k / (fw - 1.0) * (fh - 1))
                    cv.set(x0 + k, yy, "·", C_GOLD)


'''

a = s.index("def _ttt_paint")
b = s.index("def tool_ttt", a)
s = s[:a] + NEW + s[b:]

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error — file NOT changed:", e)
    sys.exit(1)

shutil.copy(P, P + ".bak-v27")
open(P, "w", encoding="utf-8").write(s)
print("★ shine paint installed ✓ (backup: cutie-os.py.bak-v27)")
