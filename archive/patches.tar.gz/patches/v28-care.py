import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "tool_period" in s:
    print("already patched ✓")
    sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label)
        print("  ✗", label)
        return
    s = s.replace(old, new, 1)
    print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label)
        print("  ✗", label)
        return
    s = s[:a] + new + s[a:]
    print("  ✓", label)

rep('VERSION      = "v26.5"', 'VERSION      = "v27.5"', "version")
rep('EDITION      = "ARCADE EDITION"', 'EDITION      = "CARE EDITION"', "edition")

rep('''    Tool("ttt", ["tictactoe"], "3D BLOCK tic-tac-toe vs Momo — 6 levels!", "fun", tool_ttt),''',
    '''    Tool("ttt", ["tictactoe"], "3D BLOCK tic-tac-toe vs Momo — 6 levels!", "fun", tool_ttt),
    Tool("period", ["cycle"], "cycle tracker — start/end/log/predict (local only)", "life", tool_period),
    Tool("cal", ["calendar"], "CUTIE calendar — dots, predictions, cute", "life", tool_cal),''',
    "care registry")

DATA = '''SYMPTOMS = ("cramps", "headache", "mood", "acne", "bloat", "backpain", "fatigue", "nausea")

PHASES = (
    ("menstrual", "🌺 Red Zone", "aaram karo, garam pani, khud se pyaar"),
    ("follicular", "🌱 Bloom Mode", "energy wapas aa rahi — naya kaam shuru karo!"),
    ("ovulation", "🌼 Glow Phase", "sabse zyada charm aaj — duniya ko dikhao"),
    ("luteal", "🍂 Cozy Mode", "self-care + chocolate, emotions valid hai"),
)


def _pd_load():
    return _jload("period.json", {"starts": [], "ends": [], "symptoms": {}})


def _pd_save(d):
    _jsave("period.json", d)


def _pd_parse(dt):
    try:
        return time.strptime(dt, "%Y-%m-%d")
    except Exception:
        return None


def _pd_avg_cycle(starts):
    if len(starts) < 2:
        return 28
    ds = []
    for i in range(1, min(len(starts), 7)):
        a = _pd_parse(starts[-i])
        b = _pd_parse(starts[-i - 1])
        if a and b:
            d = (time.mktime(a) - time.mktime(b)) / 86400.0
            if 15 < d < 60:
                ds.append(int(round(d)))
    if not ds:
        return 28
    return max(18, min(45, int(round(sum(ds) / len(ds)))))


def _pd_phase(day_of_cycle, avg, period_len):
    if day_of_cycle <= period_len:
        return 0
    if day_of_cycle <= int(avg * 0.45):
        return 1
    if day_of_cycle <= int(avg * 0.55):
        return 2
    return 3


def tool_period(app, args):
    T = app.term
    d = _pd_load()
    sub = args[0].lower() if args else ""

    def today():
        return time.strftime("%Y-%m-%d")

    if sub == "start":
        dt = today()
        if d["starts"] and d["starts"][-1] == dt:
            T.dim("  aaj ka start already logged ✓")
            return
        d["starts"].append(dt)
        d["starts"] = d["starts"][-24:]
        _pd_save(d)
        T.push([("  🌺 logged » ", C_DIM), ("period start " + dt, C_VALUE),
                ("  take care ♡", C_PINK)])
        app.add_xp(2)
        return
    if sub == "end":
        dt = today()
        if d["ends"] and d["ends"][-1] == dt:
            T.dim("  aaj ka end already logged ✓")
            return
        d["ends"].append(dt)
        d["ends"] = d["ends"][-24:]
        _pd_save(d)
        T.push([("  🌷 logged » ", C_DIM), ("period end " + dt, C_VALUE)])
        app.add_xp(2)
        return
    if sub == "log" and len(args) >= 2:
        sym = args[1].lower()
        if sym not in SYMPTOMS:
            T.push([("  ✗ symptom: ", C_RED), (" | ".join(SYMPTOMS), C_DIM)])
            return
        sev = 3
        if len(args) >= 3 and args[2].isdigit():
            sev = clamp(int(args[2]), 1, 5)
        d["symptoms"][today()] = {"s": sym, "v": sev}
        _pd_save(d)
        T.push([("  📝 logged » ", C_DIM), (sym + " (" + str(sev) + "/5)", C_VALUE),
                ("  garam pani + aaram ♡", C_PINK)])
        return
    if sub in ("clear", "reset"):
        T.push([("  ⚠ sab period data delete? type: ", C_RED),
                ("period confirm-clear", C_GOLD)])
        return
    if sub == "confirm-clear":
        _pd_save({"starts": [], "ends": [], "symptoms": {}})
        T.dim("  sab clear ✓")
        return

    starts = d["starts"]
    if not starts:
        T.head("◆ PERIOD TRACKER")
        T.dim("  (abhi koi data nahi — sab tere laptop me hi rehta hai)")
        T.dim("  shuru karo:  period start")
        T.dim("  phir roz:    period  (status)   • end pe:  period end")
        return

    avg = _pd_avg_cycle(starts)
    last = starts[-1]
    lp = _pd_parse(last)
    if not lp:
        T.dim("  data me galat date")
        return
    days = int((time.mktime(time.localtime()) - time.mktime(lp)) / 86400.0) + 1
    if days < 1:
        days = 1
    end_d = d["ends"][-1] if d["ends"] else None
    period_len = 5
    if end_d and lp:
        ep = _pd_parse(end_d)
        if ep:
            period_len = clamp(int((time.mktime(ep) - time.mktime(lp)) / 86400.0) + 1, 2, 10)
    next_day = max(1, days - avg)
    next_date = time.strftime("%Y-%m-%d", time.localtime(time.time() + (avg - days + 1) * 86400.0))
    ph_i = _pd_phase(days, avg, period_len)
    ph_name, ph_emoji, ph_msg = PHASES[ph_i]

    T.head("◆ CYCLE CARE — %s" % time.strftime("%d %b %Y"))
    barw = 24
    filled = clamp(int(days * barw / float(avg)), 0, barw)
    T.push([("  day ", C_DIM), (str(days), C_GOLD), ("/%d " % avg, C_DIM)] +
           micro_bar(clamp(days * 100.0 / avg, 1, 100), barw) +
           [("  %s" % avg, C_SLATE)])
    T.push([("  ", C_OUT), ("🌺" + "▁" * max(0, period_len - 1) + " " * 3 +
                            "🌱" + "  " + "🌼" + "      " + "🍂", C_VALUE)])
    T.push([("  phase » ", C_LABEL), (ph_emoji + " ", C_VALUE), (ph_name, C_GOLD)])
    T.push([("  ", C_OUT), (ph_msg, C_PINK)])
    if days > avg:
        T.push([("  ⏳ ", C_GOLD), ("%d din upar — ", days - avg),
                ("agar 2-3 din aur jaye to check kar lena", C_DIM)])
    else:
        T.push([("  next » ", C_LABEL), (next_date, C_VALUE),
                ("  (~%d din)" % (avg - days + 1), C_SLATE)])
    T.push([("  fertile » ", C_LABEL),
            ("ovulation ke aas-paas (%d-%d)" % (int(avg * 0.42), int(avg * 0.52)), C_SLATE)])
    sym = d["symptoms"].get(today())
    if sym:
        T.push([("  aaj log » ", C_LABEL), (sym["s"], C_VALUE),
                (" (%d/5)" % sym["v"], C_DIM)])
    if len(starts) >= 2:
        T.push([("  history » ", C_LABEL),
                ("%d cycles tracked" % len(starts), C_VALUE),
                ("  last start: " + last, C_DIM)])
    T.push([("", C_OUT)])
    T.dim("  period start | period end | period log cramps 3 | period (status)")
    T.dim("  🔒 data sirf ~/.config/cutie/period.json — local only")


def tool_cal(app, args):
    T = app.term
    d = _pd_load()
    now = time.localtime()
    year, month = now.tm_year, now.tm_mon
    if args and args[0].lower() in ("next", "prev"):
        off = 1 if args[0].lower() == "next" else -1
        total = year * 12 + month - 1 + off
        year, month = total // 12, (total % 12) + 1
    avg = _pd_avg_cycle(d["starts"]) if d["starts"] else 28
    period_len = 5
    if d["starts"] and d["ends"]:
        lp = _pd_parse(d["starts"][-1])
        ep = _pd_parse(d["ends"][-1])
        if lp and ep:
            period_len = clamp(int((time.mktime(ep) - time.mktime(lp)) / 86400.0) + 1, 2, 10)
    start_set = set()
    for st in d["starts"]:
        p = _pd_parse(st)
        if not p:
            continue
        for k in range(period_len):
            t2 = time.localtime(time.mktime(p) + k * 86400.0)
            if t2.tm_year == year and t2.tm_mon == month:
                start_set.add(t2.tm_mday)
    try:
        import calendar as _cal
        grid = _cal.monthcalendar(year, month)
        mname = _cal.month_name[month]
    except Exception:
        T.dim("  calendar nahi ban paya")
        return
    today_d = now.tm_mday if (now.tm_year == year and now.tm_mon == month) else -1
    T.head("◆ %s %d" % (mname, year))
    T.push([("  Mo Tu We Th Fr Sa Su", C_LABEL)])
    pred_start = None
    if d["starts"]:
        lp = _pd_parse(d["starts"][-1])
        if lp:
            next_ts = time.mktime(lp) + avg * 86400.0
            nd = time.localtime(next_ts)
            if nd.tm_year == year and nd.tm_mon == month:
                pred_start = nd.tm_mday
            elif abs((next_ts - time.mktime(now)) / 86400.0) < 5:
                pred_start = nd.tm_mday
    for wk in grid:
        segs = [("  ", C_OUT)]
        for day in wk:
            if day == 0:
                segs.append(("    ", C_OUT))
                continue
            lab = "%2d" % day
            if day == today_d:
                segs.append(("[" + lab + "]", C_WHITE))
            elif day in start_set:
                segs.append((lab + "🌺", C_RED))
            elif pred_start == day:
                segs.append((lab + "·", C_GOLD))
            else:
                segs.append((" " + lab + " ", C_OUT))
        T.push(segs)
    T.push([("", C_OUT)])
    segs = [("🌺 ", C_RED), ("period", C_DIM), ("   · ", C_GOLD),
            ("predicted", C_DIM), ("   [ ] ", C_WHITE), ("aaj", C_DIM)]
    T.push(segs)
    T.dim("  nav: cal next | cal prev   •  log: period start")


'''

block("def tool_music(app, args):", DATA, "care tools")

rep('''        td = _jload("todo.json", [])
        pend = sum(1 for x in td if not x["d"])''',
    '''        td = _jload("todo.json", [])
        pend = sum(1 for x in td if not x["d"])
        _pd = _jload("period.json", {"starts": []})
        if _pd["starts"]:
            _lp = _pd_parse(_pd["starts"][-1])
            if _lp:
                _dd = int((time.mktime(time.localtime()) -
                           time.mktime(_lp)) / 86400.0) + 1
                _avg = _pd_avg_cycle(_pd["starts"])
                _pi = _pd_phase(_dd, _avg, 5)
                _pe, _pn = PHASES[_pi][1], PHASES[_pi][0]''', "dash period hook")

rep('''        td = _jload("todo.json", [])
        pend = sum(1 for x in td if not x["d"])
        la = os.getloadavg()''', '''        td = _jload("todo.json", [])
        pend = sum(1 for x in td if not x["d"])
        la = os.getloadavg()''', "dash order keep")

rep('''        if self.info.bat:
            segs += [("   BAT ", C_LABEL), (str(self.info.bat[0]) + "%", C_VALUE)]
        put_segs(cv, max(2, (W - disp_width("".join(x for x, _ in segs))) // 2), y, segs)''',
    '''        if self.info.bat:
            segs += [("   BAT ", C_LABEL), (str(self.info.bat[0]) + "%", C_VALUE)]
        try:
            if "_pd" in dir() and _pd["starts"]:
                segs += [("   ", C_DIM), (PHASES[_pi][1], C_PINK)]
        except Exception:
            pass
        put_segs(cv, max(2, (W - disp_width("".join(x for x, _ in segs))) // 2), y, segs)''',
    "dash period show")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

fails = [f for f in fails if f != "dash order keep"]
if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v265")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v27.5 CARE patched ✓  (backup: %s.bak-v265)" % P)
