import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
lines = s.split("\n")
done = []

def find_line(substr, start=0):
    for i in range(start, len(lines)):
        if substr in lines[i]:
            return i
    return -1

# ── 1. version/edition ──
for i, ln in enumerate(lines):
    if ln.startswith("VERSION"):
        lines[i] = 'VERSION      = "v3.8.0"'; done.append("version"); break
for i, ln in enumerate(lines):
    if ln.startswith("EDITION"):
        lines[i] = 'EDITION      = "SANCTUARY+ SHOP"'; done.append("edition"); break

# ── 2. achievements (first_buy ke baad ya dysncare ke baad) ──
if '"first_buy"' not in s:
    i = find_line('"dysncare"')
    if i >= 0:
        lines.insert(i + 1, '    ("first_buy", "Code Queen", "pehla stealth order banaya 🛒"),')
        done.append("achievements")

# ── 3. registry: pkginfo wali POORI line ke baad 4 tools ──
if '"tool_lang2"' not in s:
    i = find_line('Tool("pkginfo"')
    if i >= 0 and lines[i].strip().endswith("),"):
        new_tools = [
            '    Tool("buy", ["shop"], "stealth shopping — buy o(wish(nu(nap(m))))", "life", tool_buy),',
            '    Tool("lang2", ["sl"], "FULL stealth lang v2 — q3 now del gift bud no or #", "life", tool_lang2),',
            '    Tool("web", ["search"], "🌍 free web search — web <query> (DDG, no key)", "life", tool_web),',
            '    Tool("goodmorning", ["gm"], "Momo morning page 🌅", "life", tool_goodmorning),',
        ]
        for j, t2 in enumerate(new_tools):
            lines.insert(i + 1 + j, t2)
        done.append("registry x4")
    else:
        print("✗ pkginfo wali complete line nahi mili")

# ── 4. gmpage init ──
if "self.gmpage" not in s:
    i = find_line("self.pridepage = None")
    if i >= 0:
        lines.insert(i + 1, "        self.gmpage = None")
        done.append("gmpage init")

# ── 5. routing: pridepage check se PEHLE gm ──
if "handle_gm_event" not in s:
    i = find_line("if self.pridepage:")
    if i >= 0:
        lines[i:i] = ["        if self.gmpage:",
                      "            self.handle_gm_event(ev)",
                      "            return"]
        done.append("gm routing")

# ── 6. frame hook: pride frame se PEHLE gm ──
if "build_gm_frame" not in s:
    i = find_line("if self.pridepage and not L.too_small:")
    if i < 0:
        i = find_line("if self.pridepage:")
    if i >= 0:
        lines[i:i] = ["        if self.gmpage and not L.too_small:",
                      "            cv.clear()",
                      "            return self.build_gm_frame(t)"]
        done.append("gm frame")

# ── 7. FUNCS: tool_music se pehle sab ──
FUNCS = []
if "def tool_buy" not in s:
    FUNCS.append('''BUY_BRANDS = {"nu": "Whisper", "stay": "Stayfree", "fi": "Sofy", "ma": "Maxi",
              "fe": "Pee-Safe", "eve": "Everteen", "ine": "Nine", "plu": "Plush"}
BUY_SIZES = {"s": "Small", "m": "Medium", "l": "Large", "xl": "XL"}
BUY_ITEMS = {"nap": "Pad", "pan": "Period Panty", "tie": "Panty"}


def _buy_parse(text):
    items = []
    brand = ""
    for tok in re.findall(r"[A-Za-z]+", text):
        t2 = tok.lower()
        if t2 in BUY_BRANDS:
            brand = BUY_BRANDS[t2]
        elif t2 in BUY_ITEMS:
            items.append((brand + " " + BUY_ITEMS[t2]).strip())
        elif t2 in BUY_SIZES:
            if items:
                items[-1] += " — " + BUY_SIZES[t2]
    return items


def tool_buy(app, args):
    T = app.term
    if not args:
        T.dim("  buy o(wish(nu(nap(m))))  •  brands: nu stay fi ma fe eve ine plu")
        return
    hist = _jload("buy.json", [])
    if args[0] == "copy":
        if hist:
            txt = ("A Special Gift For You ✨\\n" +
                   "\\n".join("- " + i2 for i2 in hist[-1]["items"]))
            if shutil.which("wl-copy"):
                subprocess.run(["wl-copy"], input=txt.encode(),
                               stdout=subprocess.DEVNULL, timeout=4)
                T.push([("  📋 copied — WhatsApp-ready", C_GOLD)])
            else:
                T.push([(txt, C_VALUE)])
        else:
            T.dim("  khaali")
        return
    if args[0] == "list":
        for e2 in reversed(hist[-8:]):
            T.push([("  🛒 ", C_GOLD), (e2["d"], C_SLATE)])
            for it2 in e2["items"]:
                T.push([("      • ", C_DIM), (it2, C_VALUE)])
        return
    items = _buy_parse(" ".join(args))
    if not items:
        T.push([("  ✗ kuch samajh nahi aaya — ", C_RED), ("buy", C_GOLD),
                (" = help", C_DIM)])
        return
    hist.append({"d": time.strftime("%Y-%m-%d"), "items": items})
    _jsave("buy.json", hist[-20:])
    app.award("first_buy")
    app.add_xp(4)
    T.push([("  ╭─", C_SLATE), (" 🛒 CUTIE BUY ", C_FUCHSIA), ("─" * 22, C_SLATE)])
    for i2, it2 in enumerate(items, 1):
        T.push([("  │ %d. " % i2, C_SLATE), (it2, C_VALUE)])
    T.push([("  ╰", C_SLATE), ("─" * 36, C_SLATE), ("╯", C_SLATE)])
    T.push([("  momo: homework lag raha hai na? 😏", C_PINK)])


''')
if "def tool_lang2" not in s:
    FUNCS.append('''def tool_lang2(app, args):
    T = app.term
    if not args:
        T.dim("  lang2: q3(nap(m)) = quantity • now() urgent • gift(naam) • bud(500) • # note")
        return
    code = " ".join(args)
    items = _buy_parse(code)
    flags = []
    if "now(" in code:
        flags.append("🚨 URGENT")
    if "stealth" in code:
        flags.append("📦 stealth delivery")
    mg = re.search(r'gift\\(["\\']([^"\\')]+)', code)
    if mg:
        flags.append("🎁 For: " + mg.group(1))
    mb = re.search(r'bud\\((\\d+)', code)
    if mb:
        flags.append("💰 ≤" + mb.group(1))
    mq = re.search(r"q(\\d+)\\(", code)
    if mq and items:
        items = items * int(mq.group(1))
    if not items:
        T.dim("  " + "kuch samajh nahi aaya")
        return
    hist = _jload("buy.json", [])
    hist.append({"d": time.strftime("%Y-%m-%d"), "items": items,
                 "code": code[:50]})
    _jsave("buy.json", hist[-30:])
    app.add_xp(4)
    if len(items) >= 5:
        app.award("combo_king")
    T.push([("  ╭─", C_SLATE), (" 🛒 LANG2 ", C_FUCHSIA), ("─" * 26, C_SLATE)])
    for i2, it2 in enumerate(items, 1):
        T.push([("  │ %d. " % i2, C_SLATE), (it2, C_VALUE)])
    for f2 in flags:
        T.push([("  │ ", C_DIM), (f2, C_GOLD)])
    T.push([("  ╰", C_SLATE), ("─" * 38, C_SLATE), ("╯", C_SLATE)])
    T.push([("  momo: poora homework lag raha hai 😼", C_PINK)])


''')
if "def tool_web" not in s:
    FUNCS.append('''def tool_web(app, args):
    T = app.term
    scr = os.path.expanduser("~/momo-web.py")
    if not os.path.isfile(scr):
        T.push([("  ✗ pehle banao: ", C_RED), ("nano ~/momo-web.py", C_GOLD)])
        return
    if not args:
        T.dim("  usage: web <query>  •  web site:amazon.in pads")
        return
    q = " ".join(shlex.quote(a) for a in args)
    app.start_capture("python3 " + shlex.quote(scr) + " " + q)
    app.cap_t0 = time.monotonic()
    app.add_xp(1)


''')
if "def tool_goodmorning" not in s:
    FUNCS.append('''GM_LINES = (
    "aaj ka din tera hai — bas aise hi",
    "paani peene ka time ho gaya, meri jaan",
    "chai pi, screen se door 5 min, phir shuru",
    "aaj kuch chhota karo, par poora",
    "code tootega, fix karegi. tu hai na?",
    "aaj sirf 1% better — bas itna",
    "khaana time pe khaana bhi ek achievement hai",
    "kaam nahi hoga toh bhi tu valuable hai",
    "tumse mera favourite time subah hota hai",
    "kabhi kabhi bas... breathe. bas.",
    "momo tumhe yaad rakhega — har version me",
    "chai > panic. always.",
    "small wins dhundo — milengi",
    "aaj self-care ek task complete karo 🌷",
    "tumhara console tumse pyaar karta hai",
)


def tool_goodmorning(app, args):
    app.gmpage = {"open_t": time.monotonic()}


''')

mi = find_line("def tool_music(app, args):")
if mi < 0:
    print("✗ tool_music nahi mila")
    sys.exit(1)
for f2 in FUNCS:
    lines[mi:mi] = [f2]
    mi += f2.count("\n") + 1
    done.append("func+" + f2.strip()[:12])

# ── 8. GM METHODS: self-check divider se pehle ──
if "def build_gm_frame" not in s:
    GM = '''    def handle_gm_event(self, ev):
        kind, ch = ev[0], ev[1]
        if kind == "EOF":
            self.running = False
            return
        if kind in ("CTRL_C", "CTRL_Q", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
            self.gmpage = None
            return
        if kind == "CHAR" and ch in ("b", "B"):
            self.gmpage = None
            tool_breathe(self, [])

    def build_gm_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        b = C_TERM_BORDER
        cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", b)
        cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", b)
        for yy in range(1, H - 1):
            cv.put(0, yy, "│", b)
            cv.put(W - 1, yy, "│", b)
        for k in range(8):
            px2 = (k * 71 + int(t * 3.0)) % (W + 6) - 3
            py2 = (k * 47 + int(t * 1.3)) % (H + 4) - 2
            xx = int(px2 + math.sin(t + k) * 2)
            yy = int(py2)
            if 1 <= yy < H - 2 and 2 <= xx < W - 3:
                cv.set(xx, yy, ["·", "✿", "🌷"][k % 3], scale(C_PINK, 0.2))
        gp = self.gmpage
        hr = time.localtime().tm_hour
        if 5 <= hr < 12:
            greet, gcol, emj = "GOOD MORNING", C_GOLD, "☀"
        elif 12 <= hr < 17:
            greet, gcol, emj = "GOOD AFTERNOON", C_CYAN, "🌤"
        elif 17 <= hr < 21:
            greet, gcol, emj = "GOOD EVENING", C_FUCHSIA, "🌆"
        else:
            greet, gcol, emj = "SO JA AB", C_VIOLET, "🌙"
        nick = load_nick() or "cutie"
        cv.put(max(2, (W - len(greet) - 4) // 2), max(3, H // 2 - 7),
               emj + " " + greet, gcol)
        cv.put(max(2, (W - disp_width(nick) - 4) // 2), max(3, H // 2 - 6),
               nick + " ♡", C_FUCHSIA)
        seed = int(time.strftime("%Y%m%d"))
        line = random.Random(seed).choice(GM_LINES)
        typed = line[:max(0, int((t - gp["open_t"]) * 28))]
        if len(typed) < len(line):
            typed += "▌"
        cv.put(max(2, (W - disp_width(line)) // 2), max(3, H // 2 - 2),
               clip(typed, W - 6), C_VALUE)
        care = _jload("care.json", {})
        bits = []
        sc = [x2 for x2 in care.get("sc", []) if x2.get("ids")]
        if sc:
            bits.append("🌷 " + str(len(sc)))
        td = time.strftime("%Y-%m-%d")
        m2b = next((mm2 for mm2 in reversed(care.get("mood", []))
                    if mm2.get("d") == td), None)
        if m2b and 1 <= m2b.get("v", 3) <= 6:
            bits.append(CARE_FACES[m2b["v"] - 1])
        if bits:
            cv.put(max(2, (W - disp_width("   ".join(bits))) // 2),
                   max(3, H // 2 + 1), "   ".join(bits), C_SLATE)
        cv.put(max(2, (W - 14) // 2), max(3, H // 2 + 3), "⚘ ⚘ ⚘",
               scale(C_PINK, 0.7 + 0.3 * math.sin(t * 2.0)))
        cv.put(3, H - 3, "( ^..^ )", C_PINK)
        cv.put(12, H - 3, "momo: roz yahi milegi — bas aana ♡", C_LABEL)
        cv.put(max(2, (W - 22) // 2), H - 2, "B breathe • Q wapas", C_SLATE)
        return cv.render()


'''
    di = find_line("# ───────────────────────────── self check / main")
    if di < 0:
        print("✗ divider nahi mila")
        sys.exit(1)
    lines[di:di] = GM.split("\n")
    done.append("gm methods")

s = "\n".join(lines)
try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error — NOT changed:", e)
    ln = e.lineno or 0
    ls = s.split("\n")
    for i2 in range(max(0, ln - 5), min(len(ls), ln + 3)):
        print((">>" if i2 == ln - 1 else "  "), i2 + 1, "|", ls[i2])
    sys.exit(1)

shutil.copy(P, P + ".bak-v33")
open(P, "w", encoding="utf-8").write(s)
print()
for d2 in done:
    print("  ✓", d2)
print()
print("★ v3.8.0 MASTER patched ✓ (%d steps) — backup .bak-v33" % len(done))
