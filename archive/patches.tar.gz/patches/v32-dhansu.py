import re
import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "tool_synthwave" in s:
    print("already patched ✓")
    sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label)
        print("  ✗", label)
        return
    s = s.replace(old, new, 1)
    print("  ✓", label)

def rx(pat, repl, label):
    global s
    s2, n = re.subn(pat, repl, s, count=1)
    if n == 0:
        fails.append(label)
        print("  ✗", label)
        return
    s = s2
    print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label)
        print("  ✗", label)
        return
    s = s[:a] + new + s[a:]
    print("  ✓", label)

rx(r'VERSION\s*=\s*"[^"]*"', 'VERSION      = "v3.2.0"', "version -> 3.2.0")
rx(r'EDITION\s*=\s*"[^"]*"', 'EDITION      = "DHANSU EDITION"', "edition")

rep('''    ("mood30", "Mood Mapper", "30 mood logs"),''',
    '''    ("mood30", "Mood Mapper", "30 mood logs"),
    ("synth", "Retro Soul", "synthwave sunset dekha"),
    ("fw10", "Pyromaniac", "10 fireworks chalaye"),''',
    "dhansu achievements")

rep('''        self.breathe = None
        self.care = None''', '''        self.breathe = None
        self.care = None
        self.fancy = None''', "fancy init")

rep('''        if self.breathe:
            self.handle_breathe_event(ev)
            return''', '''        if self.fancy:
            self.handle_fancy_event(ev)
            return
        if self.breathe:
            self.handle_breathe_event(ev)
            return''', "fancy routing")

rep('''        if self.breathe:
            cv.clear()
            return self.build_breathe_frame(t)''', '''        if self.fancy:
            cv.clear()
            return self.build_fancy_frame(t)
        if self.breathe:
            cv.clear()
            return self.build_breathe_frame(t)''', "fancy frames")

rep('''    Tool("breathe", ["calm"], "guided breathing flower — 4-4-6, anxiety ka dushman", "life", tool_breathe),''',
    '''    Tool("breathe", ["calm"], "guided breathing flower — 4-4-6, anxiety ka dushman", "life", tool_breathe),
    Tool("hackertype", ["htype"], "Hollywood hacking scene — auto typing", "fun", tool_hackertype),
    Tool("fireworks", ["fw"], "full-screen fireworks show 🎆", "fun", tool_fireworks),
    Tool("quote", ["soft"], "soft quote card — 100+ vibes", "fun", tool_quote),
    Tool("synthwave", ["synth", "retro"], "RETRO SUN + moving grid 🌆", "fun", tool_synthwave),''',
    "dhansu registry")

DATA = '''HT_LOGS = (
    "[ OK ] init cutie exploit framework v9.9",
    "[ ** ] scanning 192.168.{a}.0/24 ...",
    "[ OK ] target: 192.168.{a}.{b}  port 1337",
    "[ >> ] bypassing firewall ......... 100%",
    "[ >> ] cracking hash 0x{h} ....... 100%",
    "[ OK ] root shell acquired",
    "[ ** ] exfiltrating data.db [##########] 100%",
    "[ OK ] wiping fingerprints ... chup 🤫",
    "[ OK ] deploying good vibes.dll",
    "[ OK ] ACCESS GRANTED",
)
QUOTES = (
    ("tu itni capable hai ki tujhe khud bhi andaza nahi", "momo"),
    ("bade sapno ki keemat thakan hoti hai — kha letana", "cutie wisdom"),
    ("har expert ekdin beginner tha jo quit nahi kiya", "unknown"),
    ("self-care selfish nahi hai — zaroori hai", "soft truth"),
    ("code bhi insaan ki tarah — break ho to repair, quit nahi", "dev gyaan"),
    ("tumhari speed ka kisi se comparison nahi — tumhara race tumhara hai", "daily vibe"),
    ("jo aaj thoda mushkil hai, kal wo easy lagega", "growth"),
    ("khud par shak ho to yaad karo — kitni baar gir ke sambhi ho", "momo"),
    ("chhoti jeet ko bhi celebrate karo — energy isi se aati hai", "cutie wisdom"),
    ("perfection nahi, progress — roz 1%", "kaizen"),
    ("tum wo cheez ban sakti ho jo tum sochti ho", "classic"),
    ("raat jitni gehri hogi, subah utni sundar", "hope"),
    ("apne aap ko waise baat karo jaise best friend se karte ho", "soft truth"),
    ("break lena bhi ek achievement hai — burnout nahi", "self-care"),
    ("tumhara best kaafi hai — aaj bas itna", "aaj ka gyaan"),
    ("git commit kiya? life bhi versioning hai — push karte raho", "dev gyaan"),
    (" feelings bhi valid hai jo bhi ho — likh do, halka lagega", "journaling"),
    ("chaye ho to duniya badlo, ya bas aaj khud ko — dono bade kaam", "momo"),
)


def tool_quote(app, args):
    T = app.term
    q, who = random.choice(QUOTES)
    T.push([("  ╭", C_SLATE), ("─" * 44, C_SLATE), ("╮", C_SLATE)])
    T.push([("  │ ", C_SLATE), ("🌸", C_PINK), (" " + q[:40], C_VALUE)])
    if len(q) > 40:
        T.push([("  │ ", C_SLATE), ("   " + q[40:80], C_VALUE)])
    T.push([("  │ ", C_SLATE), ("─" * 42, C_DIM), ("│", C_SLATE)])
    T.push([("  │ ", C_SLATE), ("— " + who, C_FUCHSIA)])
    T.push([("  ╰", C_SLATE), ("─" * 44, C_SLATE), ("╯", C_SLATE)])
    app.add_xp(1)


def tool_hackertype(app, args):
    T = app.term
    app.suspend_hud()
    try:
        enter_raw(app.fd)
        app.keys.pend = b""
        W, H = app.size()
        out = app.out
        out.write(ALT_ON + CUR_HIDE + CLEAR_SCR)
        out.flush()
        G = (0, 230, 118)
        skipped = False
        for i2 in range(28):
            if skipped:
                break
            tmpl = HT_LOGS[i2 % len(HT_LOGS)]
            line = (tmpl.replace("{a}", str(random.randint(1, 254)))
                        .replace("{b}", str(random.randint(2, 254)))
                        .replace("{h}", "".join(random.choice("0123456789abcdef")
                                                for _ in range(8))))
            pre = "cutie@root:~# "
            shown = ""
            for c2 in line:
                shown += c2
                if random.random() < 0.08:
                    try:
                        out.write(ESC + "[%d;1H" % (min(H, 3 + i2)) + fg(G) +
                                  pre + shown + random.choice("▓▒░01") + RESET)
                        out.flush()
                    except Exception:
                        pass
                try:
                    out.write(ESC + "[%d;1H" % (min(H, 3 + i2)) + fg(G) +
                              pre + shown + RESET)
                    out.flush()
                except Exception:
                    pass
                t_end = time.monotonic() + 0.012
                while time.monotonic() < t_end:
                    if app.keys.poll(0.0):
                        skipped = True
                    time.sleep(0.002)
                if skipped:
                    break
            time.sleep(0.16)
            if app.keys.poll(0.0):
                skipped = True
        if not skipped:
            big = "✦ ACCESS GRANTED ✦"
            for i3 in range(10):
                cv = Canvas(W, H)
                col = C_WHITE if i3 % 2 else (40, 255, 140)
                cv.put(max(0, (W - disp_width(big)) // 2), H // 2, big, col)
                for k in range(40):
                    cv.set(random.randrange(W), random.randrange(H),
                           random.choice("✦*·+"), scale(col, 0.5))
                try:
                    out.write(HOME + cv.render())
                    out.flush()
                except Exception:
                    pass
                if app.keys.poll(0.08):
                    break
                time.sleep(0.05)
    finally:
        app.resume_hud()
    T.push([("  💻 ", C_DIM), ("pure natak tha — par style full tha na?", C_DIM)])


def tool_fireworks(app, args):
    T = app.term
    app.suspend_hud()
    count = 0
    try:
        enter_raw(app.fd)
        app.keys.pend = b""
        W, H = app.size()
        out = app.out
        out.write(ALT_ON + CUR_HIDE)
        out.flush()
        rockets = []
        sparks = []
        cv = Canvas(W, H)
        quitf = False
        last = 0.0
        while not quitf:
            now = time.monotonic()
            if now - last > 0.55 and len(rockets) < 3:
                last = now
                rockets.append({"x": random.uniform(6, W - 6),
                                "y": H - 2.0,
                                "vy": -random.uniform(9, 14),
                                "tx": random.uniform(4, H - 8),
                                "c": random.choice(GRAD_STOPS + [C_GOLD, C_WHITE])})
            cv.clear()
            cv.put(2, 1, "🎆 CUTIE FIREWORKS — Q exit", C_SLATE)
            for r2 in rockets[:]:
                r2["y"] += r2["vy"] * 0.05
                xi, yi = int(r2["x"]), int(r2["y"])
                cv.set(xi, yi, "|", scale(r2["c"], 0.8))
                if r2["y"] <= r2["tx"]:
                    rockets.remove(r2)
                    count += 1
                    if count >= 10:
                        app.award("fw10")
                    for _k in range(46):
                        a2 = random.uniform(0, 6.283)
                        sp2 = random.uniform(1.5, 6.5)
                        sparks.append({"x": float(xi), "y": float(yi),
                                       "vx": math.cos(a2) * sp2,
                                       "vy": math.sin(a2) * sp2,
                                       "life": 1.0,
                                       "c": r2["c"]})
            for s2 in sparks[:]:
                s2["x"] += s2["vx"] * 0.05
                s2["y"] += s2["vy"] * 0.05
                s2["vy"] += 1.4 * 0.05
                s2["life"] -= 0.022
                if s2["life"] <= 0 or s2["y"] >= H - 1:
                    sparks.remove(s2)
                    continue
                ch2 = "✦" if s2["life"] > 0.6 else ("·" if s2["life"] > 0.3 else "∙")
                cv.set(int(s2["x"]), int(s2["y"]), ch2,
                       scale(s2["c"], 0.35 + 0.65 * s2["life"]))
            for ev in app.keys.poll(0.0):
                if ev[0] in ("CTRL_C", "ESC", "EOF") or (ev[0] == "CHAR" and ev[1] in ("q", "Q")):
                    quitf = True
                elif ev[0] == "EOF":
                    quitf = True
            if ev and ev[0] == "EOF" if False else False:
                quitf = True
            try:
                out.write(HOME + cv.render())
                out.flush()
            except Exception:
                break
            time.sleep(0.016)
    finally:
        app.resume_hud()
    T.push([("  🎆 ", C_DIM), ("%d phool khile" % count, C_VALUE),
            ("  • momo: waah! 🎇", C_PINK)])


def tool_synthwave(app, args):
    T = app.term
    app.suspend_hud()
    try:
        enter_raw(app.fd)
        app.keys.pend = b""
        W, H = app.size()
        out = app.out
        out.write(ALT_ON + CUR_HIDE)
        out.flush()
        cv = Canvas(W, H)
        quitf = False
        t0 = time.monotonic()
        SUN = C_MAGENTA
        GRID = C_FUCHSIA
        MOUNT = C_VIOLET
        while not quitf:
            now = time.monotonic()
            t2 = now - t0
            cv.clear()
            horizon = max(6, int(H * 0.45))
            scx = W // 2
            srad = min(9, horizon - 2)
            for yy in range(horizon - srad * 2, horizon):
                dy = horizon - yy
                if dy > srad * 2:
                    continue
                half = int(math.sqrt(max(0, srad * srad - (dy - srad) * (dy - srad))))
                stripe = (yy + int(t2 * 6.0)) % 6 < 3
                if stripe or dy < srad:
                    cc = mix(SUN, (255, 120, 200), dy / float(max(1, srad * 2)))
                else:
                    cc = scale(SUN, 0.35)
                for xx in range(scx - half, scx + half + 1):
                    if 0 <= xx < W - 1:
                        cv.set(xx, yy, "▄", cc)
            for yy in range(horizon + 1, H - 1):
                depth = (yy - horizon) / float(H - horizon)
                step = max(1, int((1.0 - depth) * 6) + 1)
                if int((yy + t2 * 8.0)) % (step * 2) < step:
                    rowc = mix(GRID, C_VIOLET, depth * 0.6)
                    for xx in range(2, W - 2, 2):
                        cv.set(xx, yy, "─", scale(rowc, 0.85))
            for k in range(-8, 9):
                for yy in range(horizon + 1, H - 1):
                    depth = (yy - horizon) / float(H - horizon)
                    xx = scx + int(k * (2 + depth * depth * 26))
                    if 1 <= xx < W - 1:
                        if (k + int(t2 * 2)) % 2 == 0 or depth > 0.7:
                            cv.set(xx, yy, "║", scale(GRID, 0.5 + depth * 0.4))
            import random as _r
            _r.seed(42)
            for k in range(28):
                mx = _r.randint(2, W - 3)
                mh = _r.randint(2, 6)
                for j in range(mh):
                    xx = mx
                    yy = horizon - 1 - j
                    if 0 <= yy:
                        cc = scale(MOUNT, 1.0 - j * 0.15)
                        cv.set(xx, yy, "▄" if j == 0 else "█", cc)
            for k in range(24):
                stx = (_r.randint(2, W - 3))
                sty = (_r.randint(2, horizon - srad * 2 - 2))
                tw2 = 0.4 + 0.6 * abs(math.sin(t2 * 2.0 + k))
                cv.set(stx, sty, "·", scale(C_WHITE, tw2))
            cv.put(2, 1, "🌆 SYNTHWAVE — Q exit", C_SLATE)
            try:
                out.write(HOME + cv.render())
                out.flush()
            except Exception:
                break
            for ev in app.keys.poll(0.03):
                if ev[0] in ("CTRL_C", "ESC", "EOF") or (ev[0] == "CHAR" and ev[1] in ("q", "Q")):
                    quitf = True
            time.sleep(0.03)
    finally:
        app.resume_hud()
    app.award("synth")
    T.push([("  🌆 ", C_DIM), ("retro soul reset ho gaya — vapourwave forever", C_DIM)])


'''

block("def tool_music(app, args):", DATA, "dhansu tools")

NEW_FANCY = '''    def handle_fancy_event(self, ev):
        kind, ch = ev[0], ev[1]
        if kind == "EOF":
            self.running = False
            return
        if kind in ("CTRL_C", "CTRL_Q", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
            self.fancy = None

    def build_fancy_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        cv.put(2, 1, "quote: type quote • fireworks: Q exit", C_SLATE)
        return cv.render()


'''

block("# ───────────────────────────── self check / main", NEW_FANCY, "fancy methods")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v31")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v3.2.0 DHANSU patched ✓  (backup: %s.bak-v31)" % P)

