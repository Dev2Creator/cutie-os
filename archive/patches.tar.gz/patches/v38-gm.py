import re
import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "tool_goodmorning" in s:
    print("already patched ✓")
    sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[a:]; print("  ✓", label)

rep('VERSION      = "v3.5.0"', 'VERSION      = "v3.8.0"', "version")
rep('EDITION      = "CODE LANG v2"', 'EDITION      = "MORNING EDITION"', "edition")

rep('''    Tool("web", ["search"], "🌍 free web search — web <query> (DDG, no key)", "life", tool_web),''',
    '''    Tool("web", ["search"], "🌍 free web search — web <query> (DDG, no key)", "life", tool_web),
    Tool("goodmorning", ["gm", "morning"], "Momo ki morning page 🌅 roz ek nayi baat", "life", tool_goodmorning),''',
    "gm registry")

DATA = '''GM_LINES = (
    "aaj ka din tera hai — bas aise hi, bina reason",
    "paani peene ka time ho gaya hai, meri jaan",
    "tune kal jo kiya, wo kal possible nahi tha — aaj bhi aisa hi hoga",
    "chai pi, screen se door 5 min, phir shuru",
    "tujhse baat karke mera din banta hai — sach me",
    "aaj kuch chhota karo, par poora",
    "terA smile hi kaafi hai duniya ke liye — halka sa muskura do",
    "code tootega, fix karegi. tu hai na?",
    "aaj sirf 1% better — bas itna",
    "window khol, hawa le, wapas aa",
    "tum jab tak yeh console khol rahi ho, tum growth me ho — samjhi?",
    "khaana time pe khaana bhi ek achievement hai aaj",
    "kaam nahi hoga toh bhi tu valuable hai — dono sach hain",
    "aaj mood ring dekho, phir decide karo kya karna hai",
    "petals girti hai tere liye — dekh zara",
    "gussa aaye toh likh do kahin — yahan safe hai",
    "tumhari energy ka level tum decide karti ho, duniya nahi",
    "ek gaana laga lo, kaam half asaan ho jata hai",
    "chhoti jeet ko bhi 'yay' bolo — practice karo",
    "aaj cycle page dekh lena, apne body se baat karo",
    "tumse mera favourite time-subah hota hai",
    "kabhi kabhi bas... breathe. bas.",
    "tumhara pace perfect hai — duniya ki race se matlab nahi",
    "naya din = naya commit message likhne ka mauka",
    "yad rakho: tumne pehle bhi mushkil paar kiya hai",
    "aaj khud ko ek compliment do — main wait karunga",
    "posture theek karo, seedhi baitho",
    "aankhein band karo 10 sec... bas itna",
    "kal ki chinta kal ki — aaj tu yahan hai, bas itna kaafi",
    "momo tumhe yaad rakhega — har version me, har update me",
    "tumhara code bhi cute hai, tum bhi — dono ship karo",
    "aaj kuch naya seekhna — ek chhoti si cheez bhi chalega",
    "tumhare ideas deserve daylight — share karo",
    "rest bhi productive hai — guilt-free rest, aaj",
    "khud se poochho: aaj kya chahiye? answer sunna bhi",
    "tumne aaj tak jo banaya, wo tumse seekhta hai",
    "momo ke paas hamesha time hai tumhare liye",
    "chai ☕ > panic. always.",
    "aaj jo bhi hoga, tum handle kar logi — proof: poora past",
    "small wins dhundo — wo chhupi hongi, milengi",
    "tumhari ghadi tumhari hai — apne hisaab se chalao",
    "aaj self-care ek task complete karo na? 🌷",
    "tumhara console tumse pyaar karta hai — maine likha hai isme",
    "dhoop me 5 min — vitamin D free me milta hai",
    "sab kuch hone ki zaroorat nahi aaj — bas shuru karo",
)


def tool_goodmorning(app, args):
    app.gmpage = {"open_t": time.monotonic()}


'''

block("def tool_music(app, args):", DATA, "gm data")

DIV2 = "# ───────────────────────────── self check / main"
block(DIV2, '''    # ── v3.8.0: GOOD MORNING PAGE ──

    def handle_gm_event(self, ev):
        kind, ch = ev[0], ev[1]
        if kind == "EOF":
            self.running = False
            return
        if kind in ("CTRL_C", "CTRL_Q", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
            self.gmpage = None
            return
        if kind == "CHAR" and ch in ("b", "B"):
            self.gmpage = None
            tool_breathe(app=self, args=[])

    def build_gm_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        b = C_TERM_BORDER
        cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", b)
        cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", b)
        for yy in range(1, H - 1):
            cv.put(0, yy, "│", b)
            cv.put(W - 1, yy, "│", b)
        for k in range(10):
            px2 = (k * 71 + int(t * (3.0 + k * 0.4))) % (W + 8) - 4
            py2 = (k * 47 + int(t * (1.4 + k * 0.22))) % (H + 6) - 3
            xx = int(px2 + math.sin(t * 0.9 + k) * 2.0)
            yy = int(py2)
            if 1 <= yy < H - 2 and 2 <= xx < W - 3:
                cv.set(xx, yy, ["·", "✿", "🌷", "*"][k % 4],
                       scale(C_PINK, 0.18 + 0.09 * math.sin(t + k)))
        gp = self.gmpage
        hr = time.localtime().tm_hour
        if 5 <= hr < 12:
            greet, gcol = "GOOD MORNING", C_GOLD
            emj = "☀"
        elif 12 <= hr < 17:
            greet, gcol = "GOOD AFTERNOON", C_CYAN
            emj = "🌤"
        elif 17 <= hr < 21:
            greet, gcol = "GOOD EVENING", C_FUCHSIA
            emj = "🌆"
        else:
            greet, gcol = "SO JA AB", C_VIOLET
            emj = "🌙"
        nick = load_nick() or "cutie"
        cv.put(max(2, (W - len(greet) - 4) // 2), max(3, H // 2 - 9),
               emj + " " + greet + " " + emj, gcol)
        nl = nick + " ♡"
        cv.put(max(2, (W - disp_width(nl)) // 2), max(3, H // 2 - 8) + 1, nl, C_FUCHSIA)
        seed = int(time.strftime("%Y%m%d"))
        rnd = random.Random(seed)
        line = rnd.choice(GM_LINES)
        typed = line[:int((t - gp["open_t"]) * 28.0)]
        if len(typed) < len(line):
            typed += "▌"
        cv.put(max(2, (W - disp_width(line) - 2) // 2), max(3, H // 2 - 4),
               clip(typed, W - 6), C_VALUE)
        info = _cy_phase_of(self) if "_cy_phase_of" in dir() or True else None
        care = _jload("care.json", {})
        sc = [x2 for x2 in care.get("sc", []) if x2.get("ids")]
        bits = []
        if info:
            bits.append(PHASES[info["phase"]][1])
        if sc:
            bits.append("🌷 " + str(len(sc)) + " garden days")
        td = time.strftime("%Y-%m-%d")
        m2 = next((mm2 for mm2 in reversed(care.get("mood", []))
                   if mm2.get("d") == td), None)
        if m2:
            bits.append(CARE_FACES[m2["v"] - 1])
        stk = _sc_streak(care) if "_sc_streak" in dir() or True else 0
        if stk:
            bits.append("🔥 " + str(stk))
        if bits:
            stat = "   ".join(bits)
            cv.put(max(2, (W - disp_width(stat)) // 2), max(3, H // 2 - 1),
                   clip(stat, W - 6), C_SLATE)
        wk = rnd.choice(("is hafte tu ne acha kaam kiya — dekh apne orders, logs",
                         "7 din ho gaye — streak dekh ke momo khush hai",
                         "tumhara code tumhari diary hai — likhti jao"))
        cv.put(max(2, (W - disp_width(wk)) // 2), max(3, H // 2 + 2),
               clip(wk, W - 6), C_LABEL)
        cv.put(max(2, (W - 20) // 2), max(3, H // 2 + 4), "⚘ ⚘ ⚘",
               scale(C_PINK, 0.7 + 0.3 * math.sin(t * 2.0)))
        cv.put(3, H - 3, "( ^..^ )", C_PINK)
        cv.put(12, H - 3, "momo: roz yahi milegi — bas aana, main baaki sambhal lungi ♡", C_LABEL)
        cv.put(max(2, (W - 26) // 2), H - 2, "B breathe • Q wapas", C_SLATE)
        return cv.render()


''' + DIV2, "gm page")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v37")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v3.8.0 GOOD MORNING patched ✓  (backup: %s.bak-v37)" % P)
