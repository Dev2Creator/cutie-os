import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "_sanctuary_tabs" in s:
    print("already patched ✓")
    sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label)
        print("  ✗", label)
        return
    s = s.replace(old, new, 1)
    print("  ✓", label)

def span(a_m, b_m, new, label):
    global s
    try:
        a = s.index(a_m)
        b = s.index(b_m, a)
    except ValueError:
        fails.append(label)
        print("  ✗", label)
        return
    s = s[:a] + new + s[b:]
    print("  ✓", label)

rep('VERSION      = "v28"', 'VERSION      = "v30"', "version")
rep('EDITION      = "BLOOM EDITION"', 'EDITION      = "SANCTUARY EDITION"', "edition")

NEW_CYCLE = '''    def _sanct_type_in(self, text, started):
        el = (time.monotonic() - started) * 33.0
        n = int(el)
        return text[:max(0, min(len(text), n))]

    def _sanct_day_block(self, cv, cx, cy, num, t):
        dg = self._DIGL
        txt = str(num)
        rows = ["".join(r) for r in zip(*(dg[c] for c in txt if c in dg))] or ["   "]
        w = disp_width(rows[0])
        x0 = cx - w // 2
        sh = (t * 0.35) % 1.0
        for ry, line in enumerate(rows):
            for i, ch in enumerate(line):
                if ch == " ":
                    continue
                u = ((i + ry * 2) / float(max(1, w + 8)) + sh) % 1.0
                cv.set(x0 + i, cy + ry, ch, grad(u))

    def _sanct_mood_bar(self, cv, cx, cy, phase, t):
        w = 30
        x0 = cx - w // 2
        base = [C_RED, (60, 200, 100), C_GOLD, C_VIOLET][phase]
        for i in range(w):
            u = i / float(w - 1)
            c2 = mix(base, C_PINK, 0.5 + 0.5 * math.sin(u * 6.283 + t * 1.5))
            cv.set(x0 + i, cy, "━", scale(c2, 0.75 + 0.25 * math.sin(t * 2.0 + u * 6.0)))

    def _sanct_petal_rain(self, cv, W, H, t):
        for k in range(8):
            seed = k * 97.0
            x2 = (seed * 13.7 + t * (6.0 + k * 0.7)) % (W + 8) - 4
            y2 = (seed * 29.3 + t * (2.2 + k * 0.35)) % (H + 6) - 3
            sway = math.sin(t * 1.2 + k * 1.7) * 2.5
            xx = int(x2 + sway)
            yy = int(y2)
            if 1 <= yy < H - 2 and 2 <= xx < W - 3:
                ch2 = ["·", "✿", "·", "*"][k % 4]
                cv.set(xx, yy, ch2, scale(C_PINK, 0.16 + 0.10 * math.sin(t + k)))

    def handle_cycle_event(self, ev):
        kind, ch = ev[0], ev[1]
        cp = self.cpage_bloom
        if kind == "EOF":
            self.running = False
            return
        if cp.get("sev_for"):
            if kind in ("ESC", "CTRL_C"):
                cp["sev_for"] = None
                return
            if kind == "BACKSPACE":
                cp["sev_txt"] = cp.get("sev_txt", "")[:-1]
                return
            if kind == "CHAR" and ch and ch.isdigit():
                cp["sev_txt"] = (cp.get("sev_txt", "") + ch)[:1]
                return
            if kind == "ENTER":
                v = clamp(int(cp.get("sev_txt") or 3), 1, 5)
                dt = time.strftime("%Y-%m-%d")
                d = _pd_load()
                d["symptoms"][dt] = {"s": cp["sev_for"], "v": v}
                _pd_save(d)
                cp["msg"] = "✿ " + cp["sev_for"] + " " + str(v) + "/5 — take care ♡"
                cp["msg_t"] = time.monotonic()
                cp["sev_for"] = None
                cp["tab_open_t"] = time.monotonic()
                self.add_xp(1)
                return
            return
        if kind in ("CTRL_C", "CTRL_Q"):
            self.cpage_bloom = None
            return
        if kind == "ESC":
            if cp.get("sev_for"):
                cp["sev_for"] = None
            else:
                self.cpage_bloom = None
            return
        tab = cp.get("tab", 0)
        if kind in ("LEFT",):
            cp["tab"] = (tab - 1) % 4
            cp["tab_open_t"] = time.monotonic()
            cp["cal_sel"] = None
            return
        if kind in ("RIGHT",):
            cp["tab"] = (tab + 1) % 4
            cp["tab_open_t"] = time.monotonic()
            cp["cal_sel"] = None
            return
        if kind == "CHAR" and ch:
            low = ch.lower()
            tabs = {"t": 0, "c": 1, "i": 2, "w": 3}
            if low in tabs:
                cp["tab"] = tabs[low]
                cp["tab_open_t"] = time.monotonic()
                return
            if low == "q":
                self.cpage_bloom = None
                return
            if low == "s":
                dt = time.strftime("%Y-%m-%d")
                d = _pd_load()
                if d["starts"] and d["starts"][-1] == dt:
                    cp["msg"] = "aaj ka start already logged ✓"
                else:
                    d["starts"].append(dt)
                    d["starts"] = d["starts"][-24:]
                    _pd_save(d)
                    cp["msg"] = "🌷 start logged — take care ♡"
                    cp["confetti_t"] = time.monotonic()
                cp["msg_t"] = time.monotonic()
                cp["tab_open_t"] = time.monotonic()
                return
            if low == "e":
                dt = time.strftime("%Y-%m-%d")
                d = _pd_load()
                if d["ends"] and d["ends"][-1] == dt:
                    cp["msg"] = "aaj ka end already ✓"
                else:
                    d["ends"].append(dt)
                    d["ends"] = d["ends"][-24:]
                    _pd_save(d)
                    cp["msg"] = "🌷 end logged"
                cp["msg_t"] = time.monotonic()
                return
            if cp.get("tab") == 0 and ch.isdigit() and ch != "0":
                i2 = int(ch) - 1
                if i2 < len(SYMPTOMS):
                    cp["sev_for"] = SYMPTOMS[i2]
                    cp["sev_txt"] = ""
                return
        if cp.get("tab") == 1:
            if kind in ("UP", "DOWN", "LEFT", "RIGHT") or \
                    (kind == "CHAR" and ch in ("h", "j", "k", "l")):
                st2 = cp.setdefault("cal_state", {"off": 0, "dx": 0, "dy": 0})
                if kind == "UP" or (kind == "CHAR" and ch == "k"):
                    st2["dy"] -= 1
                elif kind == "DOWN" or (kind == "CHAR" and ch == "j"):
                    st2["dy"] += 1
                elif kind == "LEFT" or (kind == "CHAR" and ch == "h"):
                    st2["dx"] -= 1
                else:
                    st2["dx"] += 1
                cp["cal_sel"] = True
                return
            if kind == "ENTER" or (kind == "CHAR" and ch == " "):
                cp["msg"] = "day log: S/E use karo (aaj ke liye)"
                cp["msg_t"] = time.monotonic()
                return
            if kind == "CHAR" and ch in ("n", "m"):
                cp.setdefault("cal_state", {"off": 0, "dx": 0, "dy": 0})["off"] += 1
                return
            if kind == "CHAR" and ch == "p":
                cp.setdefault("cal_state", {"off": 0, "dx": 0, "dy": 0})["off"] -= 1
                return

    def build_cycle_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        b = C_TERM_BORDER
        cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", b)
        cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", b)
        for yy in range(1, H - 1):
            cv.put(0, yy, "│", b)
            cv.put(W - 1, yy, "│", b)
        self._sanct_petal_rain(cv, W, H, t)
        cp = self.cpage_bloom
        info = _cy_phase_of(self)
        tab = cp.get("tab", 0)
        tabs = (("today", "T"), ("calendar", "C"), ("insights", "I"), ("wheel", "W"))
        segs = []
        for i2, (nm, hot) in enumerate(tabs):
            cur = (i2 == tab)
            segs.append(("▸ " if cur else "  ", C_GOLD if cur else C_SLATE))
            segs.append((nm.upper() if cur else nm, C_GOLD if cur else C_DIM))
            segs.append(("   ", C_DIM))
        put_segs(cv, max(2, (W - disp_width("".join(x for x, _ in segs))) // 2), 1, segs)
        if cp.get("msg") and (time.monotonic() - cp.get("msg_t", 0)) < 4.0:
            m2 = "✿ " + cp["msg"]
            cv.put(max(2, (W - disp_width(m2)) // 2), 2, m2, C_GOLD)
        cx = W // 2
        if tab == 0:
            opent = cp.get("tab_open_t") or 0.0
            if info:
                ph = info["phase"]
                ph_name, ph_emoji, ph_msg = PHASES[ph]
                self._sanct_day_block(cv, cx, max(4, H // 2 - 10),
                                      info["days"], t)
                self._sanct_mood_bar(cv, cx, max(4, H // 2 - 10) + 6, ph, t)
                typed = self._sanct_type_in(ph_emoji + "  " + ph_name.upper(), opent + 0.2)
                cv.put(cx - disp_width(typed) // 2, max(4, H // 2 - 10) + 8, typed,
                       C_GOLD if ph == 2 else C_PINK)
                line1, line2 = ph_msg.split("—", 1) if "—" in ph_msg else (ph_msg, "")
                q1 = self._sanct_type_in("✿ " + line1.strip(), opent + 0.7)
                cv.put(cx - disp_width(q1) // 2, max(4, H // 2 - 10) + 10, q1, C_PINK)
                if line2:
                    q2 = self._sanct_type_in("✿ " + line2.strip(), opent + 1.2)
                    cv.put(cx - disp_width(q2) // 2, max(4, H // 2 - 10) + 11, q2, C_PINK)
                st = _pd_load()
                ds2 = []
                for i2 in range(1, min(len(st["starts"]), 7)):
                    a2p = _pd_parse(st["starts"][-i2])
                    b2p = _pd_parse(st["starts"][-i2 - 1])
                    if a2p and b2p:
                        dd = (time.mktime(a2p) - time.mktime(b2p)) / 86400.0
                        if 15 < dd < 60:
                            ds2.append(int(dd))
                sc = st.get("_streak_hint") or 0
                momo_face, momo_line = MOMO_CARE[PHASES[ph][0]]
                mtxt = "momo " + momo_face + "  " + momo_line
                mt = self._sanct_type_in(mtxt, opent + 1.8)
                cv.put(cx - disp_width(mt) // 2, max(4, H // 2 - 10) + 14, mt, C_LABEL)
                sym = st["symptoms"].get(time.strftime("%Y-%m-%d"))
                sy0 = max(4, H // 2 - 10) + 16
                cv.put(cx - 10, sy0, "♡ log symptom:", C_FUCHSIA)
                for i2, sm in enumerate(SYMPTOMS):
                    col = C_VALUE if sym and sym["s"] == sm else C_SLATE
                    tail = " " + str(sym["v"]) + "/5" if sym and sym["s"] == sm else ""
                    cv.put(cx - 10 + (i2 % 3) * 11, sy0 + 1 + i2 // 3,
                           str(i2 + 1) + "." + sm + tail, col)
                if cp.get("sev_for"):
                    cv.put(cx - 10, sy0 + 3, "severity 1-5: " +
                           cp.get("sev_txt", "") + "▌", C_GOLD)
            else:
                self._sanct_day_block(cv, cx, max(4, H // 2 - 8), 0, t)
                m2 = self._sanct_type_in("🌷 apna pehla cycle log karo — S dabao", opent)
                cv.put(cx - disp_width(m2) // 2, max(4, H // 2 - 2), m2, C_PINK)
        elif tab == 1:
            st2 = cp.setdefault("cal_state", {"off": 0, "dx": 0, "dy": 0})
            base = time.localtime()
            tot = base.tm_year * 12 + base.tm_mon - 1 + st2.get("off", 0)
            yy2, mm2 = tot // 12, (tot % 12) + 1
            try:
                import calendar as _cal
                grid = _cal.monthcalendar(yy2, mm2)
                mname = _cal.month_name[mm2]
            except Exception:
                grid = []
                mname = "?"
            mt2 = "← " + mname.upper() + " " + str(yy2) + " →"
            cv.put(cx - disp_width(mt2) // 2, 4, mt2, C_TITLE)
            d = _pd_load()
            marks = {}
            period_len = 5
            if d["ends"] and d["starts"]:
                lp = _pd_parse(d["starts"][-1])
                ep = _pd_parse(d["ends"][-1])
                if lp and ep:
                    period_len = clamp(int((time.mktime(ep) -
                                            time.mktime(lp)) / 86400.0) + 1, 2, 10)
            for st3 in d["starts"]:
                lp = _pd_parse(st3)
                if not lp:
                    continue
                for k in range(period_len):
                    tt2 = time.localtime(time.mktime(lp) + k * 86400.0)
                    if tt2.tm_year == yy2 and tt2.tm_mon == mm2:
                        marks[tt2.tm_mday] = "p"
            avg = _pd_avg_cycle(d["starts"]) if d["starts"] else 28
            if d["starts"]:
                lp = _pd_parse(d["starts"][-1])
                if lp:
                    nd = time.localtime(time.mktime(lp) + avg * 86400.0)
                    if nd.tm_year == yy2 and nd.tm_mon == mm2:
                        marks.setdefault(nd.tm_mday, "pred")
            heads = "Mo  Tu  We  Th  Fr  Sa  Su"
            cv.put(cx - disp_width(heads) // 2, 6, heads, C_LABEL)
            rowy = 8
            for wk in grid:
                segs2 = []
                for di, day in enumerate(wk):
                    if day == 0:
                        segs2.append(("    ", C_OUT))
                        continue
                    cell = "%2d" % day
                    if day in marks and marks[day] == "p":
                        segs2.append((cell + "🌷", C_RED))
                    elif marks.get(day) == "pred":
                        segs2.append((cell + "· ", C_GOLD))
                    elif day == base.tm_mday and mm2 == base.tm_mon:
                        segs2.append(("[" + cell + "]", C_WHITE))
                    else:
                        segs2.append((" " + cell + " ", C_OUT))
                put_segs(cv, cx - disp_width("".join(x for x, _ in segs2)) // 2,
                         rowy, segs2)
                rowy += 1
            leg = "🌷 logged    · predicted    [ ] aaj    n/p month"
            cv.put(cx - disp_width(leg) // 2, rowy + 1, leg, C_DIM)
        elif tab == 2:
            st = _pd_load()
            cv.put(cx - 8, 4, "◆ YOUR PATTERNS", C_TITLE)
            if len(st["starts"]) >= 2:
                ds2 = []
                for i2 in range(1, min(len(st["starts"]), 7)):
                    a2p = _pd_parse(st["starts"][-i2])
                    b2p = _pd_parse(st["starts"][-i2 - 1])
                    if a2p and b2p:
                        dd = (time.mktime(a2p) - time.mktime(b2p)) / 86400.0
                        if 15 < dd < 60:
                            ds2.append(int(dd))
                if ds2:
                    avgg = sum(ds2) // len(ds2)
                    reg = "✓ regular" if max(ds2) - min(ds2) <= 3 else "⚠ varying"
                    cv.put(cx - 10, 6, "avg cycle", C_LABEL)
                    cv.put(cx + 4, 6, str(avgg) + " days", C_GOLD)
                    cv.put(cx - 10, 7, "rhythm", C_LABEL)
                    cv.put(cx + 4, 7, reg, C_CYAN if "✓" in reg else C_GOLD)
                    cv.put(cx - 10, 9, "── recent cycles ──", C_SLATE)
                    rowy = 11
                    show = list(reversed(ds2))[:6]
                    for i2, dd in enumerate(show):
                        bw2 = clamp(dd, 8, 40)
                        lbl = time.strftime("%b", time.localtime(
                            time.mktime(_pd_parse(st["starts"][-1 - (len(show) - 1 - i2)]))))
                        cv.put(cx - 10, rowy, lbl.ljust(4), C_LABEL)
                        cv.put(cx - 5, rowy, "▓" * bw2, grad(i2 / max(1, len(show) - 1)))
                        cv.put(cx - 5 + bw2 + 1, rowy, str(dd) + "d", C_VALUE)
                        rowy += 1
                    rowy += 1
                    cv.put(cx - 10, rowy, "⚠ 3 mahine irregular? doctor",
                           scale(C_GOLD, 0.9))
                    cv.put(cx - 10, rowy + 1, "🔒 data sirf tere laptop me",
                           scale(C_SLATE, 0.9))
            else:
                m2 = "kam se kam 2 cycles ke baad patterns dikhenge"
                cv.put(cx - disp_width(m2) // 2, 8, m2, C_DIM)
        else:
            if info:
                frac = clamp(info["days"] / float(max(1, info["avg"])), 0.0, 1.0)
                ang_now = frac * 6.283 - 1.5708
                cx2, cy2 = cx, H // 2
                WR = min(9, (H - 12) // 2)
                for step in range(72):
                    a2 = step / 72.0 * 6.283 - 1.5708
                    ph = _pd_phase(int(step / 72.0 * info["avg"]) + 1,
                                   info["avg"], info["plen"])
                    rc = [C_RED, (60, 200, 100), C_GOLD, C_VIOLET][ph]
                    x2 = int(cx2 + math.cos(a2) * WR * 2.0)
                    y2 = int(cy2 + math.sin(a2) * WR)
                    done = a2 <= ang_now + 0.02
                    cv.set(x2, y2, "●" if done else "○",
                           scale(rc, 1.0 if done else 0.4))
                px2 = int(cx2 + math.cos(ang_now) * WR * 2.0)
                py2 = int(cy2 + math.sin(ang_now) * WR)
                cv.set(px2, py2, "✦", C_WHITE)
                dn = str(info["days"])
                cv.put(cx2 - disp_width(dn) // 2, cy2 - 1, dn, C_GOLD)
                cv.put(cx2 - 2, cy2, "DAYS", scale(C_SLATE, 0.85))
                for step in range(0, 72, 18):
                    a2 = step / 72.0 * 6.283 - 1.5708
                    ph = _pd_phase(int(step / 72.0 * info["avg"]) + 1,
                                   info["avg"], info["plen"])
                    ex = int(cx2 + math.cos(a2) * (WR + 2) * 2.0)
                    ey = int(cy2 + math.sin(a2) * (WR + 2))
                    cv.set(ex, ey, PHASES[ph][1][0], C_PINK)
            else:
                cv.put(cx - 8, H // 2, "koi data nahi — T pe S dabao", C_DIM)
        fy = H - 3
        if info:
            face, line = MOMO_CARE[PHASES[info["phase"]][0]]
        else:
            face, line = "( ^..^ )", "momo yahan hamesha rahegi ♡"
        cv.put(3, fy, face, C_PINK)
        cv.put(11, fy, clip(line, W - 15), C_LABEL)
        hint = "← → tabs • S start • E end • 1-8 log • Q exit"
        cv.put(max(2, (W - disp_width(hint)) // 2), H - 2, hint, C_SLATE)
        return cv.render()


'''

span("    def handle_cycle_event(self, ev):", "    def build_cycle_frame(self, t):",
     '''    def handle_cycle_event(self, ev):
        self.handle_cycle_event_v2(ev)

''', "route swap")

span("    def build_cycle_frame(self, t):",
     "# ───────────────────────────── self check / main",
     NEW_CYCLE, "sanctuary rebuild")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v285")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v30 PETAL SANCTUARY patched ✓  (backup: %s.bak-v285)" % P)
