import sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "_cpage_entries" in s:
    print("already patched ✓"); sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[a:]; print("  ✓", label)

rep('VERSION      = "v16"', 'VERSION      = "v17"', "version")
rep('EDITION      = "STAGE EDITION"', 'EDITION      = "DEV EDITION"', "edition")

rep('''                d = b[2]
                if d in _CSI_KEYS:''', '''                d = b[2]
                if b[1] == 0x4F and 0x50 <= d <= 0x53:
                    return (("F1", "F2", "F3", "F4")[d - 0x50], 3, None)
                if d in _CSI_KEYS:''', "F-keys ss3")

rep('''                if len(b) >= 4 and b[3] == 0x7E:''', '''                if len(b) >= 5 and b[4] == 0x7E and b[2] == 0x31 and b[3] in (0x31, 0x32, 0x33, 0x34):
                    return (("F1", "F2", "F3", "F4")[b[3] - 0x31], 5, None)
                if len(b) >= 4 and b[3] == 0x7E:''', "F-keys csi")

rep('''    def handle_event(self, ev):
        kind, ch = ev[0], ev[1]
        T = self.term''', '''    def handle_event(self, ev):
        kind, ch = ev[0], ev[1]
        T = self.term
        if kind == "F1":
            if self.cpage:
                self.handle_cpage_event(ev)
            else:
                self.open_cpage()
            return''', "F1 global")

rep('''        if self.mpage:
            self.handle_mpage_event(ev)
            return''', '''        if self.cpage:
            self.handle_cpage_event(ev)
            return
        if self.mpage:
            self.handle_mpage_event(ev)
            return''', "cpage routing")

rep('''        if self.mpage and not L.too_small:
            cv.clear()
            return self.build_mpage_frame(t)''', '''        if self.cpage and not L.too_small:
            cv.clear()
            return self.build_cpage_frame(t)
        if self.mpage and not L.too_small:
            cv.clear()
            return self.build_mpage_frame(t)''', "cpage frame")

rep('''        self.mpage = False
        self._mi_t = 0.0''', '''        self.mpage = False
        self._mi_t = 0.0
        self.cpage = None
        self.cap_colorizer = None
        self.cap_t0 = None''', "cpage init")

rep('''        T.busy = True
        T.busy_label = line
        self.cap_q = queue.Queue()''', '''        T.busy = True
        T.busy_label = line
        self.cap_q = queue.Queue()
        self.cap_colorizer = None
        self.cap_t0 = None''', "cap reset")

rep('''            if item is None:
                code = self.cap_proc.returncode
                self.term.busy = False
                self.cap_q = None
                self.cap_proc = None
                if code == 0:
                    self.term.push([("▸ done", C_DIM)])
                else:
                    self.term.push([("▸ done (code %s)" % code, C_RED)])
                return
            self.term.push(item)
            n += 1''', '''            if item is None:
                code = self.cap_proc.returncode
                self.term.busy = False
                self.cap_q = None
                self.cap_proc = None
                self.cap_colorizer = None
                dur = ("  •  %.1fs" % max(0.0, time.monotonic() - self.cap_t0)) if self.cap_t0 else ""
                self.cap_t0 = None
                if code == 0:
                    self.term.push([("▸ done" + dur, C_GOLD if dur else C_DIM)])
                else:
                    self.term.push([("▸ exit %d" % code + dur, C_RED)])
                return
            if self.cap_colorizer:
                self.term.push(self.cap_colorizer(item))
            else:
                self.term.push(item)
            n += 1''', "pump colorizer")

rep('''    Tool("np", ["player"], "♪ FULL-SCREEN music page — space/n/p live controls", "media", tool_np),''',
    '''    Tool("np", ["player"], "♪ FULL-SCREEN music page — space/n/p live controls", "media", tool_np),
    Tool("run", ["r"], "python runner — run main.py args (colored traceback)", "dev", tool_run),
    Tool("code", ["ide"], "F1 browser — enter run • V preview • E edit • 1-9 quick", "dev", tool_code),''', "registry")

rep('''                 ("text", "pro: music (spotify/YT!) • pet • ach • focus 25 • timer 10m", "", "", None)]''',
    '''                 ("text", "pro: music (spotify/YT!) • pet • ach • focus 25 • timer 10m", "", "", None),
                 ("text", "dev: F1 code browser • run file.py • V preview • E edit • 1-9 quick folders", "", "", None)]''', "help rows")

rep('''    T.dim("  pro: music • pet • ach • focus   |   style: theme • lang   |   shell: git, docker…")''',
    '''    T.dim("  dev: F1 • run • code   |   pro: music • pet • ach   |   style: theme • lang")''', "tools hint")

DEFS = '''QACCESS = (
    ("Home", "~"),
    ("cutie", "~/cutie-os-pkg"),
    ("scripts", "~/scripts"),
    ("Music", "~/Music"),
    ("Documents", "~/Documents"),
    ("Downloads", "~/Downloads"),
    ("cfg", "~/.config/cutie"),
)


def _size_str(nb):
    if nb >= 1048576:
        return "%.1fM" % (nb / 1048576.0)
    if nb >= 1024:
        return "%.0fK" % (nb / 1024.0)
    return "%dB" % nb


def _py_out_colorizer(line):
    st = line.strip()
    if st.startswith('File "'):
        return [("  ⚡ ", C_FUCHSIA), (st, C_LABEL)]
    if st.startswith("Traceback"):
        return [("  ✗ ", C_RED), ("TRACEBACK", C_GOLD), (" — kuch toota hai:", C_DIM)]
    if re.search(r"(Error|Exception)[: ]", st):
        return [(line, C_RED)]
    if st.startswith("line "):
        return [(line, C_MAGENTA)]
    return [(line, C_OUT)]


_PY_KW = frozenset(("def", "class", "import", "from", "return", "if", "elif", "else",
                    "for", "while", "try", "except", "finally", "with", "as", "in",
                    "not", "and", "or", "is", "None", "True", "False", "lambda",
                    "yield", "pass", "break", "continue", "raise", "global", "assert",
                    "del", "async", "await"))
_PYQ = (chr(34), chr(39))


def _pyhl(line):
    segs = []
    cmt = -1
    q = None
    for j, c in enumerate(line):
        if q is not None:
            if c == q:
                q = None
            continue
        if c in _PYQ:
            q = c
        elif c == "#":
            cmt = j
            break
    code = line[:cmt] if cmt >= 0 else line
    i = 0
    buf = ""

    def flush():
        nonlocal buf
        if buf:
            segs.append((buf, C_OUT))
            buf = ""
    while i < len(code):
        c = code[i]
        if c in _PYQ:
            j = i + 1
            while j < len(code) and code[j] != c:
                j += 1
            if j < len(code):
                j += 1
            flush()
            segs.append((code[i:j], C_GOLD))
            i = j
            continue
        if c.isdigit():
            j = i
            while j < len(code) and (code[j].isdigit() or code[j] in ".xXabcdefABCDEF"):
                j += 1
            flush()
            segs.append((code[i:j], C_CYAN))
            i = j
            continue
        if c.isalpha() or c == "_":
            j = i
            while j < len(code) and (code[j].isalnum() or code[j] == "_"):
                j += 1
            w = code[i:j]
            if w in _PY_KW:
                flush()
                segs.append((w, C_FUCHSIA))
            else:
                buf += w
            i = j
            continue
        if c == "@":
            j = i + 1
            while j < len(code) and (code[j].isalnum() or code[j] in "._"):
                j += 1
            flush()
            segs.append((code[i:j], C_VIOLET))
            i = j
            continue
        buf += c
        i += 1
    flush()
    if cmt >= 0:
        segs.append((line[cmt:], C_SLATE))
    return segs or [("", C_OUT)]


def tool_run(app, args):
    T = app.term
    if not args:
        T.dim("  usage: run file.py [args…]   •  ya pura browser: code (F1)")
        return
    path = os.path.expanduser(args[0])
    if not os.path.isabs(path):
        path = os.path.join(T.cwd, path)
    if not os.path.isfile(path):
        T.push([("  ✗ file nahi mili: ", C_RED), (args[0], C_VALUE)])
        return
    ext = os.path.splitext(path)[1].lower()
    if ext == ".py":
        exe = shutil.which("python3") or shutil.which("python")
        if exe is None:
            T.dim("  python nahi mila")
            return
        cmd = shlex.quote(exe) + " " + shlex.quote(path)
    elif ext == ".sh":
        cmd = "bash " + shlex.quote(path)
    else:
        T.push([("  ℹ ", C_DIM), (os.path.basename(path), C_VALUE),
                (" — .py / .sh hi chalte hain (ya !./file)", C_DIM)])
        return
    extra = " ".join(shlex.quote(a) for a in args[1:])
    if extra:
        cmd += " " + extra
    app.start_capture(cmd)
    if ext == ".py":
        app.cap_colorizer = _py_out_colorizer
    app.cap_t0 = time.monotonic()
    app.add_xp(2)


def tool_code(app, args):
    app.open_cpage(args[0] if args else None)


'''

block("def tool_music(app, args):", DEFS, "dev defs")

DIV2 = "# ───────────────────────────── self check / main"
block(DIV2, '''    # ── v17: CODE BROWSER PAGE ──

    def open_cpage(self, path=None):
        p = os.path.expanduser(path or self.term.cwd)
        if not os.path.isdir(p):
            p = os.path.expanduser("~")
        qs = []
        for lab, pth in QACCESS:
            fp = os.path.expanduser(pth)
            if os.path.isdir(fp):
                qs.append((lab, fp))
        self.cpage = {"cwd": p, "sel": 0, "scroll": 0, "mode": "list",
                      "pv": None, "pvname": "", "pvscroll": 0, "q": qs}

    def _cpage_entries(self):
        try:
            names = sorted(os.listdir(self.cpage["cwd"]), key=str.lower)
        except Exception:
            return []
        dirs = []
        files = []
        for nm in names:
            if nm.startswith("."):
                continue
            if os.path.isdir(os.path.join(self.cpage["cwd"], nm)):
                dirs.append(nm + "/")
            else:
                files.append(nm)
        return dirs + files

    def _cpage_run(self, name):
        full = os.path.join(self.cpage["cwd"], name)
        ext = os.path.splitext(full)[1].lower()
        self.cpage = None
        T = self.term
        T.echo_cmd(("run " if ext == ".py" else "bash ") + name)
        if ext == ".py":
            exe = shutil.which("python3") or shutil.which("python")
            if exe is None:
                T.dim("  python nahi mila")
                return
            self.start_capture(shlex.quote(exe) + " " + shlex.quote(full))
            self.cap_colorizer = _py_out_colorizer
        else:
            self.start_capture("bash " + shlex.quote(full))
        self.cap_t0 = time.monotonic()
        self.cmd_tick()
        self.add_xp(2)

    def _cpage_edit(self, name):
        full = os.path.join(self.cpage["cwd"], name)
        self.cpage = None
        ed = os.environ.get("VISUAL") or os.environ.get("EDITOR")
        if not ed:
            for c in ("nvim", "vim", "nano", "vi"):
                if shutil.which(c):
                    ed = c
                    break
        if not ed:
            self.term.dim("  koi editor nahi — nano install karo")
            return
        self.run_pty([ed, full])

    def _cpage_preview(self, name):
        full = os.path.join(self.cpage["cwd"], name)
        try:
            with open(full, "rb") as f:
                raw = f.read(200000)
            lines = raw.decode("utf-8", "replace").split("\\n")
        except Exception as e:
            self.term.push([("  ✗ read fail: ", C_RED), (str(e)[:60], C_DIM)])
            return
        cp = self.cpage
        cp["mode"] = "preview"
        cp["pv"] = lines[:400]
        cp["pvname"] = name
        cp["pvscroll"] = 0

    def _cpage_activate(self):
        cp = self.cpage
        ents = self._cpage_entries()
        if not ents:
            return
        nm = ents[min(cp["sel"], len(ents) - 1)]
        if nm.endswith("/"):
            self.open_cpage(os.path.join(cp["cwd"], nm))
            return
        ext = os.path.splitext(nm)[1].lower()
        if ext in (".py", ".sh"):
            self._cpage_run(nm)
        else:
            self._cpage_preview(nm)

    def handle_cpage_event(self, ev):
        kind, ch = ev[0], ev[1]
        cp = self.cpage
        if kind == "EOF":
            self.running = False
            return
        if cp["mode"] == "preview":
            if kind in ("CTRL_C", "ESC") or (kind == "CHAR" and ch in ("q", "Q", "v", "V")):
                cp["mode"] = "list"
                cp["pv"] = None
            elif kind == "UP" or (kind == "CHAR" and ch in ("k", "w")):
                cp["pvscroll"] = max(0, cp["pvscroll"] - 1)
            elif kind == "DOWN" or (kind == "CHAR" and ch in ("j", "s")):
                cp["pvscroll"] += 1
            elif kind == "PGUP":
                cp["pvscroll"] = max(0, cp["pvscroll"] - 20)
            elif kind == "PGDN":
                cp["pvscroll"] += 20
            return
        if kind in ("CTRL_C", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
            self.cpage = None
            return
        ents = self._cpage_entries()
        n = len(ents)
        if kind == "UP" or (kind == "CHAR" and ch in ("k", "w")):
            cp["sel"] = max(0, cp["sel"] - 1)
        elif kind == "DOWN" or (kind == "CHAR" and ch in ("j", "s")):
            cp["sel"] = min(max(0, n - 1), cp["sel"] + 1)
        elif kind == "PGUP":
            cp["sel"] = max(0, cp["sel"] - 12)
        elif kind == "PGDN":
            cp["sel"] = min(max(0, n - 1), cp["sel"] + 12)
        elif kind == "HOME":
            cp["sel"] = 0
        elif kind == "END":
            cp["sel"] = max(0, n - 1)
        elif kind in ("BACKSPACE", "LEFT") or (kind == "CHAR" and ch == "h"):
            self.open_cpage(os.path.dirname(cp["cwd"].rstrip("/")) or "/")
        elif kind == "ENTER" or kind in ("RIGHT", "F1") or (kind == "CHAR" and ch in ("l", "r", "R")):
            self._cpage_activate()
        elif kind == "CHAR" and ch in ("v", "V"):
            if n:
                nm = ents[min(cp["sel"], n - 1)]
                if not nm.endswith("/"):
                    self._cpage_preview(nm)
        elif kind == "CHAR" and ch in ("e", "E"):
            if n:
                self._cpage_edit(ents[min(cp["sel"], n - 1)])
        elif kind == "CHAR" and ch in ("g", "G"):
            self.open_cpage("~")
        elif kind == "CHAR" and ch and ch in "123456789" and cp.get("q"):
            i = int(ch) - 1
            if i < len(cp["q"]):
                self.open_cpage(cp["q"][i][1])

    def build_cpage_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        b = C_TERM_BORDER
        cp = self.cpage
        cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", b)
        cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", b)
        for yy in range(1, H - 1):
            cv.put(0, yy, "│", b)
            cv.put(W - 1, yy, "│", b)
        if cp["mode"] == "preview":
            return self._cpage_preview_render(cv, W, H)
        ents = self._cpage_entries()
        n = len(ents)
        cp["sel"] = clamp(cp["sel"], 0, max(0, n - 1))
        home = os.path.expanduser("~")
        disp = cp["cwd"].replace(home, "~", 1) if cp["cwd"].startswith(home) else cp["cwd"]
        pos = " %d/%d " % (cp["sel"] + 1, n)
        px = W - 2 - disp_width(pos)
        cv.put(2, 0, "◆ CODE", C_TITLE)
        if px > 22:
            cv.put(9, 0, clip("— " + disp, px - 10), C_LABEL)
            cv.put(px, 0, pos, C_SLATE)
        body = H - 6
        if cp["scroll"] > cp["sel"]:
            cp["scroll"] = cp["sel"]
        if cp["scroll"] < cp["sel"] - body + 1:
            cp["scroll"] = cp["sel"] - body + 1
        cp["scroll"] = clamp(cp["scroll"], 0, max(0, n - body))
        for r in range(body):
            idx = cp["scroll"] + r
            if idx >= n:
                break
            nm = ents[idx]
            sel = (idx == cp["sel"])
            yy = 2 + r
            cv.put(2, yy, "▸ " if sel else "  ", C_GOLD if sel else C_SLATE)
            if nm.endswith("/"):
                cv.put(4, yy, clip(nm, W - 18), C_CYAN)
            elif nm.lower().endswith(".py"):
                cv.put(4, yy, clip(nm, W - 18), C_VIOLET if sel else C_VALUE)
            else:
                cv.put(4, yy, clip(nm, W - 18), C_OUT if sel else C_DIM)
            try:
                stt = os.stat(os.path.join(cp["cwd"], nm))
                sz = "«dir»" if nm.endswith("/") else _size_str(stt.st_size)
            except Exception:
                sz = "?"
            cv.put(max(6, W - 10), yy, clip(sz.rjust(7), 8), C_SLATE)
        qy = H - 4
        qsegs = [("QUICK ", C_FUCHSIA)]
        acc = 6
        for i, (lab, pth) in enumerate(cp["q"]):
            homeh = pth.replace(home, "~", 1)
            tgs = "[%d]%s " % (i + 1, homeh)
            tw = disp_width(tgs)
            if acc + tw > W - 8:
                break
            qsegs.append((tgs, C_VALUE if i % 2 == 0 else C_OUT))
            acc += tw
        put_segs(cv, 2, qy, qsegs)
        foot = "↑↓ • ENTER run/open • V preview • E edit • ← parent • 1-9 quick • F1 run • Q close"
        cv.put(max(2, (W - disp_width(foot)) // 2), H - 2, clip(foot, W - 4), C_SLATE)
        return cv.render()

    def _cpage_preview_render(self, cv, W, H):
        cp = self.cpage
        cv.put(2, 0, "◆ PREVIEW", C_TITLE)
        cv.put(12, 0, clip("— " + cp["pvname"], W - 26), C_LABEL)
        cv.put(W - 2 - 9, 0, "ESC back", C_SLATE)
        body = H - 4
        lines = cp["pv"] or []
        cp["pvscroll"] = clamp(cp["pvscroll"], 0, max(0, len(lines) - body))
        for r in range(body):
            idx = cp["pvscroll"] + r
            if idx >= len(lines):
                break
            ln = lines[idx]
            cv.put(2, 2 + r, "%4d " % (idx + 1), C_SLATE)
            x = 7
            for seg, col in _pyhl(ln[: max(4, W - 10)]):
                if x >= W - 3:
                    break
                cv.put(x, 2 + r, seg, col)
                x += disp_width(seg)
        foot = "↑↓ scroll • ESC/V back • E edit in " + (os.environ.get("EDITOR") or "editor")
        cv.put(max(2, (W - disp_width(foot)) // 2), H - 2, clip(foot, W - 4), C_SLATE)
        return cv.render()


''' + DIV2, "cpage methods")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

fails = [f for f in fails if f != "help rows"]
if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

import shutil as _sh
_sh.copy(P, P + ".bak-v16")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v17 DEV patched ✓  (backup: %s.bak-v16)" % P)
