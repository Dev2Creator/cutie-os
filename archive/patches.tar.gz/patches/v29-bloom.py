import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "build_cycle_frame" in s:
    print("already patched ✓")
    sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label)
        print("  ✗", label)
        return
    s = s.replace(old, new, 1)
    print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label)
        print("  ✗", label)
        return
    s = s[:a] + new + s[a:]
    print("  ✓", label)

rep('VERSION      = "v27.5"', 'VERSION      = "v28"', "version")
rep('EDITION      = "CARE EDITION"', 'EDITION      = "BLOOM EDITION"', "edition")

rep('''        if self.epage:
            self.handle_epage_event(ev)
            return''', '''        if self.cpage_bloom:
            self.handle_cycle_event(ev)
            return
        if self.epage:
            self.handle_epage_event(ev)
            return''', "cycle routing")

rep('''        if self.epage and not L.too_small:
            cv.clear()
            return self.build_epage_frame(t)''', '''        if self.cpage_bloom:
            cv.clear()
            return self.build_cycle_frame(t)
        if self.epage and not L.too_small:
            cv.clear()
            return self.build_epage_frame(t)''', "cycle frame")

rep('''        self.tpage = None''', '''        self.tpage = None
        self.cpage_bloom = None''', "cycle init")

rep('''    Tool("cal", ["calendar"], "CUTIE calendar — dots, predictions, cute", "life", tool_cal),''',
    '''    Tool("cal", ["calendar"], "CUTIE calendar — dots, predictions, cute", "life", tool_cal),
    Tool("cycle", ["periodpage"], "FULL-SCREEN cycle wheel page 🌸", "life", tool_cyclepage),''',
    "cycle registry")

BLOCK1 = '''CYCLE_TIPS = {
    "menstrual": ("garam pani bottle rakho", "dark chocolate allowed ✿",
                  "halki stretch, heavy workout nahi", "khud se soft baat karo"),
    "follicular": ("naya project shuru karne ka best time",
                   "protein khao, energy badhegi", "workout PR try karo",
                   "social plans bana lo"),
    "ovulation": ("sabse confident din — interview? presentation?",
                  "hydration zyada rakhna", "creative kaam karo",
                  "duniya ghoomne le jao khud ko"),
    "luteal": ("magnesium-rich khana (dry fruits)", "raat ko jaldi sona",
               "journaling karo, emotions valid hai", "caffeine thoda kam"),
}

MOMO_CARE = {
    "menstrual": ("( u_u )", "momo garam pani leke aa gayi... take care ♡"),
    "follicular": ("( ^ω^ )", "momo: energy dekh! aaj kuch bada karte hai!"),
    "ovulation": ("> ω < ", "momo: tu aaj itni GLOW kar rahi hai!!"),
    "luteal": ("( =ω= )", "momo: blanket, chai, aur ek movie?"),
}


def tool_cyclepage(app, args):
    app.cpage_bloom = {"mini": None, "msg": "", "msg_t": 0.0,
                       "month_off": 0, "sev_for": None}


def _cy_phase_of(app):
    d = _pd_load()
    if not d["starts"]:
        return None
    avg = _pd_avg_cycle(d["starts"])
    lp = _pd_parse(d["starts"][-1])
    if not lp:
        return None
    days = max(1, int((time.mktime(time.localtime()) -
                       time.mktime(lp)) / 86400.0) + 1)
    period_len = 5
    if d["ends"]:
        ep = _pd_parse(d["ends"][-1])
        if ep:
            period_len = clamp(int((time.mktime(ep) -
                                    time.mktime(lp)) / 86400.0) + 1, 2, 10)
    return {"d": d, "days": days, "avg": avg, "plen": period_len,
            "phase": _pd_phase(days, avg, period_len)}


'''

block("def tool_cal(app, args):", BLOCK1, "cycle data")

DIV2 = "# ───────────────────────────── self check / main"
block(DIV2, '''    # ── v28: BLOOM PAGE ──

    def handle_cycle_event(self, ev):
        kind, ch = ev[0], ev[1]
        cp = self.cpage_bloom
        if kind == "EOF":
            self.running = False
            return
        if cp.get("sev_for"):
            if kind in ("ESC", "CTRL_C"):
                cp["sev_for"] = None
                return
            if kind == "BACKSPACE":
                cp["sev_txt"] = cp.get("sev_txt", "")[:-1]
                return
            if kind == "CHAR" and ch and ch.isdigit():
                cp["sev_txt"] = (cp.get("sev_txt", "") + ch)[:1]
                return
            if kind == "ENTER":
                v = clamp(int(cp.get("sev_txt") or 3), 1, 5)
                dt = time.strftime("%Y-%m-%d")
                d = _pd_load()
                d["symptoms"][dt] = {"s": cp["sev_for"], "v": v}
                _pd_save(d)
                cp["msg"] = "✓ " + cp["sev_for"] + " " + str(v) + "/5 logged — take care ♡"
                cp["msg_t"] = time.monotonic()
                cp["sev_for"] = None
                self.add_xp(1)
                return
            return
        if kind == "CHAR" and ch and ch.isdigit() and ch != "0":
            sym = SYMPTOMS[int(ch) - 1]
            cp["sev_for"] = sym
            cp["sev_txt"] = ""
            return
        if kind in ("CTRL_C", "CTRL_Q", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
            self.cpage_bloom = None
            return
        if kind == "CHAR" and ch in ("s", "S"):
            dt = time.strftime("%Y-%m-%d")
            d = _pd_load()
            if d["starts"] and d["starts"][-1] == dt:
                cp["msg"] = "aaj ka start already logged ✓"
            else:
                d["starts"].append(dt)
                d["starts"] = d["starts"][-24:]
                _pd_save(d)
                cp["msg"] = "🌺 start logged — take care ♡"
                self.add_xp(2)
            cp["msg_t"] = time.monotonic()
            return
        if kind == "CHAR" and ch in ("e", "E"):
            dt = time.strftime("%Y-%m-%d")
            d = _pd_load()
            if d["ends"] and d["ends"][-1] == dt:
                cp["msg"] = "aaj ka end already ✓"
            else:
                d["ends"].append(dt)
                d["ends"] = d["ends"][-24:]
                _pd_save(d)
                cp["msg"] = "🌷 end logged"
                self.add_xp(2)
            cp["msg_t"] = time.monotonic()
            return
        if kind in ("LEFT", "CHAR") and (kind == "LEFT" or ch in ("p", "P")):
            cp["month_off"] = cp.get("month_off", 0) - 1
        elif kind in ("RIGHT", "CHAR") and (kind == "RIGHT" or ch in ("n", "N")):
            cp["month_off"] = cp.get("month_off", 0) + 1

    def build_cycle_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        b = C_TERM_BORDER
        cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", b)
        cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", b)
        for yy in range(1, H - 1):
            cv.put(0, yy, "│", b)
            cv.put(W - 1, yy, "│", b)
        for k in range(6):
            sx = (k * 71 + int(t * 1.4) + k * k * 13) % max(4, W - 6) + 3
            sy = (k * 37 + int(t * 0.8)) % max(1, H - 6) + 2
            cv.set(sx, sy, "✦", scale(C_PINK, 0.30 + 0.13 * math.sin(t * 1.7 + k)))
        cp = self.cpage_bloom
        title = "✿ CYCLE BLOOM ✿"
        cv.put(max(2, (W - disp_width(title)) // 2), 1, title, C_TITLE)
        info = _cy_phase_of(self)
        left_w = 30 if W >= 100 else 0
        wx = 2
        wy = 3
        WR = 9
        cx = wx + WR + 2
        cy = wy + WR + 1
        if info:
            days = info["days"]
            avg = info["avg"]
            frac = clamp(days / float(max(1, avg)), 0.0, 1.0)
            ang_now = frac * 6.283 - 1.5708
            ring = []
            for step in range(72):
                a2 = step / 72.0 * 6.283 - 1.5708
                ph = _pd_phase(int(step / 72.0 * avg) + 1, avg, info["plen"])
                if ph == 0:
                    rc = C_RED
                elif ph == 1:
                    rc = (60, 200, 100)
                elif ph == 2:
                    rc = C_GOLD
                else:
                    rc = C_VIOLET
                x2 = int(cx + math.cos(a2) * WR * 2.0)
                y2 = int(cy + math.sin(a2) * WR)
                done = (a2 <= ang_now + 0.02)
                cv.set(x2, y2, "●" if done else "○",
                       scale(rc, 1.0 if done else 0.45))
                ring.append((x2, y2, rc, done))
            for step in range(0, 72, 18):
                a2 = step / 72.0 * 6.283 - 1.5708
                ph = _pd_phase(int(step / 72.0 * avg) + 1, avg, info["plen"])
                ex = int(cx + math.cos(a2) * (WR + 2) * 2.0)
                ey = int(cy + math.sin(a2) * (WR + 2))
                cv.set(ex, ey, PHASES[ph][1][0], PHASES[ph][1].__class__ and
                       scale(C_WHITE, 1.0) if False else C_PINK)
            px2 = int(cx + math.cos(ang_now) * WR * 2.0)
            py2 = int(cy + math.sin(ang_now) * WR)
            glow = "✦" if (t % 1.0) < 0.6 else "✧"
            cv.set(px2, py2, glow, C_WHITE)
            dn = str(days)
            cv.put(cx - disp_width(dn) // 2, cy - 1, dn, C_GOLD)
            cv.put(cx - 2, cy, "DAYS", scale(C_SLATE, 0.85))
            cv.put(cx - 1, cy + 2, "of " + str(avg), scale(C_SLATE, 0.7))
        else:
            cv.put(wx + 4, cy, "koi data nahi — S dabao", C_DIM)
        if left_w:
            ry2 = wy
            cv.put(wx, ry2, "◆ PHASES", C_TITLE)
            ry2 += 2
            cur_ph = info["phase"] if info else -1
            for i2, (pn, pe, _m) in enumerate(PHASES):
                cur = (i2 == cur_ph)
                mark2 = "●" if cur else "○"
                cv.put(wx, ry2, mark2 + " ", C_PINK if cur else C_SLATE)
                cv.put(wx + 2, ry2, pe + " " + pn,
                       C_VALUE if cur else C_DIM)
                ry2 += 1
        ry3 = 3
        rx2 = wx + (left_w + 6 if left_w else 0) + 2 * WR + 4
        if rx2 < W - 20:
            cv.put(rx2, ry3, "◆ TODAY", C_TITLE)
            ry3 += 1
            if info:
                ph_name, ph_emoji, ph_msg = PHASES[info["phase"]]
                cv.put(rx2, ry3, ph_emoji + " " + ph_name, C_GOLD)
                ry3 += 1
                cv.put(rx2, ry3, clip(ph_msg, W - rx2 - 4), C_PINK)
                ry3 += 2
                cv.put(rx2, ry3, "◆ SELF-CARE", C_FUCHSIA)
                ry3 += 1
                for tip in CYCLE_TIPS[PHASES[info["phase"]][0]][:4]:
                    cv.put(rx2, ry3, "✿ " + tip[: max(8, W - rx2 - 6)], C_LABEL)
                    ry3 += 1
                ry3 += 1
                sym = info["d"]["symptoms"].get(time.strftime("%Y-%m-%d"))
                cv.put(rx2, ry3, "◆ LOG SYMPTOM (1-8)", C_FUCHSIA)
                ry3 += 1
                for i2, sm in enumerate(SYMPTOMS):
                    col = C_VALUE if sym and sym["s"] == sm else C_SLATE
                    tail = (" " + str(sym["v"]) + "/5" if sym and sym["s"] == sm else "")
                    cv.put(rx2 + (i2 % 2) * 13, ry3 + i2 // 2,
                           str(i2 + 1) + "." + sm[:10] + tail, col)
                ry3 += (len(SYMPTOMS) + 1) // 2 + 1
                if cp.get("sev_for"):
                    cv.put(rx2, ry3, "severity 1-5: " + cp.get("sev_txt", "") + "▌",
                           C_GOLD)
                    ry3 += 1
                hist = info["d"]["starts"]
                if len(hist) >= 3:
                    ds2 = []
                    for i2 in range(1, min(len(hist), 7)):
                        a2p = _pd_parse(hist[-i2])
                        b2p = _pd_parse(hist[-i2 - 1])
                        if a2p and b2p:
                            dd = (time.mktime(a2p) - time.mktime(b2p)) / 86400.0
                            if 15 < dd < 60:
                                ds2.append(int(dd))
                    if ds2:
                        reg = "✓ regular" if max(ds2) - min(ds2) <= 3 else "⚠ varying"
                        cv.put(rx2, ry3, "◆ INSIGHTS", C_FUCHSIA)
                        cv.put(rx2, ry3 + 1,
                               clip("avg %dd • %s • %d tracked" %
                                    (sum(ds2) // len(ds2), reg, len(hist)),
                                    W - rx2 - 4), C_LABEL)
        fy = H - 3
        face, line = MOMO_CARE[PHASES[info["phase"]][0]] if info else \
            ("( ^..^ )", "momo: S se start log karo!")
        cv.put(3, fy, face, C_PINK)
        cv.put(11, fy, clip(line, W - 15), C_LABEL)
        msg = cp.get("msg") or ""
        if msg and (time.monotonic() - cp.get("msg_t", 0)) < 4.0:
            cv.put(max(2, (W - disp_width(msg)) // 2), H - 5, msg, C_GOLD)
        foot = "S start • E end • 1-8 symptom • N/P month • Q exit"
        cv.put(max(2, (W - disp_width(foot)) // 2), H - 2, foot, C_SLATE)
        return cv.render()


''' + DIV2, "cycle page methods")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v275")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v28 BLOOM patched ✓  (backup: %s.bak-v275)" % P)
