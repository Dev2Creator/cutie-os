import sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "_konami_on" in s:
    print("already patched ✓"); sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[a:]; print("  ✓", label)

rep('VERSION      = "v13"', 'VERSION      = "v14"', "version")
rep('EDITION      = "GOAT EDITION"', 'EDITION      = "PRO EDITION"', "edition")

rep('''def os_pretty():
    try:''', '''def os_pretty():
    if os.environ.get("TERMUX_VERSION"):
        return "Android • Termux"
    try:''', "termux os")

rep('''        if n > 0:
            return str(n)
    except Exception:
        pass
    return "N/A"''', '''        if n > 0:
            return str(n)
    except Exception:
        pass
    out = _cap("dpkg -l 2>/dev/null | grep -c '^ii'", 8)
    if out.strip().isdigit() and int(out.strip()) > 0:
        return out.strip() + " (deb)"
    return "N/A"''', "dpkg pkg")

rep('''    if bat is not None:
        return bat
    if ac_online:
        return ("AC", "AC")
    return None''', '''    if bat is not None:
        return bat
    if ac_online:
        return ("AC", "AC")
    out = run_cmd(["termux-battery-status"], 4)
    try:
        j = json.loads(out)
        return (int(j.get("percentage", 0)), str(j.get("status", "?")))
    except Exception:
        pass
    return None''', "termux battery")

rep('''def tool_notify(app, args):
    T = app.term
    msg = " ".join(args) if args else "cutie says hi ✦"
    if shutil.which("notify-send") is None:''', '''def tool_notify(app, args):
    T = app.term
    msg = " ".join(args) if args else "cutie says hi ✦"
    if app.is_termux and shutil.which("termux-notification"):
        subprocess.run(["termux-notification", "--title", "✦ CUTIE", "--content", msg],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=6)
        T.push([("  sent » ", C_DIM), (msg, C_VALUE)])
        return
    if shutil.which("notify-send") is None:''', "termux notify")

rep('''        self.hist_cpu = [0] * 18
        self.cpu_pct = 0.0
        self._last_stat = None''', '''        self.hist_cpu = [0] * 18
        self.cpu_pct = 0.0
        self._last_stat = None
        self.net_rx = 0.0
        self.net_tx = 0.0
        self._last_net = None
        self._last_net_t = 0.0''', "net init")

rep('''        self.hist_cpu.append(self.cpu_pct)
        if len(self.hist_cpu) > 18:
            del self.hist_cpu[: len(self.hist_cpu) - 18]''', '''        self.hist_cpu.append(self.cpu_pct)
        if len(self.hist_cpu) > 18:
            del self.hist_cpu[: len(self.hist_cpu) - 18]
        nb = net_bytes()
        now = time.monotonic()
        if nb and self._last_net and now > self._last_net_t:
            dt = now - self._last_net_t
            self.net_rx = max(0.0, (nb[0] - self._last_net[0]) / max(0.001, dt))
            self.net_tx = max(0.0, (nb[1] - self._last_net[1]) / max(0.001, dt))
        else:
            self.net_rx = 0.0
            self.net_tx = 0.0
        if nb:
            self._last_net = nb
            self._last_net_t = now''', "net hist")

rep('''        if self.info.temp is not None:
            tc = self.info.temp
            segs += [("%.0f°C" % tc, C_CYAN if tc < 60 else (C_GOLD if tc < 78 else C_RED))]
        total = disp_width("".join(x for x, _ in segs))''', '''        if self.info.temp is not None:
            tc = self.info.temp
            segs += [("%.0f°C" % tc, C_CYAN if tc < 60 else (C_GOLD if tc < 78 else C_RED))]
        if getattr(self.info, "net_rx", 0.0) > 1.0:
            segs += [("  ↓", C_CYAN), (fmt_speed(self.info.net_rx), C_VALUE),
                     (" ↑", C_FUCHSIA), (fmt_speed(self.info.net_tx), C_VALUE)]
        total = disp_width("".join(x for x, _ in segs))''', "net power row")

rep('''        fps_s = "%3.0f FPS" % min(999.0, self.fps)''', '''        if self.timer_until is not None:
            rem = max(0, int(self.timer_until - t))
            fps_s = "⏳ %02d:%02d" % (rem // 60, rem % 60)
        else:
            fps_s = "%3.0f FPS" % min(999.0, self.fps)''', "timer header")

rep('''        plain = "● ONLINE" + sep + fps_s + sep + clock
        x = W - 2 - disp_width(plain)
        if x >= 30:
            put_segs(cv, x, ry, [("● ", pulse), ("ONLINE", C_VALUE),
                                 (sep + fps_s, C_DIM), (sep + clock, C_DIM)])
        elif x >= 14:
            put_segs(cv, x, ry, [("● ", pulse), ("ONLINE", C_VALUE)])''', '''        parts_r = []
        if self.level() > 1:
            parts_r += [("◆ ", C_GOLD), ("L%d" % self.level(), C_GOLD), (sep, C_DIM)]
        parts_r += [("● ", pulse), ("ONLINE", C_VALUE),
                    (sep + fps_s, C_DIM), (sep + clock, C_DIM)]
        plain = "".join(tt for tt, _ in parts_r)
        x = W - 2 - disp_width(plain)
        if x >= 30:
            put_segs(cv, x, ry, parts_r)
        elif x >= 14:
            put_segs(cv, x, ry, [("● ", pulse), ("ONLINE", C_VALUE)])
        mi = getattr(self, "music_info", None)
        if mi and mi.get("title"):
            rlen = disp_width("● ONLINE" + sep + "888 FPS" + sep + "00:00:00")
            if self.level() > 1:
                rlen += 8
            avail = W - 2 - rlen - 32
            if avail >= 14:
                song = clip("%s — %s" % (mi.get("artist") or "?", mi["title"]), avail)
                sym = {"Playing": "▶", "Paused": "❚❚"}.get(mi.get("status", ""), "♪")
                put_segs(cv, 30, ry, [(sym + " ", C_CYAN), ("♪ ", C_FUCHSIA), (song, C_LABEL)])''', "header lvl+music")

rep('''                if t - self.last_info >= 2.0:
                    self.last_info = t
                    self.info.refresh_dynamic()
                    self.info.rebuild_ui(self.layout)''', '''                if t - self.last_info >= 2.0:
                    self.last_info = t
                    self.info.refresh_dynamic()
                    self.info.rebuild_ui(self.layout)
                    self._music_tick()
                    self._timer_tick(t)
                if self.confetti:
                    self._confetti_tick(dt)''', "main tick")

rep('''        self.draw_term(cv, L, t)
        self.draw_hints(cv, L)
        return cv.render()''', '''        self.draw_term(cv, L, t)
        self.draw_hints(cv, L)
        self._draw_confetti(cv, t)
        return cv.render()''', "confetti draw")

rep('''        if self.help is not None:
            self.handle_help_event(ev)
            return''', '''        _kseq = {"UP": "u", "DOWN": "d", "LEFT": "l", "RIGHT": "r"}
        if kind in _kseq:
            self.konami = (self.konami + _kseq[kind])[-10:]
        elif kind == "CHAR" and ch:
            self.konami = (self.konami + ch.lower())[-10:]
        if self.konami.endswith("uuddlrlrba"):
            self.konami = ""
            self._konami_on()
        if self.help is not None:
            self.handle_help_event(ev)
            return''', "konami track")

rep('''        if line.strip():
            T.history.append(line)
            if len(T.history) > HIST_CAP:
                del T.history[: len(T.history) - HIST_CAP]''', '''        if line.strip():
            T.history.append(line)
            if len(T.history) > HIST_CAP:
                del T.history[: len(T.history) - HIST_CAP]
            self.add_xp(3)
            self.cmd_tick()''', "xp submit")

rep('''        tool = TOOL_MAP.get(cmd)
        if tool:
            try:''', '''        tool = TOOL_MAP.get(cmd)
        if tool:
            self.tool_tick(tool)
            try:''', "tool tick")

rep('''    def run_pty(self, argv):
        self.suspend_hud()''', '''    def run_pty(self, argv):
        if argv and argv[0] in ("sudo", "doas"):
            self.award("sudoer")
        self.suspend_hud()''', "sudoer")

rep('''        hints = self.L("hint").format(n=len(TOOLS))
        hint = clip(hints, L.W - 4)
        x = max(2, (L.W - disp_width(hint)) // 2)
        cv.put(x, L.hints_y, hint, C_SLATE)''', '''        hints = self.L("hint").format(n=len(TOOLS))
        hint = clip(hints, L.W - 4)
        x = max(2, (L.W - disp_width(hint)) // 2)
        if x >= 16:
            blink = "=-..-=" if (time.monotonic() % 8.0) < 0.4 else "=^..^="
            cv.put(2, L.hints_y, blink, C_PINK if blink == "=^..^=" else C_SLATE)
            cv.put(9, L.hints_y, clip(self._pet_name, 6), C_SLATE)
        cv.put(x, L.hints_y, hint, C_SLATE)''', "hints pet")

rep('''        self.prompt_name = False
        self.help = None''', '''        self.prompt_name = False
        self.help = None
        self.is_termux = bool(os.environ.get("TERMUX_VERSION"))
        self.music_player = None
        self.music_info = None
        self._pc_path = shutil.which("playerctl") is not None
        self.last_music_t = 0.0
        self.timer_until = None
        self.timer_label = ""
        self.konami = ""
        self.confetti = []
        self.confetti_until = 0.0
        self.last_cmd_t = time.monotonic()
        _pf0 = load_profile()
        self._xp = int(_pf0.get("xp") or 0)
        self._cmd_count = int(_pf0.get("cmd_count") or 0)
        self._seen = list(_pf0.get("seen_tools") or [])
        self._ach = list(_pf0.get("ach") or [])
        self._pet_name = _pf0.get("pet_name") or "Momo"''', "app init")

rep('''    if new_hi:
        T.push([("  🐍 NEW HIGH SCORE » ", C_GOLD), (str(score), C_FUCHSIA), ("  — legend!", C_DIM)])''',
    '''    if score >= 10:
        app.award("snake10")
    if new_hi:
        T.push([("  🐍 NEW HIGH SCORE » ", C_GOLD), (str(score), C_FUCHSIA), ("  — legend!", C_DIM)])''', "snake ach")

rep('''    T.dim("  style: theme • lang • intro • nick   |   fun: snake • hack • icat   |   shell: git, docker…")''',
    '''    T.dim("  pro: music • pet • ach • focus   |   style: theme • lang   |   shell: git, docker…")''', "tools hint")

rep('''                 ("text", "games/fun: snake • hack • icat  (kitty preview)", "", "", None),
                 ("text", "pro: music (spotify/YT!) • pet • ach • focus 25 • timer 10m", "", "", None)]''',
    '''                 ("text", "games/fun: snake • hack • icat  (kitty preview)", "", "", None),
                 ("text", "pro: music (spotify/YT!) • pet • ach • focus 25 • timer 10m", "", "", None)]''', "help rows")

rep('''    if not sys.stdin.isatty():
        print("cutie os needs a real terminal (tty).", file=sys.stderr)
        return 1''', '''    if sys.platform in ("win32", "cygwin", "darwin"):
        print("CUTIE OS is Linux-only 🐧  (Windows? WSL2 me chalao!)", file=sys.stderr)
        return 1
    if not sys.stdin.isatty():
        print("cutie os needs a real terminal (tty).", file=sys.stderr)
        return 1''', "os guard")

DIV = "# ───────────────────────────── toolkit registry"
block(DIV, '''def fmt_speed(bps):
    if bps >= 1048576:
        return "%.1fM" % (bps / 1048576.0)
    if bps >= 1024:
        return "%.0fK" % (bps / 1024.0)
    return "%d" % int(bps)


def net_bytes():
    rx = tx = 0
    try:
        with open("/proc/net/dev") as f:
            for ln in f.readlines()[2:]:
                p = ln.split(":")
                if len(p) != 2 or p[0].strip() == "lo":
                    continue
                v = p[1].split()
                if len(v) >= 9:
                    rx += int(v[0])
                    tx += int(v[8])
    except Exception:
        return None
    return (rx, tx)


def _music_raw(app, player=None):
    if shutil.which("playerctl") is None:
        return None
    fmt = ("{title}\\x1f{artist}\\x1f{album}\\x1f{status}\\x1f{volume}"
           "\\x1f{playerName}\\x1f{duration(position)}\\x1f{duration(mpris:length)}"
           "\\x1f{position}\\x1f{{mpris:length}}")
    cmd = ["playerctl"]
    if player:
        cmd += ["-p", player]
    cmd += ["metadata", "--format", fmt]
    out = run_cmd(cmd, 3)
    if "\\x1f" not in out:
        return None
    p = out.strip().split("\\x1f")
    if len(p) < 10 or not p[0].strip():
        return None

    def _i(x):
        try:
            return int(float(x))
        except Exception:
            return 0
    return {"title": p[0].strip(), "artist": p[1].strip(), "album": p[2].strip(),
            "status": p[3].strip(), "vol": p[4].strip(), "pname": p[5].strip(),
            "pos_h": p[6].strip() or "0:00", "len_h": p[7].strip(),
            "pos_us": _i(p[8]), "len_us": _i(p[9])}


def tool_music(app, args):
    T = app.term
    if shutil.which("playerctl") is None:
        if app.is_termux:
            T.dim("  playerctl nahi hai — pkg install playerctl (try karo)")
        else:
            T.dim("  playerctl nahi mila — sudo pacman -S playerctl")
        T.dim("  spotify / yt-music (browser) / mpv / vlc — sab MPRIS se chalega")
        return
    if args and args[0] == "-p" and len(args) >= 2:
        app.music_player = args[1]
        args = args[2:]
    if args and args[0].isdigit() and len(args) == 1:
        players = _cap("playerctl --list-all", 3).split()
        i = int(args[0]) - 1
        if 0 <= i < len(players):
            app.music_player = players[i]
            T.push([("  ♪ player » ", C_DIM), (players[i], C_CYAN)])
        else:
            T.dim("  galat number — music list dekho")
        return
    if args:
        sub = args[0].lower()
        tgt = ["-p", app.music_player] if app.music_player else []

        def pc(*rest):
            return run_cmd(["playerctl"] + tgt + list(rest), 4)
        if sub in ("play", "pause", "toggle", "play-pause", "stop", "next", "prev", "previous"):
            act = "previous" if sub == "prev" else ("play-pause" if sub == "toggle" else sub)
            pc(act)
            app.award("musician")
            d = _music_raw(app, app.music_player)
            if d and d.get("title"):
                sym = {"Playing": "▶", "Paused": "❚❚", "Stopped": "■"}.get(d["status"], "♪")
                T.push([("  %s " % sym, C_CYAN), (d["title"], C_VALUE),
                        (" — " + (d["artist"] or "?"), C_LABEL),
                        ("  [%s]" % d["pname"], C_SLATE)])
            else:
                T.push([("  ♪ ho gaya — koi player nahi chal raha?", C_DIM)])
            return
        if sub == "seek" and len(args) >= 2:
            a2 = args[1]
            if a2.startswith("+"):
                pc("position", a2[1:] + "+")
            elif a2.startswith("-"):
                pc("position", a2[1:] + "-")
            else:
                pc("position", a2)
            app.award("musician")
            T.push([("  ⏩ seek » ", C_DIM), (a2, C_VALUE)])
            return
        if sub in ("vol", "volume") and len(args) >= 2:
            a2 = args[1].rstrip("%")
            try:
                if a2.startswith("+"):
                    pc("volume", "%.2f+" % (float(a2[1:]) / 100.0))
                elif a2.startswith("-"):
                    pc("volume", "%.2f-" % (float(a2[1:]) / 100.0))
                else:
                    pc("volume", "%.2f" % (clamp(float(a2), 0, 100) / 100.0))
                app.award("musician")
                out = pc("volume")
                v = int(round(float(out.strip() or 0) * 100))
                T.push([("  vol » ", C_DIM)] + micro_bar(v, 12)[1] + [(" %d%%" % v, C_VALUE)])
            except Exception:
                T.dim("  usage: music vol 70 | +10 | -10")
            return
        if sub == "shuffle":
            pc("shuffle", args[1].lower() if len(args) > 1 else "toggle")
            T.push([("  🔀 shuffle » ", C_DIM), (args[1] if len(args) > 1 else "toggled", C_VALUE)])
            return
        if sub == "loop":
            pc("loop")
            T.push([("  🔁 loop » ", C_DIM), ("cycled", C_VALUE)])
            return
        if sub == "list":
            pls = _cap("playerctl --list-all", 3).split()
            T.head("◆ PLAYERS (MPRIS)")
            if not pls:
                T.dim("  koi media player active nahi — spotify/yt chala ke dekho")
                return
            for i, p in enumerate(pls, 1):
                cur = (p == app.music_player) or (app.music_player is None and i == 1)
                T.push([("  %s " % ("●" if cur else "○"), C_CYAN if cur else C_SLATE),
                        ("%d) " % i, C_DIM), (p, C_VALUE if cur else C_OUT)])
            T.dim("  switch: music 2   ya   music -p <name> next")
            return
        T.dim("  usage: music [play|pause|toggle|next|prev|stop|seek ±30|vol ±10|shuffle|loop|list]")
        return
    d = _music_raw(app, app.music_player)
    if not d or not d.get("title"):
        T.push([("  ♪ koi player nahi chal raha — ", C_DIM), ("spotify / yt-music chalao!", C_VALUE)])
        T.dim("  players: music list  •  controls: music next, pause, vol +10, seek +30…")
        return
    app.award("musician")
    sym = {"Playing": "▶", "Paused": "❚❚", "Stopped": "■"}.get(d["status"], "♪")
    T.push([("  ╭─ ", C_SLATE), ("♪ NOW PLAYING ", C_FUCHSIA), ("─" * 30, C_SLATE)])
    T.push([("  │ ", C_SLATE), ("TITLE   ", C_LABEL), ("» ", C_ARROW), (d["title"][:44], C_VALUE)])
    T.push([("  │ ", C_SLATE), ("ARTIST  ", C_LABEL), ("» ", C_ARROW), ((d["artist"] or "?")[:44], C_VALUE)])
    if d.get("album"):
        T.push([("  │ ", C_SLATE), ("ALBUM   ", C_LABEL), ("» ", C_ARROW), (d["album"][:44], C_DIM)])
    if d.get("len_us", 0) > 0:
        pct = clamp(d["pos_us"] * 100.0 / max(1, d["len_us"]), 0, 100)
        bp, bs, bc = micro_bar(pct, 18)
        T.push([("  │ ", C_SLATE), ("  ", C_OUT)] + bs +
               [(" %s / %s " % (d.get("pos_h"), d.get("len_h") or "?"), C_VALUE), (sym, C_CYAN)])
    T.push([("  │ ", C_SLATE), ("PLAYER  ", C_LABEL), ("» ", C_ARROW), (d["pname"], C_CYAN)])
    try:
        v = int(round(float(d.get("vol") or 0) * 100))
        T.push([("  │ ", C_SLATE), ("VOL     ", C_LABEL), ("» ", C_ARROW)] +
               micro_bar(v, 8)[1] + [(" %d%%" % v, C_VALUE)])
    except Exception:
        pass
    T.push([("  ╰", C_SLATE), ("─" * 45, C_SLATE), ("╯", C_SLATE)])
    T.dim("  next • prev • pause • seek +30 • vol +10 • shuffle • loop • list")


_EAR = chr(47) + chr(92)


PET_STAGES = (
    ("  " + _EAR + "_" + _EAR, " ( ^.^ )", "  > ~ <"),
    ("  " + _EAR + "_" + _EAR, " ( o.o )", "  > ^ <", "  |   |"),
    ("   " + _EAR + "____" + _EAR, "  (  o  o  )", "   ( =^..^= )", "    >______<"),
)


def tool_pet(app, args):
    T = app.term
    pf = load_profile()
    name = app._pet_name
    lvl = app.level()
    if args and args[0].lower() in ("name", "rename"):
        if len(args) >= 2:
            nm = " ".join(args[1:])[:16]
            pf["pet_name"] = nm
            save_profile(pf)
            app._pet_name = nm
            app.award("petparent")
            T.push([("  ✦ pet ka naam » ", C_DIM), (nm, C_FUCHSIA), ("  ♡", C_PINK)])
        else:
            T.dim("  usage: pet name <naya-naam>")
        return
    if args and args[0].lower() == "feed":
        now = time.monotonic()
        last = float(pf.get("last_feed") or 0)
        if now - last < 60:
            T.push([("  %s » " % name, C_DIM), ("pet bhar gaya hai! thodi der baad 🐟", C_DIM)])
            return
        pf["last_feed"] = now
        save_profile(pf)
        app.add_xp(2)
        T.push([("  %s » " % name, C_DIM), ("nyam nyam nyam 🐟 yum!", C_CYAN)])
        return
    sub = args[0].lower() if args else ""
    idle_min = (time.monotonic() - app.last_cmd_t) / 60.0
    if idle_min < 2:
        mood, mcol = "khush — tu yahi hai na ✦", C_PINK
    elif idle_min < 15:
        mood, mcol = "chill", C_CYAN
    else:
        mood, mcol = "so raha hai… zzz", C_SLATE
    stage = PET_STAGES[0 if lvl < 3 else (1 if lvl < 6 else 2)]
    T.push([("  ╭─", C_SLATE), (" PET ", C_FUCHSIA), ("─" * 28, C_SLATE)])
    for i, al in enumerate(stage):
        T.push([("  │  ", C_SLATE), (al, C_CYAN if i % 2 == 0 else C_VIOLET)])
    T.push([("  │  ", C_SLATE), ("%s — LVL %d • " % (name, lvl), C_VALUE), (mood, mcol)])
    if sub in ("pet", "cuddle"):
        T.push([("  │  ", C_SLATE), ("prrrrr ♡ (pet ko accha laga)", C_PINK)])
    T.push([("  ╰", C_SLATE), ("─" * 33, C_SLATE), ("╯", C_SLATE)])
    T.dim("  pet name X • pet feed • pet pet — XP ke saath pet bada hota hai (LVL 3, 6 pe evolve!)")


def tool_ach(app, args):
    T = app.term
    got = app._ach
    T.head("◆ ACHIEVEMENTS — %d/%d unlocked" % (len(got), len(ACHIEVEMENTS)))
    lvl = app.level()
    need = (lvl * lvl) * 75
    T.push(_kv("LEVEL", "LVL %d" % lvl,
               "%d XP • next LVL %d at %d XP" % (app._xp, lvl + 1, need)))
    for aid, nm, ds in ACHIEVEMENTS:
        if aid in got:
            T.push([("  ★ ", C_GOLD), (nm.ljust(14), C_VALUE), (ds, C_DIM)])
        else:
            T.push([("  ☆ ", C_SLATE), (nm.ljust(14), C_DIM), (ds, C_SLATE)])
    T.dim("  commands = XP • naye tools = +8 XP • level up = pet evolve 🐱")


def _parse_dur(tx):
    m = re.fullmatch(r"(\\d+)([smh]?)", tx.strip().lower())
    if not m:
        return None
    n = int(m.group(1))
    u = m.group(2)
    return n * (3600 if u == "h" else (60 if u == "m" else 1))


def tool_timer(app, args):
    T = app.term
    if not args:
        if app.timer_until:
            rem = max(0, int(app.timer_until - time.monotonic()))
            T.push(_kv("TIMER", "%02d:%02d baki" % (rem // 60, rem % 60), app.timer_label or None))
        else:
            T.dim("  usage: timer 10m | 90 | 2h   (cancel: timer off)")
        return
    if args[0].lower() in ("off", "cancel", "stop"):
        app.timer_until = None
        app.timer_label = ""
        T.push([("  ⏳ timer cancelled", C_DIM)])
        return
    secs = _parse_dur(args[0])
    if not secs or secs > 86400:
        T.dim("  samajh nahi aaya — timer 10m / 90 / 2h")
        return
    app.timer_until = time.monotonic() + secs
    app.timer_label = "TIMER"
    T.push([("  ⏳ timer chalu » ", C_DIM), ("%02d:%02d" % (secs // 60, secs % 60), C_GOLD),
            ("  (header me countdown • done pe notification)", C_DIM)])


def tool_focus(app, args):
    mins = 25
    if args:
        try:
            mins = clamp(int(args[0]), 1, 180)
        except Exception:
            pass
    app.timer_until = time.monotonic() + mins * 60
    app.timer_label = "FOCUS"
    app.term.push([("  🎯 FOCUS MODE » ", C_FUCHSIA), ("%d min" % mins, C_GOLD),
                   ("  •  phone utha mat 😤  •  done = notification + achievement", C_DIM)])


''' + DIV, "pro tools")

block("TOOL_MAP = {}", '''ACHIEVEMENTS = (
    ("first_cmd", "First Blood", "pehla command chalaya"),
    ("fifty", "Half Century", "50 commands complete"),
    ("explorer10", "Explorer", "10 alag tools try kiye"),
    ("explorerall", "Completionist", "saare tools try kiye!"),
    ("sudoer", "Sudoer", "sudo kaam karwaya"),
    ("snake10", "Snake Charmer", "snake me 10+ score"),
    ("hacker", "1337", "hack chalaya (sabko mat batana)"),
    ("neo", "Wake Up Neo", "matrix dekha"),
    ("themed", "Style Icon", "theme badla"),
    ("polyglot", "Polyglot", "language badli"),
    ("musician", "DJ Cutie", "music control kiya"),
    ("speed_demon", "Speed Demon", "speed test chalaya"),
    ("konami", "???", "↑↑↓↓←→←→BA"),
    ("petparent", "Pet Parent", "pet ko naam diya"),
    ("focused", "Zen Master", "focus session poora kiya"),
    ("night_owl", "Night Owl", "raat 1-4 baje coding"),
)

TOOL_ACH = {"music": "musician", "hack": "hacker", "matrix": "neo",
            "theme": "themed", "lang": "polyglot", "speed": "speed_demon"}

''', "achievements")

rep('''    Tool("icat", ["img", "pic"], "kitty image preview — icat pic.png", "media", tool_icat),''',
    '''    Tool("icat", ["img", "pic"], "kitty image preview — icat pic.png", "media", tool_icat),
    Tool("music", ["mp", "player"], "spotify/yt-music control — play next vol seek", "media", tool_music),
    Tool("pet", ["cat"], "tera pet billi — pet name/feed/pet", "fun", tool_pet),
    Tool("ach", ["trophy"], "achievements + level + XP", "fun", tool_ach),
    Tool("timer", [], "countdown — timer 10m / 90 / 2h", "core", tool_timer),
    Tool("focus", [], "pomodoro — focus 25", "core", tool_focus),''', "registry")

DIV2 = "# ───────────────────────────── self check / main"
block(DIV2, '''    # ── v14 PRO: xp / achievements / pet / music / timer / konami ──

    def level(self):
        return 1 + int(math.sqrt(self._xp / 75.0))

    def add_xp(self, n):
        old_lvl = self.level()
        self._xp += n
        save_profile_field("xp", self._xp)
        new_lvl = self.level()
        if new_lvl > old_lvl:
            T = self.term
            T.push([("  ╭", C_SLATE), ("────────────✦", C_GOLD), ("────────────╮", C_SLATE)])
            T.push([("  │  ", C_SLATE), ("⬆ LEVEL UP!  LVL %d" % new_lvl, C_GOLD),
                    ("  •  pet bhi bada ho gaya!", C_PINK)])
            T.push([("  ╰", C_SLATE), ("────────────✦", C_GOLD), ("────────────╯", C_SLATE)])
            if new_lvl >= 3:
                T.push([("  ✦ pet evolve hua — dekho: ", C_DIM), ("pet", C_CYAN)])

    def award(self, aid):
        if aid in self._ach:
            return
        meta = next((a for a in ACHIEVEMENTS if a[0] == aid), None)
        if meta is None:
            return
        self._ach.append(aid)
        save_profile_field("ach", self._ach)
        self.term.push([("  🏆 ACHIEVEMENT » ", C_GOLD), (meta[1], C_FUCHSIA),
                        (" — " + meta[2], C_DIM)])

    def cmd_tick(self):
        self.last_cmd_t = time.monotonic()
        self._cmd_count += 1
        save_profile_field("cmd_count", self._cmd_count)
        if self._cmd_count == 1:
            self.award("first_cmd")
        if self._cmd_count >= 50:
            self.award("fifty")
        h = time.localtime().tm_hour
        if 1 <= h < 4:
            self.award("night_owl")

    def tool_tick(self, tool):
        if tool.name not in self._seen:
            self._seen.append(tool.name)
            save_profile_field("seen_tools", self._seen)
            self.add_xp(8)
            if len(self._seen) >= 10:
                self.award("explorer10")
            if len(self._seen) >= len(TOOLS):
                self.award("explorerall")
        aid = TOOL_ACH.get(tool.name)
        if aid:
            self.award(aid)

    def _konami_on(self):
        self.confetti_until = time.monotonic() + 4.0
        cols = list(GRAD_STOPS) + [C_GOLD, C_WHITE]
        W, H = self.cv.w, self.cv.h
        self.confetti = [{"x": random.uniform(0, W), "y": random.uniform(-24, 0),
                          "vy": random.uniform(10, 26), "c": random.choice(cols),
                          "ch": random.choice("✦*·+•")} for _ in range(70)]
        self.term.push([("  🌈 KONAMI CODE! ", C_GOLD),
                        ("cheat activated — khush ho ja ✦", C_FUCHSIA)])
        self.award("konami")

    def _confetti_tick(self, dt):
        H = self.cv.h
        for p in self.confetti:
            p["y"] += p["vy"] * dt
        self.confetti = [p for p in self.confetti if p["y"] < H]

    def _draw_confetti(self, cv, t):
        if not self.confetti or time.monotonic() > self.confetti_until:
            self.confetti = []
            return
        for p in self.confetti:
            cv.set(int(p["x"]) % cv.w, int(p["y"]), p["ch"], p["c"])

    def _music_tick(self):
        now = time.monotonic()
        if now - self.last_music_t < 3.0 or not self._pc_path:
            return
        self.last_music_t = now
        self.music_info = _music_raw(self, self.music_player)

    def _timer_tick(self, now):
        if self.timer_until is None or now < self.timer_until:
            return
        lbl = self.timer_label or "TIMER"
        self.timer_until = None
        self.timer_label = ""
        T = self.term
        T.push([("  ⏰ ", C_GOLD), ("%s POORA HUA!" % lbl, C_FUCHSIA),
                ("  (%s)" % time.strftime("%H:%M"), C_DIM)])
        if self.is_termux and shutil.which("termux-notification"):
            _cap("termux-notification --title 'CUTIE %s' --content 'time up ⏰'" % lbl, 4)
        elif shutil.which("notify-send"):
            try:
                subprocess.run(["notify-send", "-a", "CUTIE OS",
                                "⏰ CUTIE %s" % lbl, "time up!"], timeout=4)
            except Exception:
                pass
        if lbl == "FOCUS":
            self.award("focused")


''' + DIV2, "app pro methods")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

import shutil as _sh
_sh.copy(P, P + ".bak-v13")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v14 PRO patched ✓  (backup: %s.bak-v13)" % P)
