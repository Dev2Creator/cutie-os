import re, shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "tool_tetris" in s:
    print("already patched ✓"); sys.exit(0)
for ln in s.splitlines():
    if ln.startswith("VERSION") or ln.startswith("EDITION"):
        print("  base file:", ln.strip())
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

def rx(pat, repl, label):
    global s
    s2, n = re.subn(pat, repl, s, count=1)
    if n == 0:
        fails.append(label); print("  ✗", label); return
    s = s2; print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[a:]; print("  ✓", label)

rx(r'VERSION\s*=\s*"[^"]*"', 'VERSION      = "v26"', "version")
rx(r'EDITION\s*=\s*"[^"]*"', 'EDITION      = "PLAY EDITION"', "edition")

rep('''    ("night_owl", "Night Owl", "raat 1-4 baje coding"),
)''', '''    ("night_owl", "Night Owl", "raat 1-4 baje coding"),
    ("typer60", "60 WPM Club", "typing me 60+ wpm"),
    ("typer100", "Lightning Hands", "100+ WPM!! legend"),
    ("boss_slain", "Boss Slayer", "typing boss khatam kiya"),
    ("momo_beaten", "Momo Ko Haraya", "race mode jeet liya"),
    ("streak7", "Streak 7", "7 din daily typing"),
    ("tetris1k", "Block Master", "tetris me 1000+ score"),
    ("n2048", "2048 Unlocked", "2048 tile bana diya"),
)''', "new achievements")

rep('''        threading.Thread(target=self._wx_loop, daemon=True).start()''',
    '''        threading.Thread(target=self._wx_loop, daemon=True).start()
        self.tpage = None''', "tpage init")

rep('''        if self.epage:
            self.handle_epage_event(ev)
            return''', '''        if self.tpage is not None:
            self.handle_tpage_event(ev)
            return
        if self.epage:
            self.handle_epage_event(ev)
            return''', "tpage routing")

rep('''        if self.epage and not L.too_small:
            cv.clear()
            return self.build_epage_frame(t)''', '''        if self.tpage is not None and not L.too_small:
            cv.clear()
            return self.build_tpage_frame(t)
        if self.epage and not L.too_small:
            cv.clear()
            return self.build_epage_frame(t)''', "tpage frame")

rep('''    Tool("sync", ["backup"], "cutie setup export/import — naya PC same cutie", "core", tool_sync),''',
    '''    Tool("sync", ["backup"], "cutie setup export/import — naya PC same cutie", "core", tool_sync),
    Tool("typing", ["type", "tt"], "CUTIE TYPE — 12 modes: boss race ghost meme code…", "fun", tool_typing),
    Tool("tetris", ["blocks"], "TETRIS — arrows, space=drop, hi-score saved", "fun", tool_tetris),
    Tool("2048", ["g2048"], "2048 — arrows merge, best score", "fun", tool_2048),''',
    "game registry")

rx(r'"hint": "[^"]*"',
   '"hint": "↑↓ • CTRL+R fuzzy • TAB • CTRL+C kill • !cmd sudo • dash • ask (AI) • typing • tetris • 2048 • tools → {n}"',
   "hint games")

DATA = '''TYPE_WORDS = (
    "the", "be", "to", "of", "and", "a", "in", "that", "have", "it", "for",
    "not", "on", "with", "he", "as", "you", "do", "at", "this", "but", "his",
    "by", "from", "they", "we", "say", "her", "she", "or", "an", "will", "my",
    "one", "all", "would", "there", "their", "what", "so", "up", "out", "if",
    "about", "who", "get", "which", "go", "me", "when", "make", "can", "like",
    "time", "no", "just", "him", "know", "take", "people", "into", "year",
    "your", "good", "some", "could", "them", "see", "other", "than", "then",
    "now", "look", "only", "come", "its", "over", "think", "also", "back",
    "after", "use", "two", "how", "our", "work", "first", "well", "way",
    "even", "new", "want", "because", "any", "these", "give", "day", "most",
    "code", "bug", "git", "diff", "test", "pass", "fail", "loop", "data",
    "file", "line", "name", "call", "read", "write", "list", "hash", "stack",
    "heap", "node", "edge", "sort", "cache", "fetch", "push", "pull", "merge",
    "fork", "repo", "shell", "kernel", "server", "client", "thread", "async",
    "class", "return", "print", "input", "while", "break", "range", "index",
    "debug", "deploy", "build", "ship", "fast", "slow", "clean", "cute",
    "momo", "vibe", "chai", "coffee", "night", "early", "sleep", "dream",
    "focus", "relax", "panic", "fix", "hack", "magic", "power", "energy",
    "battery", "boost", "turbo", "level", "score", "win", "lose", "again",
    "retry", "final", "done", "ready", "steady", "go", "quick", "jump",
)

TYPE_QUOTES = (
    "simplicity is the ultimate sophistication",
    "talk is cheap show me the code",
    "first solve the problem then write the code",
    "experience is the name everyone gives to their mistakes",
    "programming is thinking not typing",
    "make it work make it right make it fast",
    "any fool can write code that a computer can understand",
    "there is no place like 127.0.0.1",
)

TYPE_HI = (
    "kal se pakka diet aur pakka side project",
    "bas aakhri update phir so jaunga",
    "debugging me chai hi asli hero hai",
    "merge conflict dekh ke dil toot gaya",
    "code chal gaya pata nahi kaise",
    "production me test karna hi asli test hai",
    "semicolon bhool gaya poora din gaya",
    "stack overflow se mila jawab",
    "aur thoda sa push phir ghar",
    "bhai ne friday ko deploy kar diya",
)

TYPE_BN = (
    "ajke kaj kal e hobe bolle hoy na",
    "ek cup cha holei bug chole jabe",
    "commit message porer ami bujhbe na",
    "amar wifi amar niyom",
    "push kore ghumiye porbo",
    "raat jege code likha classic",
    "kal theke serious padha shuru",
    "sohoj kaj kothin hoye jay",
)

TYPE_CODE = (
    "\\n".join(["def fib(n):", "    if n < 2:", "        return n",
                "    return fib(n - 1) + fib(n - 2)"]),
    "\\n".join(["for i in range(10):", "    if i % 2 == 0:", "        print(i, 'even')",
                "    else:", "        print(i, 'odd')"]),
    "\\n".join(["import json", "", "with open('data.json') as f:",
                "    data = json.load(f)", "print(data.keys())"]),
    "\\n".join(["#include <stdio.h>", "", "int main() {", "    int sum = 0;",
                "    for (int i = 1; i <= 10; i++) {", "        sum += i;",
                "    }", '    printf("sum = %d", sum);', "    return 0;", "}"]),
    "\\n".join(["#include <stdio.h>", "", "int main() {", '    puts("cutie c");',
                "    for (int i = 0; i < 3; i++) {", '        puts("loop");', "    }",
                "    return 0;", "}"]),
    "\\n".join(["def quicksort(xs):", "    if len(xs) <= 1:", "        return xs",
                "    p = xs[0]", "    left = [x for x in xs[1:] if x < p]",
                "    right = [x for x in xs[1:] if x >= p]",
                "    return quicksort(left) + [p] + quicksort(right)"]),
)

TET_COLORS = {"I": C_CYAN, "O": C_GOLD, "T": C_VIOLET, "S": (60, 200, 100),
              "Z": C_RED, "J": (96, 165, 250), "L": (251, 146, 60)}


def _tet_rot(m):
    return ["".join(r) for r in zip(*m[::-1])]


_T_BASE = {"I": ["####"], "O": ["##", "##"], "T": ["###", " # "],
           "S": [" ##", "## "], "Z": ["## ", " ##"],
           "J": ["#  ", "###"], "L": ["  #", "###"]}
_T_PIECES = {}
for _k, _m in _T_BASE.items():
    _rots = [_m]
    _cur = _m
    for _i in range(3):
        _cur = _tet_rot(_cur)
        if _cur not in _rots:
            _rots.append(_cur)
    _T_PIECES[_k] = _rots

G2048_COL = [C_SLATE, C_OUT, C_CYAN, C_VIOLET, C_PURPLE, C_FUCHSIA,
             C_MAGENTA, C_PINK, C_GOLD, C_RED, C_WHITE, C_GOLD]


def _type_wrap(text, width):
    lines = []
    cur = ""
    start = 0
    for w in text.split(" "):
        cand = (cur + " " + w) if cur else w
        if disp_width(cand) > width and cur:
            lines.append((cur, start))
            start += len(cur) + 1
            cur = w
        else:
            cur = cand
    if cur:
        lines.append((cur, start))
    return lines


def tool_typing(app, args):
    mode = "words"
    arg = None
    known = ("words", "quote", "quotes", "meme", "hi", "bn", "code",
             "boss", "race", "ghost", "zen", "daily", "drill")
    if args:
        a0 = args[0].lower()
        if a0 == "drill":
            mode, arg = "drill", (args[1] if len(args) > 1 else None)
        elif a0.isdigit():
            arg = a0
        elif a0 in known:
            mode = "quote" if a0 == "quotes" else a0
            arg = args[1] if len(args) > 1 else None
        else:
            mode, arg = "drill", a0
    app.tpage = app._type_build(mode, arg)


def tool_tetris(app, args):
    T = app.term
    app.suspend_hud()
    score = 0
    lines_c = 0
    try:
        enter_raw(app.fd)
        app.keys.pend = b""
        W, H = app.size()
        out = app.out
        out.write(ALT_ON + CUR_HIDE)
        out.flush()
        BW, BH = 10, 20
        grid = [[None] * BW for _ in range(BH)]
        bag = []
        hi = int(load_profile().get("tetris_hi") or 0)
        hi0 = hi

        def nxt_piece():
            if not bag:
                bag.extend(list(_T_PIECES.keys()))
                random.shuffle(bag)
            return bag.pop()

        cur_k, cur_r, px, py = nxt_piece(), 0, 3, 0
        next_k = nxt_piece()
        over = False
        quitf = False
        paused = False
        last_g = time.monotonic()

        def cells(k, r, ox, oy):
            m = _T_PIECES[k][r % len(_T_PIECES[k])]
            oc = []
            for rr, row in enumerate(m):
                for cc, c2 in enumerate(row):
                    if c2 == "#":
                        oc.append((ox + cc, oy + rr))
            return oc

        def hit(k, r, ox, oy):
            for x, y in cells(k, r, ox, oy):
                if x < 0 or x >= BW or y >= BH:
                    return True
                if y >= 0 and grid[y][x] is not None:
                    return True
            return False

        def render(t2):
            cv = Canvas(W, H)
            bcol = C_TERM_BORDER
            bx = max(2, (W - (BW * 2 + 12)) // 2)
            byy = max(1, (H - (BH + 2)) // 2)
            cv.put(bx - 1, byy - 1, "╭" + "─" * (BW * 2 + 1) + "╮", bcol)
            cv.put(bx - 1, byy + BH, "╰" + "─" * (BW * 2 + 1) + "╯", bcol)
            for yy2 in range(BH):
                cv.put(bx - 1, byy + yy2, "│", bcol)
                cv.put(bx + BW * 2, byy + yy2, "│", bcol)
            for y2 in range(BH):
                for x2 in range(BW):
                    v = grid[y2][x2]
                    if v:
                        cv.put(bx + x2 * 2, byy + y2, "██", v)
            if not over:
                for x, y in cells(cur_k, cur_r, px, py):
                    if y >= 0:
                        cv.put(bx + x * 2, byy + y, "██", TET_COLORS[cur_k])
            sx = bx + BW * 2 + 3
            cv.put(sx, byy, "✿ TETRIS", C_TITLE)
            cv.put(sx, byy + 2, "SCORE", C_LABEL)
            cv.put(sx, byy + 3, str(score).rjust(6), C_GOLD)
            cv.put(sx, byy + 5, "LINES", C_LABEL)
            cv.put(sx, byy + 6, str(lines_c).rjust(6), C_VALUE)
            cv.put(sx, byy + 8, "NEXT", C_LABEL)
            for x, y in cells(next_k, 0, 0, 0):
                cv.put(sx + x * 2, byy + 9 + y, "██", TET_COLORS[next_k])
            cv.put(sx, byy + 13, "HI " + str(max(hi, score)), C_SLATE)
            cv.put(sx, byy + 15, "←→ move", C_SLATE)
            cv.put(sx, byy + 16, "↑ rot • ␣ drop", C_SLATE)
            cv.put(sx, byy + 17, "Q quit", C_SLATE)
            if paused:
                cv.put(sx, byy + 19, "|| PAUSED", C_GOLD)
            if over:
                m1 = "☠ GAME OVER"
                cv.put(max(2, (W - disp_width(m1)) // 2), byy + 8, m1, C_RED)
                m2 = "score %d%s" % (score, "  ★ NEW BEST!" if score > hi0 else "")
                cv.put(max(2, (W - disp_width(m2)) // 2), byy + 10, m2, C_VALUE)
                m3 = "Q / ENTER"
                cv.put(max(2, (W - disp_width(m3)) // 2), byy + 12, m3, C_SLATE)
            try:
                out.write(HOME + cv.render())
                out.flush()
            except Exception:
                pass

        render(time.monotonic())
        while not quitf:
            now = time.monotonic()
            for ev in app.keys.poll(0.02):
                kind, ch = ev[0], ev[1]
                if kind == "EOF":
                    quitf = True
                elif kind in ("CTRL_C", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
                    quitf = True
                elif kind == "ENTER" and over:
                    quitf = True
                elif over or paused:
                    continue
                elif kind == "LEFT":
                    if not hit(cur_k, cur_r, px - 1, py):
                        px -= 1
                elif kind == "RIGHT":
                    if not hit(cur_k, cur_r, px + 1, py):
                        px += 1
                elif kind == "UP":
                    nr = (cur_r + 1) % len(_T_PIECES[cur_k])
                    if not hit(cur_k, nr, px, py):
                        cur_r = nr
                elif kind == "DOWN":
                    if not hit(cur_k, cur_r, px, py + 1):
                        py += 1
                        score += 1
                elif kind == "CHAR" and ch == " ":
                    while not hit(cur_k, cur_r, px, py + 1):
                        py += 1
                        score += 2
                elif kind == "CHAR" and ch in ("p", "P"):
                    paused = not paused
            if quitf:
                break
            if not over and not paused and now - last_g >= max(0.08, 0.5 - (lines_c // 10) * 0.045):
                last_g = now
                if not hit(cur_k, cur_r, px, py + 1):
                    py += 1
                else:
                    for x, y in cells(cur_k, cur_r, px, py):
                        if y >= 0:
                            grid[y][x] = TET_COLORS[cur_k]
                    cleared = 0
                    yy2 = BH - 1
                    while yy2 >= 0:
                        if all(v is not None for v in grid[yy2]):
                            grid.pop(yy2)
                            grid.insert(0, [None] * BW)
                            cleared += 1
                        else:
                            yy2 -= 1
                    if cleared:
                        score += (0, 100, 300, 500, 800)[cleared] * (1 + lines_c // 10)
                        lines_c += cleared
                    cur_k, cur_r = next_k, 0
                    px, py = 3, 0
                    next_k = nxt_piece()
                    if hit(cur_k, cur_r, px, py):
                        over = True
                        if score > hi0:
                            save_profile_field("tetris_hi", score)
            render(now)
            time.sleep(0.004)
        if score > hi0:
            save_profile_field("tetris_hi", score)
    finally:
        app.resume_hud()
    if score >= 1000:
        app.award("tetris1k")
    T.push([("  🧱 tetris » ", C_DIM), ("score %d • %d lines" % (score, lines_c), C_VALUE),
            ("  •  best %d" % max(score, hi), C_SLATE)])


def tool_2048(app, args):
    T = app.term
    app.suspend_hud()
    score = 0
    got2048 = False
    try:
        enter_raw(app.fd)
        app.keys.pend = b""
        W, H = app.size()
        out = app.out
        out.write(ALT_ON + CUR_HIDE)
        out.flush()
        g = [[0] * 4 for _ in range(4)]
        best = int(load_profile().get("g2048_best") or 0)
        best0 = best

        def spawn():
            empt = [(y, x) for y in range(4) for x in range(4) if g[y][x] == 0]
            if not empt:
                return
            y, x = random.choice(empt)
            g[y][x] = 4 if random.random() < 0.1 else 2

        def merge_row(row):
            vals = [v for v in row if v]
            outv = []
            i = 0
            gn = 0
            while i < len(vals):
                if i + 1 < len(vals) and vals[i] == vals[i + 1]:
                    outv.append(vals[i] * 2)
                    gn += vals[i] * 2
                    i += 2
                else:
                    outv.append(vals[i])
                    i += 1
            outv += [0] * (4 - len(outv))
            return outv, gn

        def move(dirn):
            nonlocal score, got2048
            before = [r[:] for r in g]
            if dirn == "L":
                for y in range(4):
                    g[y], gn = merge_row(g[y])
                    score += gn
            elif dirn == "R":
                for y in range(4):
                    rev = g[y][::-1]
                    rev, gn = merge_row(rev)
                    g[y] = rev[::-1]
                    score += gn
            elif dirn == "U":
                for x in range(4):
                    col = [g[y][x] for y in range(4)]
                    col, gn = merge_row(col)
                    for y in range(4):
                        g[y][x] = col[y]
                    score += gn
            elif dirn == "D":
                for x in range(4):
                    col = [g[y][x] for y in range(4)][::-1]
                    col, gn = merge_row(col)
                    col = col[::-1]
                    for y in range(4):
                        g[y][x] = col[y]
                    score += gn
            moved = g != before
            if moved:
                spawn()
                for y in range(4):
                    for x in range(4):
                        if g[y][x] >= 2048:
                            got2048 = True
            return moved

        def can_move():
            for y in range(4):
                for x in range(4):
                    if g[y][x] == 0:
                        return True
                    if x < 3 and g[y][x] == g[y][x + 1]:
                        return True
                    if y < 3 and g[y][x] == g[y + 1][x]:
                        return True
            return False

        def render(t2):
            cv = Canvas(W, H)
            bcol = C_TERM_BORDER
            gx = max(2, (W - 32) // 2)
            gy = max(3, (H - 13) // 2)
            cv.put(gx - 1, gy - 1, "╭" + "─" * 29 + "╮", bcol)
            cv.put(gx - 1, gy + 11, "╰" + "─" * 29 + "╯", bcol)
            for yy2 in range(11):
                cv.put(gx - 1, gy + yy2, "│", bcol)
                cv.put(gx + 29, gy + yy2, "│", bcol)
            for y in range(4):
                for x in range(4):
                    v = g[y][x]
                    cx = gx + x * 7
                    cy = gy + y * 3
                    if v:
                        col = G2048_COL[max(0, min(11, int(math.log2(v)) - 1))]
                        fill = scale(col, 0.30)
                        for r2 in range(3):
                            cv.put(cx, cy + r2, " " * 6, fill)
                        tstr = str(v)
                        cv.put(cx + (6 - len(tstr)) // 2, cy + 1, tstr,
                               C_WHITE if v >= 128 else scale(col, 1.3))
                    else:
                        cv.put(cx, cy + 1, "  ·   ", scale(C_SLATE, 0.6))
            put_segs(cv, gx, gy - 2,
                     [("2048  ", C_TITLE), ("SCORE ", C_LABEL), (str(score), C_GOLD),
                      ("   BEST ", C_LABEL), (str(max(best, score)), C_VALUE)])
            if not can_move():
                cv.put(gx + 3, gy + 5, "☠ koi move nahi!", C_RED)
                cv.put(gx + 3, gy + 7, "Q / ENTER", C_SLATE)
            try:
                out.write(HOME + cv.render())
                out.flush()
            except Exception:
                pass

        spawn()
        spawn()
        quitf = False
        render(time.monotonic())
        while not quitf:
            for ev in app.keys.poll(0.05):
                kind, ch = ev[0], ev[1]
                if kind == "EOF":
                    quitf = True
                elif kind in ("CTRL_C", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
                    quitf = True
                elif kind == "ENTER" and not can_move():
                    quitf = True
                elif not can_move():
                    continue
                elif kind == "LEFT":
                    move("L")
                elif kind == "RIGHT":
                    move("R")
                elif kind == "UP":
                    move("U")
                elif kind == "DOWN":
                    move("D")
            if score > best:
                best = score
            render(time.monotonic())
            time.sleep(0.01)
        if score > best0:
            save_profile_field("g2048_best", score)
    finally:
        app.resume_hud()
    if got2048:
        app.award("n2048")
    T.push([("  🎲 2048 » ", C_DIM), ("score %d" % score, C_VALUE),
            ("  •  best %d" % max(best, score), C_SLATE)])


'''

block("def tool_music(app, args):", DATA, "game tools data")

DIV2 = "# ───────────────────────────── self check / main"
block(DIV2, '''    # ── v26: CUTIE TYPE page ──

    def _type_build(self, mode, arg=None):
        cfg = {"name": mode}
        txt = ""
        if mode == "words":
            cfg["dur"] = clamp(int(arg), 15, 300) if (arg or "").isdigit() else 30
            txt = " ".join(random.choice(TYPE_WORDS) for _ in range(cfg["dur"] * 3))
        elif mode == "quote":
            txt = random.choice(TYPE_QUOTES)
        elif mode == "meme":
            txt = random.choice(MEMES)[0]
        elif mode == "hi":
            txt = random.choice(TYPE_HI)
        elif mode == "bn":
            txt = random.choice(TYPE_BN)
        elif mode == "code":
            txt = random.choice(TYPE_CODE)
            cfg["name"] = "code"
        elif mode == "daily":
            random.seed(time.strftime("%Y%m%d"))
            txt = random.choice(TYPE_QUOTES + tuple(m for m, _t in MEMES))
            random.seed()
            cfg["name"] = "daily " + time.strftime("%d %b")
        elif mode == "drill":
            L = (arg or "q").lower()[:1]
            pool = [w for w in TYPE_WORDS if L in w] or TYPE_WORDS
            txt = " ".join(random.choice(pool) for _ in range(40))
            cfg["name"] = "drill '" + L + "'"
        elif mode == "zen":
            txt = " ".join(random.choice(TYPE_WORDS) for _ in range(120))
        else:
            mode = "words"
            cfg["dur"] = 30
            txt = " ".join(random.choice(TYPE_WORDS) for _ in range(90))
        st = {"mode": mode, "arg": arg, "text": txt, "states": [2] * len(txt),
              "idx": 0, "t0": time.monotonic(), "errors": 0, "ok": 0,
              "combo": 0, "maxcombo": 0, "done": False, "res": None,
              "dur": cfg.get("dur"), "samples": [], "last_s": 0.0,
              "name": cfg.get("name", mode), "last_err": 0.0,
              "keyerr": {}, "pb": False, "streak": 0}
        if mode == "boss":
            st["hp"] = 100
            st["bhp"] = max(30, len(txt) // 2)
            st["bhp0"] = st["bhp"]
        if mode in ("race", "ghost"):
            if mode == "race":
                st["momo"] = 85 if (arg or "") == "pro" else 35
            else:
                gr = load_profile().get("ghost_run") or {}
                st["momo"] = float(gr.get("wpm") or 40)
            if st["momo"] < 5:
                st["momo"] = 35
        return st

    def _type_start(self, mode, arg=None):
        self.tpage = self._type_build(mode, arg)

    def _type_finish(self):
        tp = self.tpage
        el = max(0.5, time.monotonic() - tp["t0"])
        wpm = tp["ok"] / 5.0 * 60.0 / el
        acc = tp["ok"] * 100.0 / max(1, tp["ok"] + tp["errors"])
        mode = tp["mode"]
        win = True
        note = None
        if mode == "boss":
            win = tp.get("bhp", 1) <= 0
            note = "BOSS DOWN! 🐉💀" if win else "boss ne haraya… retry! 😿"
        elif mode in ("race", "ghost"):
            mi = int(tp.get("momo", 40) * 5 * el / 60.0)
            win = mi < len(tp["text"])
            who = "MOMO" if mode == "race" else "GHOST (tera purana best)"
            note = ("%s ko haraya! 🏁" % who) if win else ("%s pehle pahunch gaya 😹" % who)
        tp["done"] = True
        tp["res"] = (wpm, acc, el, win, note)
        bestk = "type_best_" + mode
        pb = wpm > float(load_profile().get(bestk) or 0)
        if pb:
            save_profile_field(bestk, round(wpm, 1))
            tp["pb"] = True
            self.confetti_until = time.monotonic() + 4.0
            cols = list(GRAD_STOPS) + [C_GOLD, C_WHITE]
            self.confetti = [{"x": random.uniform(0, self.cv.w),
                              "y": random.uniform(-24, 0),
                              "vy": random.uniform(10, 26),
                              "c": random.choice(cols),
                              "ch": random.choice("✦*·+•")} for _ in range(70)]
        if wpm >= 100:
            self.award("typer100")
        elif wpm >= 60:
            self.award("typer60")
        if mode == "boss" and win:
            self.award("boss_slain")
        if mode == "race" and win:
            self.award("momo_beaten")
        if mode == "daily":
            today = time.strftime("%Y-%m-%d")
            yst = time.strftime("%Y-%m-%d", time.localtime(time.time() - 86400))
            stk = int(load_profile().get("type_streak") or 0)
            last = load_profile().get("type_lastday")
            stk = (stk + 1) if last == yst else 1
            save_profile_field("type_streak", stk)
            save_profile_field("type_lastday", today)
            tp["streak"] = stk
            if stk >= 7:
                self.award("streak7")
        if mode == "ghost" and win:
            save_profile_field("ghost_run", {"wpm": round(wpm, 1),
                                             "samples": tp["samples"][-40:]})
        self.add_xp(4)
        self.cmd_tick()

    def handle_tpage_event(self, ev):
        kind, ch = ev[0], ev[1]
        tp = self.tpage
        if kind == "EOF":
            self.running = False
            return
        if kind in ("CTRL_C", "ESC", "CTRL_Q") or (kind == "CHAR" and ch in ("q", "Q")):
            self.tpage = None
            return
        if tp["done"]:
            if kind in ("CHAR", "ENTER") and (ch == " " or kind == "ENTER"):
                self._type_start(tp["mode"], tp.get("arg"))
            return
        if kind != "CHAR" or not ch or ch in ("\\n", "\\r"):
            return
        now = time.monotonic()
        txt = tp["text"]
        if tp["idx"] >= len(txt):
            return
        exp = txt[tp["idx"]]
        if ch == exp:
            tp["states"][tp["idx"]] = 0
            tp["idx"] += 1
            tp["ok"] += 1
            tp["combo"] += 1
            tp["maxcombo"] = max(tp["maxcombo"], tp["combo"])
            if tp["mode"] == "boss":
                tp["bhp"] -= (2 if tp["combo"] >= 10 else 1)
                if tp["bhp"] <= 0:
                    return self._type_finish()
        else:
            tp["errors"] += 1
            tp["combo"] = 0
            tp["last_err"] = now
            tp["keyerr"][exp] = tp["keyerr"].get(exp, 0) + 1
            if tp["mode"] == "boss":
                tp["hp"] -= 8
                if tp["hp"] <= 0:
                    return self._type_finish()
        if now - tp.get("last_s", 0) >= 0.5:
            tp["samples"].append((now - tp["t0"], tp["ok"]))
            tp["last_s"] = now
        if tp["mode"] == "race":
            mi = int(tp["momo"] * 5 * (now - tp["t0"]) / 60.0)
            if mi >= len(txt):
                return self._type_finish()
        if tp["idx"] >= len(txt):
            if tp["mode"] == "zen":
                more = " " + " ".join(random.choice(TYPE_WORDS) for _ in range(40))
                tp["text"] += more
                tp["states"] += [2] * len(more)
                return
            return self._type_finish()

    def build_tpage_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        tp = self.tpage
        b = C_TERM_BORDER
        cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", b)
        cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", b)
        for yy in range(1, H - 1):
            cv.put(0, yy, "│", b)
            cv.put(W - 1, yy, "│", b)
        now = time.monotonic()
        if tp["done"]:
            return self._type_end_frame(cv, W, H, t)
        if tp.get("dur") and (now - tp["t0"]) >= tp["dur"]:
            self._type_finish()
            return self._type_end_frame(cv, W, H, t)
        if tp.get("dur") and (now - tp["t0"]) >= tp["dur"]:
            self._type_finish()
            return self._type_end_frame(cv, W, H, t)
        el = now - tp["t0"]
        wpm = tp["ok"] / 5.0 * 60.0 / max(0.5, el)
        acc = tp["ok"] * 100.0 / max(1, tp["ok"] + tp["errors"])
        cv.put(2, 1, "✿ CUTIE TYPE", C_TITLE)
        cv.put(15, 1, clip("— " + tp["name"], W - 56), C_SLATE)
        if tp["mode"] == "words" and tp["dur"]:
            rem = max(0, tp["dur"] - el)
            timest = "⏱ %d:%02d" % (rem // 60, rem % 60)
        else:
            timest = "⏱ %d:%02d" % (el // 60, el % 60)
        segs = [(timest + "   ", C_VALUE), ("%.0f WPM" % wpm, C_GOLD),
                ("   ", C_DIM), ("%.0f%%" % acc, C_CYAN if acc >= 90 else C_GOLD)]
        if tp["combo"] >= 5:
            segs += [("   ✦x%d" % min(9, tp["combo"] // 5), C_FUCHSIA)]
        put_segs(cv, W - 2 - disp_width("".join(x for x, _ in segs)), 1, segs)
        gw = min(44, W - 16)
        if len(tp["samples"]) >= 2 and gw > 10:
            ss = tp["samples"][-gw:]
            bars = []
            for i in range(1, len(ss)):
                dt = ss[i][0] - ss[i - 1][0]
                dc = ss[i][1] - ss[i - 1][1]
                bars.append(dc / 5.0 * 60.0 / max(0.2, dt))
            mx = max(bars) or 1.0
            for i, v in enumerate(bars[-gw:]):
                hgt = clamp(int(v / mx * 7.999), 0, 7) + 1
                cv.set(4 + i, 3, "▁▂▃▄▅▆▇█"[hgt - 1], grad(i / max(1, len(bars) - 1)))
        tw = max(20, W - 12)
        lines = _type_wrap(tp["text"], tw)
        cur_l = 0
        for li, (ln, st_i) in enumerate(lines):
            if st_i <= tp["idx"] < st_i + len(ln):
                cur_l = li
                break
        show_n = max(3, H - 13)
        froml = max(0, min(cur_l - 1, max(0, len(lines) - show_n)))
        for r2 in range(show_n):
            li = froml + r2
            if li >= len(lines):
                break
            ln, st_i = lines[li]
            yy = 5 + r2
            x = 5
            for j, c2 in enumerate(ln):
                i = st_i + j
                if i >= len(tp["text"]):
                    break
                col = C_SLATE
                if i < tp["idx"]:
                    col = C_CYAN
                elif i == tp["idx"]:
                    col = C_RED if (now - tp["last_err"] < 0.30) else C_WHITE
                if i == tp["idx"]:
                    cv.put(x, yy, "▌", C_GOLD)
                    x += 1
                cv.put(x, yy, c2, col)
                x += char_width(c2)
                if x > W - 6:
                    break
        by = H - 6
        if tp["mode"] in ("race", "ghost"):
            prog = tp["idx"] * 100.0 / max(1, len(tp["text"]))
            momo_i = int(tp["momo"] * 5 * el / 60.0)
            mprog = min(100.0, momo_i * 100.0 / max(1, len(tp["text"])))
            bw = max(14, W - 30)
            put_segs(cv, 4, by, [("YOU ", C_LABEL)] + micro_bar(prog, bw) +
                     [(" %.0f%%" % prog, C_VALUE)])
            who = "MOMO" if tp["mode"] == "race" else "GHST"
            put_segs(cv, 4, by + 1, [(who + " ", C_LABEL)] + micro_bar(mprog, bw) +
                     [(" %.0f%%" % mprog, C_VALUE)])
        elif tp["mode"] == "boss":
            bwp = max(14, W - 34)
            put_segs(cv, 4, by, [("🐉 ", C_VALUE)] +
                     micro_bar(max(0.0, tp["bhp"] * 100.0 / max(1, tp["bhp0"])), bwp) +
                     [(" BOSS", C_RED)])
            put_segs(cv, 4, by + 1, [("❤ ", C_RED)] + micro_bar(max(0.0, tp["hp"]), bwp) +
                     [(" YOU", C_VALUE)])
        face, fcol = "=^..^=", C_PINK
        if tp["combo"] >= 10:
            face, fcol = "😻", C_GOLD
        elif now - tp["last_err"] < 0.6:
            face, fcol = "😿", C_SLATE
        cv.put(W - 12, H - 3, face, fcol)
        cv.put(2, H - 3, clip("type the text • galti = shake • ✦ combo • ESC quit",
                              W - 20), C_SLATE)
        self._draw_confetti(cv, t)
        return cv.render()

    def _type_end_frame(self, cv, W, H, t):
        tp = self.tpage
        wpm, acc, el, win, note = tp["res"]
        digits = str(min(999, int(wpm)))
        rows = self._block_text(digits, self._DIGL)
        lab = self._block_text("WPM", _GLYPHS)
        total_w = disp_width(rows[0] if rows else "") + 4 + \
            (disp_width(lab[0]) if lab else 0)
        x0 = max(2, (W - total_w) // 2)
        y0 = max(2, H // 2 - 8)
        for ry, line in enumerate(rows[:6]):
            for i, c2 in enumerate(line):
                if c2 != " ":
                    cv.set(x0 + i, y0 + ry, c2, grad((i + ry * 2) / 30.0))
        if lab:
            xl = x0 + disp_width(rows[0]) + 4
            for ry, line in enumerate(lab[:6]):
                for i, c2 in enumerate(line):
                    if c2 != " ":
                        cv.set(xl + i, y0 + ry, c2, scale(C_PINK, 0.9))
        sy = y0 + 7
        segs = [("%.1f WPM" % wpm, C_GOLD), ("  •  ", C_DIM),
                ("%.0f%% acc" % acc, C_CYAN), ("  •  ", C_DIM),
                ("max combo %d" % tp["maxcombo"], C_VALUE)]
        put_segs(cv, max(2, (W - disp_width("".join(x for x, _ in segs))) // 2), sy, segs)
        sy += 1
        if tp.get("pb"):
            put_segs(cv, max(2, (W - 22) // 2), sy, [("🏆 NEW PERSONAL BEST!", C_GOLD)])
            sy += 1
        if note:
            put_segs(cv, max(2, (W - disp_width(note)) // 2), sy, [(note, C_RED if win is False else C_FUCHSIA)])
            sy += 1
        if tp.get("streak"):
            put_segs(cv, max(2, (W - 24) // 2), sy, [("🔥 streak: %d din" % tp["streak"], C_GOLD)])
            sy += 1
        wk = [k for k, v in sorted(tp["keyerr"].items(), key=lambda kv: -kv[1])[:3] if v >= 2]
        if wk:
            put_segs(cv, max(2, (W - 34) // 2), sy,
                     [("kamzor keys: ", C_DIM), (", ".join(wk), C_GOLD),
                      ("  → typing drill " + wk[0], C_SLATE)])
            sy += 1
        best = float(load_profile().get("type_best_" + tp["mode"]) or wpm)
        msg = ("momo: waah!! naya record ✦" if tp.get("pb") else
               ("momo: bas thoda! record %.0f hai" % best if wpm >= best * 0.9
                else "momo: practice makes purrfect 😸"))
        put_segs(cv, max(2, (W - disp_width(msg)) // 2), sy + 1, [(msg, C_PINK)])
        foot = "SPACE dobara • Q bahar"
        cv.put(max(2, (W - disp_width(foot)) // 2), H - 2, foot, C_SLATE)
        self._draw_confetti(cv, t)
        return cv.render()


''' + DIV2, "typing page methods")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v25")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v26 PLAY patched ✓  (backup: %s.bak-v25)" % P)
