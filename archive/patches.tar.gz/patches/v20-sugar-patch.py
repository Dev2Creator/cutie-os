import sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "_ep_lang" in s:
    print("already patched ✓"); sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

def span(start_m, end_m, new, label):
    global s
    try:
        a = s.index(start_m); b = s.index(end_m, a)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[b:]; print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[a:]; print("  ✓", label)

rep('VERSION      = "v19"', 'VERSION      = "v20"', "version")
rep('EDITION      = "CUTE EDITION"', 'EDITION      = "SUGAR EDITION"', "edition")

HELPERS = '''_LANG_ICON = {".py": ("🐍", "python"), ".c": ("⚡", "C"), ".cpp": ("⚡", "C++"),
              ".sh": ("🐚", "shell"), ".js": ("🌐", "node"), ".txt": ("📝", "text"),
              ".html": ("🌐", "html"), ".css": ("🎨", "css"), ".json": ("🧩", "json"),
              ".md": ("📖", "markdown"), ".rs": ("🦀", "rust"), ".go": ("🐹", "go")}


def _ep_lang(path):
    return _LANG_ICON.get(os.path.splitext(path)[1].lower(), ("✎", "plain"))


_CUTE_MSGS = ("✿ happy coding, cutie", "♡ momo believes in you",
              "✦ stay hydrated • sit straight", "❀ small steps, big ships",
              "✧ CTRL+D duplicates the line", "✧ CTRL+F finds anywhere",
              "✧ CTRL+G jumps to a line", "✧ CTRL+T drops a starter template",
              "🌸 ship it when it feels right")


def _ep_template_lines(path):
    if path.endswith(".py"):
        return ["#!/usr/bin/env python3",
                "# ✿ made with CUTIE editor",
                "",
                "def main():",
                '    print("hello from cutie ♡")',
                "",
                "",
                'if __name__ == "__main__":',
                "    main()",
                ""]
    if path.endswith(".c") or path.endswith(".cpp"):
        return ["#include <stdio.h>",
                "",
                "int main() {",
                '    puts("hello from cutie ♡");',
                "    return 0;",
                "}",
                ""]
    if path.endswith(".sh"):
        return ["#!/usr/bin/env bash",
                "# ✿ made with CUTIE editor",
                'echo "hello from cutie ♡"',
                ""]
    if path.endswith(".js"):
        return ['console.log("hello from cutie ♡");', ""]
    return ["✿ new cutie file", ""]


'''

block("def tool_ed(app, args):", HELPERS, "sugar helpers")

SPAN_A_END = "    def build_epage_frame(self, t):"

NEW_HANDLE = '''    def handle_epage_event(self, ev):
        kind, ch = ev[0], ev[1]
        ep = self.epage
        lines = ep["lines"]
        self._ep_last_key = time.monotonic()
        if kind == "EOF":
            self.running = False
            return
        mini = ep.get("mini")
        if mini:
            if kind in ("ESC", "CTRL_C"):
                ep["mini"] = None
            elif kind == "ENTER":
                q = mini["text"].strip()
                ep["mini"] = None
                if mini["mode"] == "goto":
                    try:
                        n = int(q)
                    except Exception:
                        return
                    ep["cy"] = clamp(n - 1, 0, len(lines) - 1)
                    ep["cx"] = 0
                    ep["msg"] = "✦ line %d" % (ep["cy"] + 1)
                elif q:
                    start = ep["cy"]
                    for k in range(1, len(lines) + 1):
                        i = (start + k) % len(lines)
                        if q.lower() in lines[i].lower():
                            ep["cy"] = i
                            ep["cx"] = lines[i].lower().find(q.lower())
                            ep["msg"] = "✓ line %d pe mila" % (i + 1)
                            break
                    else:
                        ep["msg"] = "✗ nahi mila: " + q[:30]
                else:
                    return
                ep["msg_t"] = time.monotonic()
                self._epage_ensure_visible()
            elif kind == "BACKSPACE":
                mini["text"] = mini["text"][:-1]
            elif kind == "CHAR" and ch and ch not in ("\\n", "\\r"):
                mini["text"] = (mini["text"] + ch)[:40]
            return
        if kind == "CTRL_Q":
            if ep["dirty"] and not ep.get("confirm"):
                ep["confirm"] = True
                ep["msg"] = "⚠ modified! CTRL+Q dobara = bina save chhodo"
                ep["msg_t"] = time.monotonic()
                return
            self.epage = None
            return
        ep["confirm"] = False
        if kind in ("CTRL_S", "F2"):
            self._epage_save()
            return
        if kind == "F1":
            self._epage_run()
            return
        if kind == "ESC":
            if ep["dirty"]:
                ep["msg"] = "dirty — CTRL+S save • CTRL+Q ×2 discard"
                ep["msg_t"] = time.monotonic()
            else:
                self.epage = None
            return
        if kind == "CTRL_C":
            ep["msg"] = "✿ editor se bahar = CTRL+Q"
            ep["msg_t"] = time.monotonic()
            return
        if kind == "CTRL_D":
            ln = lines[ep["cy"]]
            lines.insert(ep["cy"] + 1, ln)
            ep["cy"] += 1
            ep["cx"] = len(ln)
            ep["dirty"] = True
            ep["msg"] = "⧉ line duplicated"
            ep["msg_t"] = time.monotonic()
            self._epage_ensure_visible()
            return
        if kind == "CTRL_K":
            if len(lines) > 1:
                lines.pop(ep["cy"])
                if ep["cy"] >= len(lines):
                    ep["cy"] = len(lines) - 1
                ep["cx"] = min(ep["cx"], len(lines[ep["cy"]]))
            else:
                lines[0] = ""
                ep["cx"] = 0
            ep["dirty"] = True
            ep["msg"] = "✂ line gayi"
            ep["msg_t"] = time.monotonic()
            self._epage_ensure_visible()
            return
        if kind == "CTRL_F":
            ep["mini"] = {"mode": "find", "text": ""}
            return
        if kind == "CTRL_G":
            ep["mini"] = {"mode": "goto", "text": ""}
            return
        if kind == "CTRL_T":
            if lines == [""] and not ep["dirty"]:
                lines[:] = _ep_template_lines(ep["path"])
                ep["cy"] = min(2, len(lines) - 1)
                ep["cx"] = 0
                ep["dirty"] = True
                ep["msg"] = "✿ template aa gaya — likhna shuru!"
                ep["msg_t"] = time.monotonic()
            else:
                ep["msg"] = "✧ template sirf khaali file pe"
                ep["msg_t"] = time.monotonic()
            return
        if kind == "CHAR":
            if ch in ("\\n", "\\r"):
                self._epage_enter()
                self._epage_ensure_visible()
                return
            ln = lines[ep["cy"]]
            nxt = ln[ep["cx"]] if ep["cx"] < len(ln) else ""
            pairs = {"(": ")", "[": "]", "{": "}"}
            if ch == "\\t":
                lines[ep["cy"]] = ln[:ep["cx"]] + "    " + ln[ep["cx"]:]
                ep["cx"] += 4
            elif ch in pairs:
                lines[ep["cy"]] = ln[:ep["cx"]] + ch + pairs[ch] + ln[ep["cx"]:]
                ep["cx"] += 1
            elif ch in (")", "]", "}") and nxt == ch:
                ep["cx"] += 1
            elif ch in ('"', "'") and nxt == ch:
                ep["cx"] += 1
            elif ch in ('"', "'"):
                lines[ep["cy"]] = ln[:ep["cx"]] + ch + ch + ln[ep["cx"]:]
                ep["cx"] += 1
            else:
                lines[ep["cy"]] = ln[:ep["cx"]] + ch + ln[ep["cx"]:]
                ep["cx"] += len(ch)
            ep["dirty"] = True
            self._epage_ensure_visible()
            return
        if kind == "ENTER":
            self._epage_enter()
            self._epage_ensure_visible()
            return
        if kind == "BACKSPACE":
            if ep["cx"] > 0:
                ln = lines[ep["cy"]]
                prevc = ln[ep["cx"] - 1]
                nxtc = ln[ep["cx"]] if ep["cx"] < len(ln) else ""
                if (prevc in pairs and nxtc == pairs[prevc]) or \\
                        (prevc in ('"', "'") and nxtc == prevc):
                    lines[ep["cy"]] = ln[:ep["cx"] - 1] + ln[ep["cx"] + 1:]
                else:
                    lines[ep["cy"]] = ln[:ep["cx"] - 1] + ln[ep["cx"]:]
                ep["cx"] -= 1
            elif ep["cy"] > 0:
                prev = lines[ep["cy"] - 1]
                lines[ep["cy"] - 1] = prev + lines[ep["cy"]]
                lines.pop(ep["cy"])
                ep["cy"] -= 1
                ep["cx"] = len(prev)
            else:
                return
            ep["dirty"] = True
            self._epage_ensure_visible()
            return
        if kind == "DEL":
            ln = lines[ep["cy"]]
            if ep["cx"] < len(ln):
                lines[ep["cy"]] = ln[:ep["cx"]] + ln[ep["cx"] + 1:]
            elif ep["cy"] < len(lines) - 1:
                lines[ep["cy"]] = ln + lines.pop(ep["cy"] + 1)
            else:
                return
            ep["dirty"] = True
            return
        if kind == "LEFT":
            if ep["cx"] > 0:
                ep["cx"] -= 1
            elif ep["cy"] > 0:
                ep["cy"] -= 1
                ep["cx"] = len(lines[ep["cy"]])
        elif kind == "RIGHT":
            if ep["cx"] < len(lines[ep["cy"]]):
                ep["cx"] += 1
            elif ep["cy"] < len(lines) - 1:
                ep["cy"] += 1
                ep["cx"] = 0
        elif kind == "UP":
            if ep["cy"] > 0:
                ep["cy"] -= 1
                ep["cx"] = min(ep["cx"], len(lines[ep["cy"]]))
        elif kind == "DOWN":
            if ep["cy"] < len(lines) - 1:
                ep["cy"] += 1
                ep["cx"] = min(ep["cx"], len(lines[ep["cy"]]))
        elif kind == "HOME":
            ep["cx"] = 0
        elif kind == "END":
            ep["cx"] = len(lines[ep["cy"]])
        elif kind == "PGUP":
            ep["cy"] = max(0, ep["cy"] - 15)
            ep["cx"] = min(ep["cx"], len(lines[ep["cy"]]))
        elif kind == "PGDN":
            ep["cy"] = min(len(lines) - 1, ep["cy"] + 15)
            ep["cx"] = min(ep["cx"], len(lines[ep["cy"]]))
        self._epage_ensure_visible()

'''

span("    def handle_epage_event(self, ev):", SPAN_A_END, NEW_HANDLE, "editor handle v2")

DIV2 = "# ───────────────────────────── self check / main"

NEW_BUILD = '''    def build_epage_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        ep = self.epage
        for i in range(W):
            c = scale(grad(i / max(1, W - 1)), 0.8)
            cv.set(i, 0, "─", c)
            cv.set(i, H - 1, "─", c)
        for yy in range(1, H - 1):
            c = scale(grad(yy / max(1, H - 1)), 0.8)
            cv.set(0, yy, "│", c)
            cv.set(W - 1, yy, "│", c)
        cv.set(0, 0, "╭", scale(grad(0.0), 0.8))
        cv.set(W - 1, 0, "╮", scale(grad(1.0), 0.8))
        cv.set(0, H - 1, "╰", scale(grad(0.0), 0.8))
        cv.set(W - 1, H - 1, "╯", scale(grad(1.0), 0.8))
        for k in range(7):
            sx = (k * 53 + int(t * 2.5) + k * k * 13) % max(4, W - 6) + 3
            sy = (k * 29 + int(t * 1.2)) % max(1, H - 10) + 3
            if k % 3 == 0:
                cv.set(sx, sy, "·", scale(C_SLATE, 0.55))
            else:
                cv.set(sx, sy, "✦", scale(C_VIOLET, 0.38 + 0.18 * math.sin(t * 2.0 + k * 1.4)))
        icon, lname = _ep_lang(ep["path"])
        tt = "✿ edit " + icon + " "
        cv.put(2, 0, tt, C_PINK)
        x = 2 + disp_width(tt)
        nm = os.path.basename(ep["path"])
        for i, chx in enumerate(nm):
            if x >= W - 30:
                break
            cv.put(x, 0, chx, grad(i / max(1, len(nm) - 1)))
            x += char_width(chx)
        cv.put(x + 1, 0, "●" if ep["dirty"] else "○", C_GOLD if ep["dirty"] else C_SLATE)
        pos = "Ln %d, Col %d " % (ep["cy"] + 1, ep["cx"] + 1)
        cv.put(W - 2 - disp_width(pos), 0, pos, C_LABEL)
        body = H - 6
        lines = ep["lines"]
        top = clamp(ep["scroll"], 0, max(0, len(lines) - 1))
        nl = len(lines)
        for r in range(body):
            idx = top + r
            if idx >= nl:
                break
            yy = 2 + r
            cur = (idx == ep["cy"])
            cv.put(1, yy, "❯" if cur else " ", C_GOLD if cur else C_SLATE)
            nc = grad(idx / max(1, nl))
            if cur:
                nc = scale(nc, 1.45)
            cv.put(2, yy, "%4d " % (idx + 1), nc)
            ln = lines[idx]
            hs = ep["hscroll"]
            x = 7
            for seg, col in _pyhl(ln):
                segw = disp_width(seg)
                endx = x + segw
                if endx <= 7 + hs:
                    x = endx
                    continue
                if x < 7 + hs:
                    cutd = hs - (x - 7)
                    seg, segw = substr_width(seg, cutd, max(0, segw - cutd))
                if x + segw > W - 3:
                    seg, segw = substr_width(seg, 0, max(0, W - 3 - x))
                if seg:
                    cv.put(x, yy, seg, col)
                x += segw
                if x >= W - 3:
                    break
            ind = len(re.match(r"[ ]*", ln).group(0))
            for g in range(3, ind, 4):
                gx = 7 + g - hs
                if 7 <= gx < W - 3:
                    cv.set(gx, yy, "┊", scale(C_SLATE, 0.5))
        cury = 2 + (ep["cy"] - top)
        if 2 <= cury < 2 + body:
            curline = lines[ep["cy"]]
            visx = 7 + max(0, ep["cx"] - ep["hscroll"])
            if visx < W - 3:
                if (t % 1.1) < 0.6:
                    chb = curline[ep["cx"]] if ep["cx"] < len(curline) else " "
                    cv.put(visx, cury, chb if chb != " " else "█", C_WHITE)
                elif ep["cx"] < len(curline):
                    cv.put(visx, cury, curline[ep["cx"]], C_WHITE)
        idle = time.monotonic() - getattr(self, "_ep_last_key", time.monotonic())
        pname = getattr(self, "_pet_name", "momo").lower()
        if idle > 45:
            mx = max(4, W - 18)
            my2 = max(4, H // 2)
            cv.put(mx, my2, "=︿=", scale(C_PINK, 0.65))
            zy = my2 - 1 + int(t * 0.8) % 2
            cv.put(mx + 5, zy, "z", scale(C_SLATE, 0.75))
            cv.put(mx + 7, zy - 1, "z", scale(C_SLATE, 0.5))
            cv.put(mx, my2 + 1, pname + " so rahi hai…", scale(C_SLATE, 0.75))
        my = H - 4
        mini = ep.get("mini")
        msg = ep.get("msg") or ""
        show_msg = msg and (time.monotonic() - ep.get("msg_t", 0)) < 5.0
        if mini:
            lab = "/ find: " if mini["mode"] == "find" else "/ goto: "
            cv.put(2, my, lab, C_FUCHSIA)
            cv.put(2 + disp_width(lab), my, mini["text"] + "▌", C_WHITE)
        else:
            left = "%s %s%s  %d ch" % (icon, lname, "  ●" if ep["dirty"] else "",
                                       sum(len(l) for l in lines))
            cv.put(2, my, clip(left, 34), C_LABEL)
            if show_msg:
                cv.put(max(2, (W - disp_width(msg)) // 2), my, clip(msg, W - 40), C_GOLD)
            else:
                rot = _CUTE_MSGS[int(t / 5.0) % len(_CUTE_MSGS)]
                cv.put(max(2, (W - disp_width(rot)) // 2), my, clip(rot, W - 40),
                       scale(C_PINK, 0.9))
        pd = ep["path"]
        home = os.path.expanduser("~")
        if pd.startswith(home):
            pd = pd.replace(home, "~", 1)
        cv.put(2, my + 1, clip(pd, W - 6), scale(C_SLATE, 0.85))
        foot = "F1 run • CTRL+S save • CTRL+D dup • CTRL+K cut • CTRL+F find • CTRL+G goto • CTRL+T template • CTRL+Q"
        cv.put(max(2, (W - disp_width(foot)) // 2), H - 2, clip(foot, W - 4), C_SLATE)
        return cv.render()


'''

span("    def build_epage_frame(self, t):", DIV2, NEW_BUILD, "editor build v2")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

fails = [f for f in fails if f != "help rows"]
if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

import shutil as _sh
_sh.copy(P, P + ".bak-v19")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v20 SUGAR patched ✓  (backup: %s.bak-v19)" % P)
