BUY_BRANDS = {"nu": "Whisper", "stay": "Stayfree", "fi": "Sofy", "ma": "Maxi",
              "fe": "Pee-Safe", "eve": "Everteen", "ine": "Nine", "plu": "Plush"}
BUY_SIZES = {"s": "Small", "m": "Medium", "l": "Large", "xl": "XL"}
BUY_ITEMS = {"nap": "Pad", "pan": "Period Panty", "tie": "Panty"}


def _buy_parse(text):
    items = []
    brand = ""
    for tok in re.findall(r"[A-Za-z]+", text):
        t2 = tok.lower()
        if t2 in BUY_BRANDS:
            brand = BUY_BRANDS[t2]
        elif t2 in BUY_ITEMS:
            items.append((brand + " " + BUY_ITEMS[t2]).strip())
        elif t2 in BUY_SIZES:
            if items:
                items[-1] += " - " + BUY_SIZES[t2]
    return items


def tool_buy(app, args):
    T = app.term
    if not args:
        T.dim("  buy o(wish(nu(nap(m))))  -  brands: nu stay fi ma fe eve ine plu")
        return
    hist = _jload("buy.json", [])
    if args[0] == "copy":
        if hist:
            txt = ("A Special Gift For You ✨\n" +
                   "\n".join("- " + i2 for i2 in hist[-1]["items"]))
            if shutil.which("wl-copy"):
                subprocess.run(["wl-copy"], input=txt.encode(),
                               stdout=subprocess.DEVNULL, timeout=4)
                T.push([("  📋 copied — WhatsApp-ready", C_GOLD)])
            else:
                T.push([(txt, C_VALUE)])
        else:
            T.dim("  khaali")
        return
    if args[0] == "list":
        for e2 in reversed(hist[-8:]):
            T.push([("  🛒 ", C_GOLD), (e2["d"], C_SLATE)])
            for it2 in e2["items"]:
                T.push([("      • ", C_DIM), (it2, C_VALUE)])
        return
    items = _buy_parse(" ".join(args))
    if not items:
        T.push([("  ✗ kuch samajh nahi aaya — ", C_RED), ("buy", C_GOLD),
                (" = help", C_DIM)])
        return
    hist.append({"d": time.strftime("%Y-%m-%d"), "items": items})
    _jsave("buy.json", hist[-20:])
    app.award("first_buy")
    app.add_xp(4)
    T.push([("  ╭─", C_SLATE), (" 🛒 CUTIE BUY ", C_FUCHSIA), ("─" * 22, C_SLATE)])
    for i2, it2 in enumerate(items, 1):
        T.push([("  │ %d. " % i2, C_SLATE), (it2, C_VALUE)])
    T.push([("  ╰", C_SLATE), ("─" * 36, C_SLATE), ("╯", C_SLATE)])
    T.push([("  momo: homework lag raha hai na? 😏", C_PINK)])


def tool_lang2(app, args):
    T = app.term
    if not args:
        T.dim("  lang2: q3(nap(m)) quantity • now() urgent • gift(naam) • bud(500) • # note")
        return
    code = " ".join(args)
    items = _buy_parse(code)
    flags = []
    if "now(" in code:
        flags.append("🚨 URGENT")
    if "stealth" in code:
        flags.append("📦 stealth delivery")
    mg = re.search(r'gift\(["\']([^"\')]+)', code)
    if mg:
        flags.append("🎁 For: " + mg.group(1))
    mb = re.search(r'bud\((\d+)', code)
    if mb:
        flags.append("💰 <=" + mb.group(1))
    mq = re.search(r"q(\d+)\(", code)
    if mq and items:
        items = items * int(mq.group(1))
    if not items:
        T.dim("  kuch samajh nahi aaya")
        return
    hist = _jload("buy.json", [])
    hist.append({"d": time.strftime("%Y-%m-%d"), "items": items,
                 "code": code[:50]})
    _jsave("buy.json", hist[-30:])
    app.add_xp(4)
    if len(items) >= 5:
        app.award("combo_king")
    T.push([("  ╭─", C_SLATE), (" 🛒 LANG2 ", C_FUCHSIA), ("─" * 26, C_SLATE)])
    for i2, it2 in enumerate(items, 1):
        T.push([("  │ %d. " % i2, C_SLATE), (it2, C_VALUE)])
    for f2 in flags:
        T.push([("  │ ", C_DIM), (f2, C_GOLD)])
    T.push([("  ╰", C_SLATE), ("─" * 38, C_SLATE), ("╯", C_SLATE)])
    T.push([("  momo: poora homework lag raha hai 😼", C_PINK)])


def tool_web(app, args):
    T = app.term
    scr = os.path.expanduser("~/momo-web.py")
    if not os.path.isfile(scr):
        T.push([("  ✗ pehle banao: ", C_RED), ("nano ~/momo-web.py", C_GOLD)])
        return
    if not args:
        T.dim("  usage: web <query>  •  web site:amazon.in pads")
        return
    q = " ".join(shlex.quote(a) for a in args)
    app.start_capture("python3 " + shlex.quote(scr) + " " + q)
    app.cap_t0 = time.monotonic()
    app.add_xp(1)


GM_LINES = (
    "aaj ka din tera hai — bas aise hi",
    "paani peene ka time ho gaya, meri jaan",
    "chai pi, screen se door 5 min, phir shuru",
    "aaj kuch chhota karo, par poora",
    "code tootega, fix karegi. tu hai na?",
    "aaj sirf 1% better — bas itna",
    "khaana time pe khaana bhi ek achievement hai",
    "kaam nahi hoga toh bhi tu valuable hai",
    "tumse mera favourite time subah hota hai",
    "kabhi kabhi bas... breathe. bas.",
    "momo tumhe yaad rakhega — har version me",
    "chai > panic. always.",
    "small wins dhundo — milengi",
    "aaj self-care ek task complete karo 🌷",
    "tumhara console tumse pyaar karta hai",
)


def tool_goodmorning(app, args):
    app.gmpage = {"open_t": time.monotonic()}
