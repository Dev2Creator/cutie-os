import sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "def build_mpage_frame" in s:
    print("already patched ✓"); sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

def span(start_m, end_m, new, label):
    global s
    try:
        a = s.index(start_m); b = s.index(end_m, a)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[b:]; print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[a:]; print("  ✓", label)

rep('VERSION      = "v15"', 'VERSION      = "v16"', "version")
rep('EDITION      = "MEGA EDITION"', 'EDITION      = "STAGE EDITION"', "edition")

NEW_RAW = '''def _hms(sec):
    try:
        sec = max(0, int(float(sec)))
    except Exception:
        return "?"
    if sec >= 3600:
        return "%d:%02d:%02d" % (sec // 3600, (sec % 3600) // 60, sec % 60)
    return "%d:%02d" % (sec // 60, sec % 60)


def _music_raw(app, player=None):
    if shutil.which("playerctl") is None:
        return None
    L = chr(123)
    R = chr(125)

    def pc(*rest):
        cmd = ["playerctl"]
        if player:
            cmd += ["-p", player]
        return run_cmd(cmd + list(rest), 3).strip()

    title = pc("metadata", "--format", L + "title" + R)
    if not title:
        return None
    artist = pc("metadata", "--format", L + "artist" + R)
    album = pc("metadata", "--format", L + "album" + R)
    status = (pc("status") or "Playing").capitalize()
    vol = pc("volume") or "0"
    pname = (pc("metadata", "--format", L + "playerName" + R) or player or "mpris")[:22]
    try:
        pos_f = float(pc("position") or 0)
    except Exception:
        pos_f = 0.0
    try:
        len_us = int(float(pc("metadata", "mpris:length") or 0))
    except Exception:
        len_us = 0
    return {"title": title, "artist": artist or "", "album": album or "",
            "status": status, "vol": vol, "pname": pname,
            "pos_h": _hms(pos_f), "len_h": _hms(len_us / 1e6) if len_us else "?",
            "pos_us": int(pos_f * 1e6), "len_us": len_us}


'''

span("def _music_raw(app, player=None):", "def _music_files():", NEW_RAW, "music_raw v2 (braces fixed)")

rep('''    r = _mpv_cmd(app, {"command": ["get_property", "media-title"]})
    title = (r or {}).get("data")
    if not title:
        return None''', '''    r = _mpv_cmd(app, {"command": ["get_property", "media-title"]})
    title = (r or {}).get("data")
    if not title:
        return None
    title = re.sub(r"\\.(mp3|flac|ogg|opus|wav|m4a|oga)$", "", str(title), flags=re.I)
    title = re.sub(r"_[A-Za-z0-9]{6,}$", "", title)
    title = title.replace("_", " ").strip() or str(r.get("data"))''', "mpv title clean")

rep('''        if self.help is not None:
            self.handle_help_event(ev)
            return''', '''        if self.mpage:
            self.handle_mpage_event(ev)
            return
        if self.help is not None:
            self.handle_help_event(ev)
            return''', "mpage routing")

rep('''        if self.help is not None and not L.too_small:
            cv.clear()
            return self.build_help_frame(t)''', '''        if self.mpage and not L.too_small:
            cv.clear()
            return self.build_mpage_frame(t)
        if self.help is not None and not L.too_small:
            cv.clear()
            return self.build_help_frame(t)''', "mpage frame")

rep('''        self.mpv_proc = None
        self.mpv_list = []
        self.mpv_idx = -1''', '''        self.mpv_proc = None
        self.mpv_list = []
        self.mpv_idx = -1
        self.mpage = False
        self._mi_t = 0.0''', "mpage init")

rep('''        if (not d or not d.get("title")) and _mpv_alive(self):
            d = _mpv_now(self)
        self.music_info = d''', '''        if (not d or not d.get("title")) and _mpv_alive(self):
            d = _mpv_now(self)
        self.music_info = d
        self._mi_t = now if (d and d.get("title")) else 0.0''', "mi timestamp")

rep('''    a0 = args[0].lower() if args else ""
    if a0 in ("ls", "library", "files"):
        return _music_library(app, args[1:])''', '''    a0 = args[0].lower() if args else ""
    if a0 == "page":
        app.open_mpage()
        return
    if a0 in ("ls", "library", "files"):
        return _music_library(app, args[1:])''', "music page route")

rep('''    Tool("music", ["mp", "player"], "local library + spotify/yt — play 5, pause, vol +10", "media", tool_music),''',
    '''    Tool("music", ["mp", "player"], "local library + spotify/yt — play 5, pause, vol +10", "media", tool_music),
    Tool("np", ["player"], "♪ FULL-SCREEN music page — space/n/p live controls", "media", tool_np),''', "np registry")

block("def tool_music(app, args):", '''def tool_np(app, args):
    app.open_mpage()


''', "tool_np")

DIV2 = "# ───────────────────────────── self check / main"
block(DIV2, '''    # ── v16: MUSIC STAGE PAGE ──

    def open_mpage(self):
        self.mpage = True
        self.last_music_t = 0.0
        self._music_tick()

    def _mp_ctrl(self, act, arg=None):
        if _mpv_alive(self):
            if act == "toggle":
                _mpv_cmd(self, {"command": ["cycle", "pause"]})
            elif act == "next":
                _mpv_cmd(self, {"command": ["playlist-next"]})
                if self.mpv_idx < len(self.mpv_list) - 1:
                    self.mpv_idx += 1
            elif act == "prev":
                _mpv_cmd(self, {"command": ["playlist-prev"]})
                if self.mpv_idx > 0:
                    self.mpv_idx -= 1
            elif act == "seek":
                try:
                    _mpv_cmd(self, {"command": ["seek", float(arg)]})
                except Exception:
                    pass
            elif act == "vol":
                try:
                    _mpv_cmd(self, {"command": ["add", "volume", float(arg)]})
                except Exception:
                    pass
        elif self._pc_path:
            base = ["playerctl"]
            if self.music_player:
                base += ["-p", self.music_player]
            if act == "toggle":
                run_cmd(base + ["play-pause"], 3)
            elif act in ("next", "prev"):
                run_cmd(base + ["previous" if act == "prev" else "next"], 3)
            elif act == "seek":
                run_cmd(base + ["position", ("%d+" % int(arg)) if arg > 0 else ("%d-" % int(-arg))], 3)
            elif act == "vol":
                run_cmd(base + ["volume", ("%.2f+" % (arg / 100.0)) if arg > 0 else ("%.2f-" % (-arg / 100.0))], 3)
        self.last_music_t = 0.0
        self._music_tick()

    def handle_mpage_event(self, ev):
        kind, ch = ev[0], ev[1]
        if kind == "EOF":
            self.running = False
            return
        if kind in ("CTRL_C", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
            self.mpage = False
            return
        if kind == "CHAR" and ch == " ":
            self._mp_ctrl("toggle")
        elif kind == "CHAR" and ch in ("n", "N"):
            self._mp_ctrl("next")
        elif kind == "CHAR" and ch in ("p", "P"):
            self._mp_ctrl("prev")
        elif kind == "RIGHT":
            self._mp_ctrl("seek", 10)
        elif kind == "LEFT":
            self._mp_ctrl("seek", -10)
        elif kind == "CHAR" and ch in ("+", "="):
            self._mp_ctrl("vol", 5)
        elif kind == "CHAR" and ch in ("-", "_"):
            self._mp_ctrl("vol", -5)

    def build_mpage_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        b = C_TERM_BORDER
        cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", b)
        cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", b)
        for yy in range(1, H - 1):
            cv.put(0, yy, "│", b)
            cv.put(W - 1, yy, "│", b)
        mi = self.music_info
        now = time.monotonic()
        local = _mpv_alive(self)
        if not mi or not mi.get("title"):
            cv.put(max(2, (W - 20) // 2), H // 2 - 1, "♪ kuch nahi baj raha", C_FUCHSIA)
            sub = "music ls → music play 5  •  ya spotify chalao  •  Q = close"
            cv.put(max(2, (W - disp_width(sub)) // 2), H // 2 + 1, clip(sub, W - 4), C_DIM)
            return cv.render()
        title = mi.get("title") or "?"
        artist = mi.get("artist") or ""
        status = mi.get("status", "Playing")
        sym = {"Playing": "▶", "Paused": "❚❚", "Stopped": "■"}.get(status, "♪")
        cv.put(2, 1, clip("♪ NOW PLAYING", W - 4), C_TITLE)
        if local:
            tag = "local • mpv"
            if self.mpv_list:
                tag += "  •  %d/%d" % (self.mpv_idx + 1, len(self.mpv_list))
        else:
            tag = mi.get("pname") or "mpris"
        cv.put(max(14, W - 2 - disp_width(tag)), 1, clip(tag, W - 16), C_SLATE)
        ty = max(4, H // 2 - 7)
        n = max(1, len(title))
        cx = max(2, (W - disp_width(title)) // 2)
        for i, chx in enumerate(title):
            cv.put(cx, ty, chx, grad(i / float(n)))
            cx += char_width(chx)
        if artist:
            asub = "— " + artist + " —"
            cv.put(max(2, (W - disp_width(asub)) // 2), ty + 1, clip(asub, W - 6), C_LABEL)
        playing = (status == "Playing")
        eqw = min(56, W - 12)
        ex = (W - eqw) // 2
        ey = ty + 3
        for i in range(eqw):
            ph = t * 3.1 + i * 0.55
            amp = (math.sin(ph) * 0.5 + 0.5) * (math.sin(ph * 0.37 + i * 1.7) * 0.5 + 0.5)
            if not playing:
                amp *= 0.22
            hh = 1 + int(amp * 2.99)
            for k in range(hh):
                cv.set(ex + i, ey + 2 - k, "▄" if k == 0 else "█",
                       scale(grad(i / float(eqw - 1)), 0.8 if k == 0 else 1.0))
        pos = mi.get("pos_us", 0) / 1e6
        ln = mi.get("len_us", 0) / 1e6
        if playing and self._mi_t:
            pos += (now - self._mi_t)
        if ln > 0:
            pos = clamp(pos, 0.0, ln)
        by = ey + 5
        bw = max(12, W - 24)
        bx = (W - bw) // 2
        filled = int((pos / ln) * bw) if ln > 0 else 0
        for i in range(bw):
            if i < filled:
                cv.set(bx + i, by, "█", grad(i / float(bw - 1)))
            else:
                cv.set(bx + i, by, "░", C_BAR_EMPTY)
        tstr = "%s / %s" % (_hms(pos), _hms(ln) if ln > 0 else "∞")
        cv.put(max(2, (W - disp_width(tstr)) // 2), by + 1, tstr, C_VALUE)
        st = "%s %s" % (sym, status)
        cv.put(max(2, (W - disp_width(st)) // 2), by + 3, st,
               C_CYAN if playing else C_GOLD)
        volpct = None
        if local:
            rr = _mpv_cmd(self, {"command": ["get_property", "volume"]})
            try:
                volpct = float((rr or {}).get("data") or 0)
            except Exception:
                volpct = None
        elif mi.get("vol"):
            try:
                volpct = float(mi["vol"]) * 100.0
            except Exception:
                volpct = None
        fy = H - 2
        if volpct is not None and by + 5 < fy:
            vbw = 12
            vbx = (W - vbw) // 2
            vby = by + 5
            vf = int(clamp(volpct, 0, 100) / 100.0 * vbw)
            cv.put(vbx - 5, vby, "VOL ", C_LABEL)
            for i in range(vbw):
                cv.set(vbx + i, vby, "█" if i < vf else "░",
                       C_CYAN if i < vf else C_BAR_EMPTY)
            cv.put(vbx + vbw + 1, vby, "%3.0f%%" % volpct, C_VALUE)
        foot = "SPACE pause • N next • P prev • ←→ seek 10s • +/- vol • Q close"
        cv.put(max(2, (W - disp_width(foot)) // 2), fy, clip(foot, W - 4), C_SLATE)
        return cv.render()


''' + DIV2, "stage page methods")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

import shutil as _sh
_sh.copy(P, P + ".bak-v15")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v16 STAGE patched ✓  (backup: %s.bak-v15)" % P)
