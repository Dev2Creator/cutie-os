import sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "_epage_flush_out" in s:
    print("already patched ✓"); sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

def span(a_m, b_m, new, label):
    global s
    try:
        a = s.index(a_m); b = s.index(b_m, a)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[b:]; print("  ✓", label)

rep('VERSION      = "v21"', 'VERSION      = "v22"', "version")
rep('EDITION      = "GLOW EDITION"', 'EDITION      = "PANEL EDITION"', "edition")

rep('''        if _lang:
            _run_banner(self, _lang, "▶ live output — CTRL+C kill")''',
    '''        if _lang and self.epage is None:
            _run_banner(self, _lang, "▶ live output — CTRL+C kill")''', "banner only outside editor")

rep('''        if kind == "CTRL_C":
            ep["msg"] = "✿ editor se bahar = CTRL+Q"
            ep["msg_t"] = time.monotonic()
            return''', '''        if kind == "CTRL_C":
            if self.term.busy:
                self.kill_capture()
                ep["msg"] = "✗ job killed (CTRL+C)"
            else:
                ep["msg"] = "✿ editor se bahar = CTRL+Q"
            ep["msg_t"] = time.monotonic()
            return''', "ctrl-c kills job")

rep('''                ep["msg_t"] = time.monotonic()
                return
            self.epage = None
            return''', '''                ep["msg_t"] = time.monotonic()
                return
            self._epage_flush_out()
            self.epage = None
            self.epage_out = False
            return''', "ctrl-q flush")

rep('''            else:
                self.epage = None
            return''', '''            else:
                self._epage_flush_out()
                self.epage = None
                self.epage_out = False
            return''', "esc flush")

NEW_RUN = '''    def _epage_flush_out(self):
        ep = self.epage
        ol = ep.get("out") or []
        if not ol or self.term.busy:
            return
        T = self.term
        T.push([("  ▢ editor output (aakhri lines) —", C_DIM)])
        for segs in ol[-8:]:
            T.push(segs if isinstance(segs, list) else [(str(segs), C_OUT)])
        T.push([("  ▢ (editor band — dobara F1 = fresh run)", C_SLATE)])

    def _epage_run(self):
        ep = self.epage
        if self.term.busy:
            ep["msg"] = "⏳ pehle wala chal raha — CTRL+C kill kar"
            ep["msg_t"] = time.monotonic()
            return
        if not self._epage_save(quiet=True):
            return
        path = ep["path"]
        ext = os.path.splitext(path)[1].lower()
        exe = shutil.which("python3") or shutil.which("python")
        cmd = None
        colorize = False
        if ext == ".py" and exe:
            cmd = shlex.quote(exe) + " " + shlex.quote(path)
            colorize = True
        elif ext == ".sh":
            cmd = "bash " + shlex.quote(path)
        elif ext in (".c", ".cpp"):
            cc = shutil.which("gcc" if ext == ".c" else "g++")
            if cc is None:
                ep["msg"] = "✗ gcc/g++ nahi — !sudo pacman -S gcc"
                ep["msg_t"] = time.monotonic()
                return
            outb = "/tmp/cutie-cc-%d" % os.getpid()
            cmd = shlex.quote(cc) + " " + shlex.quote(path) + " -o " + outb + " && " + outb
        elif ext == ".js" and shutil.which("node"):
            cmd = shlex.quote(shutil.which("node")) + " " + shlex.quote(path)
        else:
            ep["msg"] = "✧ .py .sh .c .cpp .js hi run hote hain"
            ep["msg_t"] = time.monotonic()
            return
        ep["out"] = []
        ep["out_mode"] = True
        ep["msg"] = "▶ running " + os.path.basename(path) + " … (CTRL+C kill)"
        ep["msg_t"] = time.monotonic()
        self.epage_out = True
        self.start_capture(cmd)
        if colorize:
            self.cap_colorizer = _py_out_colorizer
        self.cap_t0 = time.monotonic()
        self.cmd_tick()
        self.add_xp(2)

'''

span("    def _epage_run(self):", "    def _epage_enter(self):", NEW_RUN, "run in-editor")

OLD_PUMP = '''            if item is None:
                code = self.cap_proc.returncode
                self.term.busy = False
                self.cap_q = None
                self.cap_proc = None
                self.cap_colorizer = None
                dur = ("  •  %.1fs" % max(0.0, time.monotonic() - self.cap_t0)) if self.cap_t0 else ""
                self.cap_t0 = None
                if code == 0:
                    self.term.push([("▸ done ✦" + dur, C_GOLD if dur else C_DIM)])
                else:
                    self.term.push([("▸ exit %d" % code + dur, C_RED)])
                return
            if self.cap_colorizer:
                self.term.push(self.cap_colorizer(item))
            else:
                self.term.push(item)
            n += 1'''

NEW_PUMP = '''            in_ep = (self.epage is not None and getattr(self, "epage_out", False))
            if item is None:
                code = self.cap_proc.returncode
                self.term.busy = False
                self.cap_q = None
                self.cap_proc = None
                self.cap_colorizer = None
                dur = ("  •  %.1fs" % max(0.0, time.monotonic() - self.cap_t0)) if self.cap_t0 else ""
                self.cap_t0 = None
                self.epage_out = False
                if in_ep:
                    epo = self.epage
                    if code == 0:
                        epo["out"].append([("▸ done ✦" + dur, C_GOLD)])
                        epo["msg"] = "✓ done ✦" + dur
                    else:
                        epo["out"].append([("▸ exit %d" % code + dur, C_RED)])
                        epo["msg"] = "✗ exit %d" % code + dur
                    epo["msg_t"] = time.monotonic()
                elif code == 0:
                    self.term.push([("▸ done ✦" + dur, C_GOLD if dur else C_DIM)])
                else:
                    self.term.push([("▸ exit %d" % code + dur, C_RED)])
                return
            if in_ep:
                epo = self.epage
                epo.setdefault("out", []).append(
                    self.cap_colorizer(item) if self.cap_colorizer else [(item, C_OUT)])
                if len(epo["out"]) > 240:
                    del epo["out"][:80]
            elif self.cap_colorizer:
                self.term.push(self.cap_colorizer(item))
            else:
                self.term.push(item)
            n += 1'''

rep(OLD_PUMP, NEW_PUMP, "pump divert")

rep('''        content_top = 8 if show_banner else 2
        body = max(1, H - 5 - content_top)''',
    '''        content_top = 8 if show_banner else 2
        show_out = bool(ep.get("out")) or bool(ep.get("out_mode"))
        out_rows = 5 if show_out else 0
        body = max(1, H - 5 - content_top - out_rows)''', "body shrink")

rep('''        idle = now - getattr(self, "_ep_last_key", now)''',
    '''        if show_out:
            ow = (code_w - 2) if use_preview else (W - 2)
            ox = 1
            y0 = content_top + body
            if y0 < H - 6:
                cv.put(ox, y0, "◆ OUTPUT", C_TITLE)
                lab = "── live — CTRL+C kill " if self.term.busy else "── tail "
                rem = max(0, ow - 9 - disp_width(lab) - 1)
                cv.put(ox + 9, y0, lab + "─" * rem, scale(C_SLATE, 0.7))
                ol = ep.get("out") or []
                vis = max(0, out_rows - 1)
                for i2, segs in enumerate(ol[-vis:] if vis else []):
                    ry2 = y0 + 1 + i2
                    x2 = ox + 1
                    for t2, c2 in segs:
                        w2 = disp_width(t2)
                        if w2 > ow - x2 - 1:
                            t2 = substr_width(t2, 0, max(0, ow - x2 - 1))[0]
                        if t2:
                            cv.put(x2, ry2, t2, c2)
                            x2 += disp_width(t2)
                        if x2 >= ow:
                            break
        idle = now - getattr(self, "_ep_last_key", now)''', "output pane draw")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

import shutil as _sh
_sh.copy(P, P + ".bak-v21")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v22 PANEL patched ✓  (backup: %s.bak-v21)" % P)
