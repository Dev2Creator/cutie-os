import re
import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "tool_breathe" in s:
    print("already patched ✓")
    sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label)
        print("  ✗", label)
        return
    s = s.replace(old, new, 1)
    print("  ✓", label)

def rx(pat, repl, label):
    global s
    s2, n = re.subn(pat, repl, s, count=1)
    if n == 0:
        fails.append(label)
        print("  ✗", label)
        return
    s = s2
    print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label)
        print("  ✗", label)
        return
    s = s[:a] + new + s[a:]
    print("  ✓", label)

rx(r'VERSION\s*=\s*"[^"]*"', 'VERSION      = "v31"', "version")
rx(r'EDITION\s*=\s*"[^"]*"', 'EDITION      = "BLOOM CARE"', "edition")

rep('''    ("ttt_win5", "X Master", "tic-tac-toe 5 jeet"),''',
    '''    ("ttt_win5", "X Master", "tic-tac-toe 5 jeet"),
    ("breathe1", "First Breath", "breathing session poora kiya"),
    ("sc_streak5", "Bloom Keeper", "5-din selfcare streak"),
    ("love5", "Self-Love Pro", "5 proud moments save kiye"),
    ("mood30", "Mood Mapper", "30 mood logs"),''',
    "care achievements")

rep('''        self.tpage = None
        self.cpage_bloom = None''', '''        self.tpage = None
        self.cpage_bloom = None
        self.breathe = None
        self.care = None''', "care init")

rep('''        if self.cpage_bloom:
            self.handle_cycle_event(ev)
            return''', '''        if self.breathe:
            self.handle_breathe_event(ev)
            return
        if self.care:
            self.handle_care_event(ev)
            return
        if self.cpage_bloom:
            self.handle_cycle_event(ev)
            return''', "care routing")

rep('''        if self.dash and not L.too_small:
            cv.clear()
            return self.build_dash_frame(t)''', '''        if self.breathe:
            cv.clear()
            return self.build_breathe_frame(t)
        if self.care:
            cv.clear()
            return self.build_care_frame(t)
        if self.cpage_bloom:
            cv.clear()
            return self.build_cycle_frame(t)''', "care frames")

rep('''    Tool("cycle", ["periodpage"], "FULL-SCREEN cycle wheel page 🌸", "life", tool_cyclepage),''',
    '''    Tool("cycle", ["periodpage"], "FULL-SCREEN cycle wheel page 🌸", "life", tool_cyclepage),
    Tool("selfcare", ["garden"], "self-care garden — daily tasks + 🌷 streaks", "life", tool_selfcare),
    Tool("mood", ["feel"], "mood check-in — 14-day sparkline + phase link", "life", tool_mood),
    Tool("love", ["proud"], "proud-moments vault — sad din pe yaad dilata hai", "life", tool_love),
    Tool("breathe", ["calm"], "guided breathing flower — 4-4-6, anxiety ka dushman", "life", tool_breathe),''',
    "care registry")

rep('''        if self.info.bat:
            segs += [("   BAT ", C_LABEL), (str(self.info.bat[0]) + "%", C_VALUE)]''',
    '''        if self.info.bat:
            segs += [("   BAT ", C_LABEL), (str(self.info.bat[0]) + "%", C_VALUE)]
        _cj = _jload("care.json", {})
        _td = time.strftime("%Y-%m-%d")
        _mt = next((m2.get("v") for m2 in reversed(_cj.get("mood", []))
                    if m2.get("d") == _td), None)
        if _mt is not None and 1 <= _mt <= 6:
            segs += [("  ", C_DIM), (CARE_FACES[_mt - 1], C_VALUE)]
        _sc_days = len(set(x2.get("d") for x2 in _cj.get("sc", []) if x2.get("ids")))
        if _sc_days:
            segs += [("  🌷", C_PINK), (str(_sc_days), C_VALUE)]''',
    "dash care card")

DATA = '''CARE_FACES = ("😄", "😊", "😐", "😢", "😤", "😴")
CARE_VALS = (5, 4, 3, 2, 2, 3)
CARE_MOOD_MSG = {
    5: "aaj toh full toofani energy!! export karo isko 🌞",
    4: "achhi vibe hai — isko save karne ka mann kare to love add 🌸",
    3: "neutral bhi ek valid jagah hai — paani piyo, chalte raho",
    2: "aaj bhaari lag raha hai — breathe try kar? ya love dekh 💜",
    2: "gussa = energy hai bas direction chahiye — likh ke nikal",
    3: "neend ki kami sab kuch kharab karti — aaj jaldi soyo?",
}
SC_TASKS = ("10 min walk / stretch", "paani 2 glass", "skin routine",
            "5 min deep breathe", "ek achhi baat khud ke baare me",
            "proper khana")
MOMO_CARE2 = {
    "good": "( ^ω^ )", "mid": "( ^..^ )", "low": "( ;_; )",
}


def _care_load():
    return _jload("care.json", {"mood": [], "love": [], "sc": []})


def _care_save(d2):
    _jsave("care.json", d2)


def _sc_today(d2):
    td = time.strftime("%Y-%m-%d")
    for e2 in d2["sc"]:
        if e2["d"] == td:
            return e2
    e2 = {"d": td, "ids": []}
    d2["sc"].append(e2)
    return e2


def _sc_streak(d2):
    days = set(e2["d"] for e2 in d2["sc"] if e2.get("ids"))
    n = 0
    cur = time.time()
    while True:
        dd = time.strftime("%Y-%m-%d", time.localtime(cur))
        if dd in days:
            n += 1
            cur -= 86400.0
        else:
            break
    return n


def tool_selfcare(app, args):
    app.care = {"mode": "sc", "msg": "", "msg_t": 0.0,
                "open_t": time.monotonic()}


def tool_mood(app, args):
    T = app.term
    d2 = _care_load()
    if args and args[0].isdigit() and 1 <= int(args[0]) <= 6:
        v = int(args[0])
        note = " ".join(args[1:])[:60]
        d2["mood"].append({"d": time.strftime("%Y-%m-%d"),
                           "v": v, "n": note})
        d2["mood"] = d2["mood"][-60:]
        _care_save(d2)
        T.push([("  " + CARE_FACES[v - 1] + " logged » ", C_DIM),
                (CARE_MOOD_MSG[v - 1], C_PINK)])
        if note:
            T.push([("  note » ", C_DIM), (note, C_VALUE)])
        info = _cy_phase_of(app)
        if info:
            T.push([("  phase link » ", C_DIM),
                    (PHASES[info["phase"]][1] + " — mood is phase me common",
                     C_SLATE)])
        if v <= 2:
            T.push([("  ♡ ", C_GOLD), ("breathe ya love try kar — momo hai tere paas", C_PINK)])
        app.add_xp(2)
        return
    T.head("◆ MOOD CHECK-IN")
    for i2, f2 in enumerate(CARE_FACES):
        T.push([("  " + str(i2 + 1) + ". ", C_SLATE), (f2, C_VALUE),
                ("  " + ["full energy", "achhi vibe", "theek-thaak", "bhaari",
                          "gussa", "soyi hui"][i2], C_DIM)])
    T.dim("  usage: mood 2   ya note ke saath: mood 4 ghar jaana hai")
    hist = d2["mood"][-14:]
    if hist:
        spark = []
        dd2 = {m2["d"]: m2["v"] for m2 in d2["mood"]}
        cur = time.time() - 13 * 86400.0
        for i2 in range(14):
            dd = time.strftime("%Y-%m-%d", time.localtime(cur))
            v = dd2.get(dd)
            spark.append("▁▂▃▄▅"[v - 1] if v else "·")
            cur += 86400.0
        T.push([("  14 din » ", C_DIM), ("".join(spark), C_CYAN)])
    T.dim("  🔒 sab local — care.json")


def tool_love(app, args):
    T = app.term
    d2 = _care_load()
    if args and args[0] == "add" and len(args) >= 2:
        txt = " ".join(args[1:])[:120]
        d2["love"].append({"d": time.strftime("%Y-%m-%d"), "t": txt})
        _care_save(d2)
        app.add_xp(3)
        if len(d2["love"]) >= 5:
            app.award("love5")
        T.push([("  💜 saved » ", C_DIM), (txt, C_VALUE)])
        T.dim("  yeh kabhi kabhi tujhe yaad dilayenge — ki tu kitni badass hai")
        return
    if args and args[0] == "list":
        T.head("◆ PROUD VAULT — %d memories" % len(d2["love"]))
        for e2 in reversed(d2["love"][-15:]):
            T.push([("  💜 ", C_GOLD), (e2["d"], C_SLATE), ("  ", C_DIM),
                    (e2["t"], C_VALUE)])
        if not d2["love"]:
            T.dim("  (khaali) — love add aaj maine test pass kiya!")
        return
    if not d2["love"]:
        T.dim("  vault khaali hai — pehli memory: love add aaj maine cutie banayi")
        return
    e2 = random.choice(d2["love"])
    T.push([("  ╭─", C_SLATE), (" 💜 YAAD HAI? ", C_FUCHSIA), ("─" * 24, C_SLATE)])
    T.push([("  │ ", C_SLATE), (e2["t"], C_VALUE)])
    T.push([("  │ ", C_SLATE), ("(" + e2["d"] + " ko tu ne ye kiya thi)", C_DIM)])
    T.push([("  ╰", C_SLATE), ("─" * 36, C_SLATE), ("╯", C_SLATE)])
    T.push([("  momo ( ^ω^ ): ", C_PINK), ("tu ye sab kar sakti hai — aaj bhi kar sakti hai ♡", C_LABEL)])


def tool_breathe(app, args):
    app.breathe = {"t0": time.monotonic(), "n": 0, "done": False,
                   "done_t": 0.0}


'''

block("def tool_music(app, args):", DATA, "care tools")

DIV2 = "# ───────────────────────────── self check / main"
block(DIV2, '''    # ── v31: SELF-CARE PAGE + BREATHE PAGE ──

    def handle_care_event(self, ev):
        kind, ch = ev[0], ev[1]
        cp = self.care
        if kind == "EOF":
            self.running = False
            return
        if kind in ("CTRL_C", "CTRL_Q", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
            self.care = None
            return
        if kind == "CHAR" and ch and ch.isdigit() and ch != "0":
            i2 = int(ch) - 1
            if 0 <= i2 < len(SC_TASKS):
                d2 = _care_load()
                e2 = _sc_today(d2)
                if i2 + 1 in e2["ids"]:
                    e2["ids"].remove(i2 + 1)
                else:
                    e2["ids"].append(i2 + 1)
                    self.add_xp(1)
                _care_save(d2)
                if len(e2["ids"]) == len(SC_TASKS):
                    cp["msg"] = "✿ POORA DIN COMPLETE! momo proud 😻"
                    cp["conf_t"] = time.monotonic()
                    self.confetti_until = time.monotonic() + 3.0
                    cols = list(GRAD_STOPS) + [C_GOLD, C_WHITE]
                    self.confetti = [{"x": random.uniform(0, self.cv.w),
                                      "y": random.uniform(-24, 0),
                                      "vy": random.uniform(10, 26),
                                      "c": random.choice(cols),
                                      "ch": random.choice("✦*·+•")}
                                     for _ in range(60)]
                elif len(e2["ids"]) == 1:
                    cp["msg"] = "pehla step! baaki bhi ho jayenge ♡"
                cp["msg_t"] = time.monotonic()
                stk = _sc_streak(d2)
                if stk >= 5:
                    self.award("sc_streak5")

    def build_care_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        b = C_TERM_BORDER
        cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", b)
        cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", b)
        for yy in range(1, H - 1):
            cv.put(0, yy, "│", b)
            cv.put(W - 1, yy, "│", b)
        self._sanct_petal_rain(cv, W, H, t)
        cp = self.care
        d2 = _care_load()
        cv.put(2, 1, "✿ SELF-CARE GARDEN", C_TITLE)
        stk = _sc_streak(d2)
        cv.put(W - 2 - (10 + len(str(stk))), 1,
               "🌷 streak " + str(stk), C_GOLD if stk else C_SLATE)
        y2 = 4
        x2 = max(4, W // 2 - 26)
        e2 = _sc_today(d2)
        for i2, task in enumerate(SC_TASKS):
            done = (i2 + 1) in e2["ids"]
            box = "[✓]" if done else "[ ]"
            cv.put(x2, y2 + i2 * 2, box, C_GOLD if done else C_SLATE)
            cv.put(x2 + 4, y2 + i2 * 2,
                   str(i2 + 1) + ". " + task,
                   C_VALUE if done else C_OUT)
            if done:
                cv.put(x2 + 4 + disp_width(task) + 2, y2 + i2 * 2, "✿",
                       scale(C_PINK, 0.8))
        gy2 = y2 + len(SC_TASKS) * 2 + 1
        cv.put(x2, gy2, "garden:", C_LABEL)
        cur = time.time() - 13 * 86400.0
        segs = []
        for i2 in range(14):
            dd = time.strftime("%Y-%m-%d", time.localtime(cur))
            done = any(x2b["d"] == dd and x2b.get("ids") for x2b in d2["sc"])
            segs.append(("🌷" if done else "·", C_PINK if done else C_SLATE))
            cur += 86400.0
        put_segs(cv, x2 + 8, gy2, segs)
        msg = cp.get("msg") or ""
        if msg and (time.monotonic() - cp.get("msg_t", 0)) < 5.0:
            cv.put(max(2, (W - disp_width(msg)) // 2), gy2 + 2, msg, C_GOLD)
        cv.put(3, H - 3, "( ^..^ )", C_PINK)
        cv.put(12, H - 3, "momo: ek-ek kadam bhi count hota hai ♡", C_LABEL)
        cv.put(max(2, (W - 34) // 2), H - 2,
               "1-6 toggle • Q exit • sab local 🔒", C_SLATE)
        return cv.render()

    def handle_breathe_event(self, ev):
        kind, ch = ev[0], ev[1]
        if kind == "EOF":
            self.running = False
            return
        if kind in ("CTRL_C", "CTRL_Q", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
            self.breathe = None
            return
        if self.breathe.get("done") and kind in ("ENTER", "CHAR"):
            self.breathe = None

    def build_breathe_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        b = C_TERM_BORDER
        cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", b)
        cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", b)
        for yy in range(1, H - 1):
            cv.put(0, yy, "│", b)
            cv.put(W - 1, yy, "│", b)
        bp = self.breathe
        el = t - bp["t0"]
        if not bp.get("done") and el >= 6 * 14.0:
            bp["done"] = True
            bp["done_t"] = t
            self.award("breathe1")
            self.confetti_until = t + 3.0
            cols = list(GRAD_STOPS) + [C_GOLD, C_WHITE]
            self.confetti = [{"x": random.uniform(0, W), "y": random.uniform(-24, 0),
                              "vy": random.uniform(10, 26),
                              "c": random.choice(cols),
                              "ch": random.choice("✦*·+•")} for _ in range(60)]
            self.add_xp(5)
        cx2, cy2 = W // 2, H // 2 - 1
        if not bp.get("done"):
            cyy = el % 14.0
            bn = int(el // 14.0) + 1
            if cyy < 4.0:
                f = cyy / 4.0
                lab, col = "saans ANDAR lo ♡", C_CYAN
            elif cyy < 8.0:
                f = 1.0
                lab, col = "rokoo . . .", C_VIOLET
            else:
                f = 1.0 - (cyy - 8.0) / 6.0
                lab, col = "dheere se CHHODO . . .", C_PINK
            f = f * f * (3 - 2 * f)
            R = 4 + f * (min(9, (H - 10) // 2) - 4)
            for k in range(12):
                a2 = k / 12.0 * 6.283 + t * 0.35
                x2 = int(cx2 + math.cos(a2) * R * 2.0)
                y2 = int(cy2 + math.sin(a2) * R)
                pet = "⚘" if (k + int(t * 2)) % 3 else "✿"
                cv.set(x2, y2, pet, scale(mix(C_PINK, col, f * 0.6),
                                          0.55 + 0.45 * f))
            for k in range(8):
                a2 = k / 8.0 * 6.283 - t * 0.5
                x2 = int(cx2 + math.cos(a2) * R * 1.1)
                y2 = int(cy2 + math.sin(a2) * R * 0.55)
                cv.set(x2, y2, "·", scale(C_WHITE, 0.35 + 0.4 * f))
            cv.put(cx2 - 1, cy2, "⚘", scale(C_PINK, 0.8 + 0.2 * math.sin(t * 3.0)))
            cv.put(cx2 - disp_width(lab) // 2, cy2 + R + 2, lab, col)
            prog = "●" * bn + "○" * (6 - bn)
            cv.put(cx2 - 3, cy2 + R + 4, prog, C_SLATE)
            cv.put(3, H - 3, "( -.- )", C_PINK)
            cv.put(12, H - 3, "momo bhi saans le rahi hai… hum saath hai ♡", C_LABEL)
        else:
            big = "kitni shaant 🌸"
            cv.put(cx2 - disp_width(big) // 2, cy2, big, C_GOLD)
            sub = "6 breaths complete — jab chahiye, momo yahi hai"
            cv.put(cx2 - disp_width(sub) // 2, cy2 + 2, sub, C_LABEL)
            cv.put(3, H - 3, "( ^ω^ )", C_PINK)
        cv.put(max(2, (W - 24) // 2), H - 2, "Q exit • 4-4-6 rhythm", C_SLATE)
        self._draw_confetti(cv, t)
        return cv.render()


''' + DIV2, "care pages")

rx(r'foot = "F1 run[^"]*"', 'foot = "F1 run • CTRL+S save • CTRL+Z undo • CTRL+Y redo • CTRL+D dup • CTRL+F find • CTRL+G goto • CTRL+O jump • CTRL+E preview • CTRL+Q"', "foot keep")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v30")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v31 BLOOM CARE patched ✓  (backup: %s.bak-v30)" % P)

