import sys
P = "/home/cutie/v14-patch.py"
s = open(P, encoding="utf-8").read()

# 1) pet art — backslashes ko safe chr() version se badlo
a = s.index("PET_STAGES = (")
b = s.index("def tool_pet", a)
new_block = (
    "_EAR = chr(47) + chr(92)\n"
    "\n"
    "\n"
    "PET_STAGES = (\n"
    '    ("  " + _EAR + "_" + _EAR, " ( ^.^ )", "  > ~ <"),\n'
    '    ("  " + _EAR + "_" + _EAR, " ( o.o )", "  > ^ <", "  |   |"),\n'
    '    ("   " + _EAR + "____" + _EAR, "  (  o  o  )", "   ( =^..^= )", "    >______<"),\n'
    ")\n"
    "\n"
    "\n"
)
s = s[:a] + new_block + s[b:]
print("  ✓ pet art fixed (backslash-free)")

# 2) playerctl format — {{title}} ko {title} karo
n = 0
for name in ("title", "artist", "album", "status", "volume", "playerName",
             "duration(position)", "duration(mpris:length)", "position"):
    if "{{" + name + "}}" in s:
        s = s.replace("{{" + name + "}}", "{" + name + "}"); n += 1
print("  ✓ playerctl format fixed (%d fields)" % n)

# 3) help rows anchor ko loose karo (cosmetic line)
old_a = '("text", "games/fun: snake • hack • icat  (kitty preview)", "", "", None)]'
new_a = ('("text", "games/fun: snake • hack • icat  (kitty preview)", "", "", None),\n'
         '                 ("text", "pro: music (spotify/YT!) • pet • ach • focus 25 • timer 10m", "", "", None)]')
if old_a in s:
    s = s.replace(old_a, new_a)
    print("  ✓ help rows anchor fixed")
else:
    print("  ~ help rows — chhodega (cosmetic)")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ fixer ne patch bigaad diya?? — file NOT changed:", e)
    sys.exit(1)

open(P, "w", encoding="utf-8").write(s)
print("★ v14-patch.py repaired ✓ — ab dubara chalao")
