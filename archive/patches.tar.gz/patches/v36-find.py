import re
import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "tool_find" in s:
    print("already patched ✓")
    sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label)
        print("  ✗", label)
        return
    s = s.replace(old, new, 1)
    print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label)
        print("  ✗", label)
        return
    s = s[:a] + new + s[a:]
    print("  ✓", label)

# registry: fireworks line ke baad (v3.2.0 se guaranteed hai)
m = re.search(r'Tool\("fireworks".*\n', s)
if m:
    new_line = ('    Tool("find", ["shopfind"], '
                '"momo Amazon pe dhoondhti hai — find <query>", '
                '"life", tool_find),\n')
    s = s[:m.end()] + new_line + s[m.end():]
    print("  ✓ find registered")
else:
    fails.append("fireworks registry")
    print("  ✗ fireworks line nahi mili")

FIND_FUNC = '''def tool_find(app, args):
    T = app.term
    scr = os.path.expanduser("~/momo-find.py")
    if not os.path.isfile(scr):
        T.push([("  ✗ pehle banao: ", C_RED), ("nano ~/momo-find.py", C_GOLD)])
        return
    if not args:
        T.dim("  usage: find whisper ultra large")
        return
    q = " ".join(shlex.quote(a) for a in args)
    app.start_capture("python3 " + shlex.quote(scr) + " " + q)
    app.cap_t0 = time.monotonic()
    app.add_xp(1)


'''

block("def tool_music(app, args):", FIND_FUNC, "find func")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v35")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v3.6.0 MOMO-FIND patched ✓  (backup: %s.bak-v35)" % P)
