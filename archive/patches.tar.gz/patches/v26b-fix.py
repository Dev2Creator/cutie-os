import re, shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

rep('''def _type_wrap(text, width):
    lines = []
    cur = ""
    start = 0''', '''def _type_wrap(text, width):
    lines = []
    cur = ""
    start = 0''', "wrap check (noop)")

# Line 1323 ke aas-paas dekho kya hai
lines = s.split("\n")
print("")
print("=== Line 1320-1330 (abhi ka context) ===")
for i in range(1318, min(1332, len(lines))):
    print("%s %5d| %s" % (">>" if i == 1322 else "  ", i + 1, lines[i]))
print("")

# Common indentation issues fix karo
# Issue: TYPE_QUOTES/TYPE_CODE me join ke andar ka indent
old_fix1 = 'TYPE_CODE = (\n    "\\n".join(["def fib(n):", "    if n < 2:", "        return n",\n                "    return fib(n - 1) + fib(n - 2)"]),'
new_fix1 = 'TYPE_CODE = (\n    "\\n".join(["def fib(n):", "    if n < 2:", "        return n", "    return fib(n - 1) + fib(n - 2)"]),'
rep(old_fix1, new_fix1, "code snippet 1 inline")

old_fix2 = 'TYPE_CODE = (\n    "\\n".join(["def fib(n):", "    if n < 2:", "        return n",\n                "    return fib(n - 1) + fib(n - 2)"]),\n    "\\n".join(["for i in range(10):", "    if i % 2 == 0:", "        print(i, \'even\')",\n                "    else:", "        print(i, \'odd\')"]),'
new_fix2 = 'TYPE_CODE = (\n    "\\n".join(["def fib(n):", "    if n < 2:", "        return n", "    return fib(n - 1) + fib(n - 2)"]),\n    "\\n".join(["for i in range(10):", "    if i % 2 == 0:", "        print(i, \'even\')", "    else:", "        print(i, \'odd\')"]),'
rep(old_fix2, new_fix2, "code snippet 2 inline")

try:
    compile(s, P, "exec")
    print("  ✓ syntax sahi hai ab!")
except SyntaxError as e:
    ln = e.lineno or 0
    print("")
    print("=== ab bhi error hai — context ===")
    for i in range(max(0, ln - 9), min(len(lines), ln + 3)):
        mark = ">>" if i == ln - 1 else "  "
        print("%s %5d| %s" % (mark, i + 1, lines[i]))
    print("")
    sys.exit(1)

if fails:
    print("⚠ kuch fix nahi hue:", fails)

shutil.copy(P, P + ".bak-v26")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v26b fix applied ✓")
