import sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
fails = []

old_search = '''    else:
        q = " ".join(args).lower()
        idx = next((i for i, f in enumerate(files)
                    if q in os.path.basename(f).lower()), None)
        if idx is None:
            T.push([("  ✗ nahi mila: ", C_RED), (q, C_VALUE)])
            return'''

new_search = '''    else:
        q = " ".join(args).lower()
        words = [w for w in re.split(r"[\\s_\\-]+", q) if w]
        cand = None
        for i, f in enumerate(files):
            nm = re.sub(r"\\.(mp3|flac|ogg|opus|wav|m4a|oga)$", "",
                        os.path.basename(f).lower())
            if all(w in nm for w in words):
                cand = i
                break
        if cand is None:
            T.push([("  ✗ nahi mila: ", C_RED), (q, C_VALUE)])
            clean = [re.sub(r"_[A-Za-z0-9]{6,}\\.\\w{2,4}$", "",
                            os.path.basename(f)) for f in files]
            import difflib as _df
            close = _df.get_close_matches(q, [c.lower() for c in clean],
                                          n=4, cutoff=0.35)
            if close:
                T.push([("  matlab ye tha? ", C_DIM),
                        ("  •  ".join(close[:4]), C_GOLD)])
            T.dim("  tip: number 100% chalta hai — music ls → music play 32")
            return
        idx = cand'''

if old_search not in s:
    fails.append("search block")
else:
    s = s.replace(old_search, new_search, 1)
    print("  ✓ fuzzy search (words match + junk ignore)")

old_sub = 'sub = "— SUPREME EDITION %s • %d TOOLS • FASTFETCH MODE —" % (VERSION, len(TOOLS))'
new_sub = 'sub = "— %s %s • %d TOOLS • FASTFETCH MODE —" % (EDITION, VERSION, len(TOOLS))'
if old_sub in s:
    s = s.replace(old_sub, new_sub, 1)
    print("  ✓ subtitle ab sahi edition dikhayega")
else:
    print("  ~ subtitle anchor nahi mila (cosmetic, chhodo)")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error — file NOT changed:", e)
    sys.exit(1)
if fails:
    print("✗ anchor failed — file NOT changed:", fails)
    sys.exit(1)

import shutil as _sh
_sh.copy(P, P + ".bak-v15")
open(P, "w", encoding="utf-8").write(s)
print("★ v15b hotfix ✓")
