import sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "_mpv_alive" in s:
    print("already patched ✓"); sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[a:]; print("  ✓", label)

rep('VERSION      = "v14"', 'VERSION      = "v15"', "version")
rep('EDITION      = "PRO EDITION"', 'EDITION      = "MEGA EDITION"', "edition")

rep('''def tool_exit(app, args):
    app.running = False''', '''def tool_exit(app, args):
    _mpv_kill(app)
    app.running = False''', "exit kills mpv")

rep('''    def _music_tick(self):
        now = time.monotonic()
        if now - self.last_music_t < 3.0 or not self._pc_path:
            return
        self.last_music_t = now
        self.music_info = _music_raw(self, self.music_player)''',
    '''    def _music_tick(self):
        now = time.monotonic()
        if now - self.last_music_t < 3.0:
            return
        self.last_music_t = now
        d = _music_raw(self, self.music_player) if self._pc_path else None
        if (not d or not d.get("title")) and _mpv_alive(self):
            d = _mpv_now(self)
        self.music_info = d''', "music tick local")

rep('''        self._pet_name = _pf0.get("pet_name") or "Momo"''',
    '''        self._pet_name = _pf0.get("pet_name") or "Momo"
        self.mpv_proc = None
        self.mpv_list = []
        self.mpv_idx = -1''', "mpv init")

rep('''def tool_music(app, args):
    T = app.term
    if shutil.which("playerctl") is None:''',
    '''def tool_music(app, args):
    T = app.term
    local_alive = _mpv_alive(app)
    a0 = args[0].lower() if args else ""
    if a0 in ("ls", "library", "files"):
        return _music_library(app, args[1:])
    if a0 == "play":
        return _music_local_play(app, args[1:])
    if a0 == "stop" and local_alive:
        _mpv_kill(app)
        T.push([("  ■ local player band", C_DIM)])
        return
    if local_alive and a0 in ("pause", "resume", "toggle", "play-pause", "next",
                              "prev", "previous", "vol", "volume", "seek"):
        return _music_local_ctl(app, args)
    if shutil.which("playerctl") is None:''', "music routing")

rep('''    d = _music_raw(app, app.music_player)
    if not d or not d.get("title"):
        T.push([("  ♪ koi player nahi chal raha — ", C_DIM), ("spotify / yt-music chalao!", C_VALUE)])''',
    '''    d = _music_raw(app, app.music_player) if app._pc_path else None
    if (not d or not d.get("title")) and local_alive:
        d = _mpv_now(app)
    if not d or not d.get("title"):
        T.push([("  ♪ kuch nahi chal raha — ", C_DIM), ("music ls", C_GOLD),
                (" (local) ya spotify/yt!", C_VALUE)])''', "music fallback")

rep('''    Tool("music", ["mp", "player"], "spotify/yt-music control — play next vol seek", "media", tool_music),''',
    '''    Tool("music", ["mp", "player"], "local library + spotify/yt — play 5, pause, vol +10", "media", tool_music),''',
    "music desc")

MUSIC_FUNCS = '''MPV_SOCK = "/tmp/cutie-mpv-%d.sock" % os.getuid()
_MUSIC_EXT = (".mp3", ".flac", ".ogg", ".opus", ".wav", ".m4a", ".oga")


def _music_files():
    files = []
    seen = set()
    for d in ("~/Music", "~/music", "~/Downloads"):
        d = os.path.expanduser(d)
        if os.path.isdir(d) and d not in seen:
            seen.add(d)
            try:
                for f in sorted(os.listdir(d)):
                    if f.lower().endswith(_MUSIC_EXT) and not f.startswith("."):
                        files.append(os.path.join(d, f))
            except Exception:
                pass
    return files


def _mpv_alive(app):
    p = getattr(app, "mpv_proc", None)
    if p is not None and p.poll() is None:
        return True
    if os.path.exists(MPV_SOCK):
        try:
            sk = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sk.settimeout(0.4)
            sk.connect(MPV_SOCK)
            sk.close()
            return True
        except Exception:
            try:
                os.unlink(MPV_SOCK)
            except Exception:
                pass
    return False


def _mpv_cmd(app, cmdobj):
    try:
        sk = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sk.settimeout(1.5)
        sk.connect(MPV_SOCK)
        sk.send((json.dumps(cmdobj) + "\\n").encode("utf-8"))
        buf = b""
        try:
            while b"\\n" not in buf:
                chunk = sk.recv(65536)
                if not chunk:
                    break
                buf += chunk
        except socket.timeout:
            pass
        sk.close()
        for ln in buf.decode("utf-8", "replace").split("\\n"):
            if '"error"' in ln:
                try:
                    return json.loads(ln)
                except Exception:
                    return None
        return None
    except Exception:
        return None


def _mpv_kill(app):
    if os.path.exists(MPV_SOCK):
        _mpv_cmd(app, {"command": ["quit"]})
    p = getattr(app, "mpv_proc", None)
    if p is not None and p.poll() is None:
        try:
            p.terminate()
        except Exception:
            pass
    app.mpv_proc = None


def _mpv_start(app, files):
    _mpv_kill(app)
    exe = shutil.which("mpv")
    if not exe:
        return False
    try:
        if os.path.exists(MPV_SOCK):
            os.unlink(MPV_SOCK)
    except Exception:
        pass
    try:
        app.mpv_proc = subprocess.Popen(
            [exe, "--no-video", "--really-quiet",
             "--input-ipc-server=" + MPV_SOCK] + list(files),
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL)
    except Exception:
        app.mpv_proc = None
        return False
    for _ in range(40):
        if os.path.exists(MPV_SOCK):
            return True
        if app.mpv_proc.poll() is not None:
            return False
        time.sleep(0.05)
    return os.path.exists(MPV_SOCK)


def _mpv_now(app):
    r = _mpv_cmd(app, {"command": ["get_property", "media-title"]})
    title = (r or {}).get("data")
    if not title:
        return None

    def gp(prop, default=0.0):
        rr = _mpv_cmd(app, {"command": ["get_property", prop]})
        try:
            return float((rr or {}).get("data") or default)
        except Exception:
            return default

    def fsec(sec):
        sec = int(sec)
        return "%d:%02d" % (sec // 60, sec % 60)

    tp = gp("time-pos")
    du = gp("duration")
    rz = _mpv_cmd(app, {"command": ["get_property", "pause"]})
    paused = bool((rz or {}).get("data"))
    return {"title": str(title), "artist": "local • mpv", "album": "",
            "status": "Paused" if paused else "Playing", "vol": "", "pname": "mpv",
            "pos_h": fsec(tp), "len_h": fsec(du) if du else "?",
            "pos_us": int(tp * 1e6), "len_us": int(du * 1e6)}


def _music_library(app, args):
    T = app.term
    files = _music_files()
    if not files:
        T.dim("  ~/Music me koi audio file nahi mili")
        return
    app.mpv_list = files
    ok = shutil.which("mpv") is not None
    T.head("◆ LOCAL LIBRARY — %d songs • mpv %s" %
           (len(files), "ready ✓" if ok else "MISSING ✗"))
    flt = " ".join(args).lower() if args else ""
    cur = getattr(app, "mpv_idx", -1)
    shown = 0
    for i, f in enumerate(files):
        nm = os.path.basename(f)
        if flt and flt not in nm.lower():
            continue
        shown += 1
        T.push([("  %s%3d " % ("▶" if i == cur else " ", i + 1),
                 C_GOLD if i == cur else C_SLATE), (nm[:62], C_VALUE if i == cur else C_OUT)])
        if shown > 39:
            T.dim("  … aur bhi hain — filter: music ls hotel")
            break
    T.dim("  bajao:  music play 5   ya   music play hotel   •  stop: music stop")


def _music_local_play(app, args):
    T = app.term
    if shutil.which("mpv") is None:
        T.push([("  ✗ mpv nahi hai — ", C_RED), ("!sudo pacman -S mpv", C_GOLD)])
        return
    files = _music_files()
    if not files:
        T.dim("  ~/Music khaali hai — pehle gane daalo 🎵")
        return
    if not args:
        idx = 0
    elif args[0].isdigit():
        idx = int(args[0]) - 1
        if idx < 0 or idx >= len(files):
            T.dim("  galat number — music ls dekho")
            return
    else:
        q = " ".join(args).lower()
        idx = next((i for i, f in enumerate(files)
                    if q in os.path.basename(f).lower()), None)
        if idx is None:
            T.push([("  ✗ nahi mila: ", C_RED), (q, C_VALUE)])
            return
    app.mpv_list = files
    app.mpv_idx = idx
    if not _mpv_start(app, files):
        T.push([("  ✗ mpv start nahi hua", C_RED)])
        return
    for _ in range(12):
        if _mpv_cmd(app, {"command": ["playlist-play-index", idx]}) is not None:
            break
        time.sleep(0.1)
    app.award("musician")
    app.last_music_t = 0.0
    nm = os.path.basename(files[idx])
    T.push([("  ▶ chal raha hai » ", C_CYAN), (nm[:52], C_VALUE)])
    T.dim("  pause • next • prev • vol +10 • seek +30 • music (card) • stop")


def _music_local_ctl(app, args):
    T = app.term
    a0 = args[0].lower()

    def cmd(*rest):
        return _mpv_cmd(app, {"command": list(rest)})

    if a0 == "pause":
        cmd("set_property", "pause", True)
    elif a0 == "resume":
        cmd("set_property", "pause", False)
    elif a0 in ("toggle", "play-pause"):
        cmd("cycle", "pause")
    elif a0 == "next":
        cmd("playlist-next")
        if app.mpv_list and app.mpv_idx < len(app.mpv_list) - 1:
            app.mpv_idx += 1
    elif a0 in ("prev", "previous"):
        cmd("playlist-prev")
        if app.mpv_idx > 0:
            app.mpv_idx -= 1
    elif a0 in ("vol", "volume"):
        a2 = args[1].rstrip("%") if len(args) > 1 else "+10"
        try:
            if a2.startswith("+"):
                cmd("add", "volume", float(a2[1:]))
            elif a2.startswith("-"):
                cmd("add", "volume", -float(a2[1:]))
            else:
                cmd("set_property", "volume", clamp(float(a2), 0, 130))
        except Exception:
            T.dim("  usage: music vol 70 | +10 | -10")
            return
    elif a0 == "seek":
        a2 = args[1] if len(args) > 1 else "+30"
        try:
            if a2.startswith("+"):
                cmd("seek", float(a2[1:]))
            elif a2.startswith("-"):
                cmd("seek", -float(a2[1:]))
            else:
                cmd("seek", float(a2), "absolute")
        except Exception:
            T.dim("  usage: music seek +30 | -15 | 120")
            return
    app.award("musician")
    app.last_music_t = 0.0
    d = _mpv_now(app)
    if d:
        sym = {"Playing": "▶", "Paused": "❚❚"}.get(d["status"], "♪")
        T.push([("  %s " % sym, C_CYAN), (d["title"][:52], C_VALUE),
                ("  [%s / %s]" % (d["pos_h"], d["len_h"]), C_SLATE)])


'''

block("def tool_music(app, args):", MUSIC_FUNCS, "local player funcs")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

import shutil as _sh
_sh.copy(P, P + ".bak-v14")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v15 MEGA patched ✓  (backup: %s.bak-v14)" % P)
