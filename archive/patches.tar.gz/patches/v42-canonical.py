import re, shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
lines = s.split("\n")
steps = []

# ═══ 1. PURANE divert-blocks pump se HATAO ═══
# (lines: 'elif getattr(self, "gshop"...' se lekar block-end tak)
out = []
i = 0
removed = 0
while i < len(lines):
    st = lines[i].strip()
    if st.startswith('elif getattr(self, "gshop"') or st.startswith('elif getattr(self, "gshop_out"'):
        # is elif ke inner lines hatao (indent > 12)
        i += 1
        while i < len(lines):
            st2 = lines[i].strip()
            ind = len(lines[i]) - len(lines[i].lstrip())
            if ind <= 12 and st2 and not st2.startswith(("#",)):
                break
            i += 1
        removed += 1
        continue
    out.append(lines[i])
    i += 1
lines = out
if removed:
    steps.append("✓ %d purane divert-blocks hataye" % removed)
else:
    steps.append("~ koi purana divert nahi mila")

# ═══ 2. module-level _gshop_parse_json upgrade (tuple return) ═══
i = next((k for k, ln in enumerate(lines) if ln.startswith("def _gshop_parse_json")), -1)
if i >= 0:
    end = i + 1
    while end < len(lines) and (lines[end].startswith((" ", "\t")) or lines[end] == ""):
        end += 1
    lines[i:end] = '''def _gshop_parse_json(line):
    """Canonical parser. Returns (results, error)."""
    try:
        import json as _j
        data = _j.loads(line)
    except Exception as exc:
        return None, "Invalid JSON: %s" % str(exc)[:40]
    if not isinstance(data, list):
        return None, "Expected a JSON array"
    if any(not isinstance(row, dict) for row in data):
        return None, "Non-object entry in array"
    return data, None'''.split("\n")
    steps.append("✓ canonical _gshop_parse_json (tuple)")
else:
    print("✗ _gshop_parse_json nahi mila"); sys.exit(1)

# ═══ 3. App methods: _gshop_debug + _gshop_consume_capture_line ═══
# insert point: 'def pump_capture' se theek pehle
pi = next((k for k, ln in enumerate(lines) if "def pump_capture" in ln), -1)
if pi < 0:
    print("✗ pump_capture nahi mila"); sys.exit(1)

NEW_METHODS = '''    def _gshop_debug(self, message):
        try:
            with open("/tmp/gshop-debug.log", "a", encoding="utf-8") as f:
                f.write(str(message) + "\\n")
        except OSError:
            pass

    def _gshop_consume_capture_line(self, item):
        """True = ye line GShop JSON thi aur consume ho gayi."""
        gs = getattr(self, "gshop", None)
        if not isinstance(gs, dict):
            return False
        if not gs.get("_capture_pending", False):
            return False
        if isinstance(item, bytes):
            item = item.decode("utf-8", errors="replace")
        if not isinstance(item, str):
            return False
        line = item.rstrip("\\r\\n")
        line = re.sub(r"\\x1b\\[[0-?]*[ -/]*[@-~]", "", line)
        candidate = line.lstrip("\\ufeff \\t ")
        if not candidate.startswith("["):
            return False
        if not re.search(r'"t"\\s*:', candidate):
            return False
        self._gshop_debug("PUMP JSON candidate len=%d" % len(candidate))
        results, error = _gshop_parse_json(candidate)
        gs["_json_seen"] = True
        gs["_capture_pending"] = False
        if error is not None:
            gs["_json_received"] = False
            gs["_json_error"] = error
            gs["status"] = "parse_error"
            self._gshop_debug("PUMP parse_error=%s" % error)
            return True
        gs["results"] = results
        gs["_json_received"] = True
        gs["status"] = "ready" if results else "empty"
        gs["busy"] = False
        gs["msg"] = ("✿ %d results — 1-9 se cart" % len(results)) if results \\
            else "😿 zero results — dusri query"
        gs["msg_t"] = time.monotonic()
        self._gshop_debug("PUMP JSON accepted count=%d" % len(results))
        return True

'''

lines[pi:pi] = NEW_METHODS.split("\n")
steps.append("✓ _gshop_debug + _gshop_consume_capture_line methods")

# ═══ 4. pump me consume call — 'if in_ep:' se PEHLE ═══
ii = next((k for k in range(pi, len(lines)) if "if in_ep:" in lines[k]), -1)
if ii < 0:
    print("✗ 'if in_ep:' pump me nahi mila"); sys.exit(1)
lines[ii:ii] = ["            if self._gshop_consume_capture_line(item):",
                "                continue"]
steps.append("✓ consume-call pump me (if in_ep se pehle)")

# ═══ 5. _gshop_finish replace ═══
fi = next((k for k, ln in enumerate(lines) if ln.strip() == "def _gshop_finish(self):"), -1)
if fi < 0:
    print("✗ _gshop_finish nahi mila"); sys.exit(1)
fe = fi + 1
while fe < len(lines) and not (lines[fe].strip().startswith("def ") or
                               lines[fe].strip().startswith("# ─")):
    fe += 1
lines[fi:fe] = '''    def _gshop_finish(self):
        gs = getattr(self, "gshop", None)
        if not isinstance(gs, dict):
            return
        gs["busy"] = False
        gs["done"] = True
        if gs.get("_json_received"):
            gs["status"] = "ready" if gs.get("results") else "empty"
        elif gs.get("_json_error"):
            gs["status"] = "parse_error"
        else:
            gs["status"] = "missing_json"
        self.gshop_out = False
        self._gshop_debug(
            "FINISH json_received=%s pending=%s results=%d" %
            (gs.get("_json_received", False), gs.get("_capture_pending", False),
             len(gs.get("results", []))))'''.split("\n")
steps.append("✓ _gshop_finish v2 (results preserve)")

# ═══ 6. handle_gshop_event me state-init (start_capture se pehle) ═══
hi = next((k for k, ln in enumerate(lines)
           if 'gs["busy"] = True' in ln and 'self.gshop_out = True' in
           (lines[k + 1] if k + 1 < len(lines) else "")), -1)
if hi >= 0:
    ins_at = hi + 2  # results = [] ke baad
    lines[ins_at:ins_at] = [
        "                    gs[\"_capture_pending\"] = True",
        "                    gs[\"_json_seen\"] = False",
        "                    gs[\"_json_received\"] = False",
        "                    gs[\"_json_error\"] = None",
        "                    gs[\"status\"] = \"searching\"",
        "                    gs[\"done\"] = False",
    ]
    steps.append("✓ state-init (handle_gshop_event)")
else:
    # tool_gshop wala initial path
    ti2 = next((k for k, ln in enumerate(lines)
                if 'app.gshop["busy"] = True' in ln), -1)
    if ti2 >= 0:
        lines[ti2 + 1:ti2 + 1] = [
            "        app.gshop[\"_capture_pending\"] = True",
            "        app.gshop[\"_json_seen\"] = False",
            "        app.gshop[\"_json_received\"] = False",
            "        app.gshop[\"_json_error\"] = None",
            "        app.gshop[\"status\"] = \"searching\"",
            "        app.gshop[\"done\"] = False",
        ]
        steps.append("✓ state-init (tool_gshop path)")
    else:
        steps.append("~ state-init skip (anchor nahi mila)")

# ═══ 7. cv.clear in gshop frame (agar missing) ═══
gi = next((k for k, ln in enumerate(lines) if ln.strip() == "def build_gshop_frame(self, t):"), -1)
if gi >= 0:
    blk = "\n".join(lines[gi:gi + 6])
    if "cv.clear()" not in blk:
        lines[gi + 3:gi + 3] = ["        cv.clear()"]
        steps.append("✓ cv.clear (stale HUD fix)")
    else:
        steps.append("~ cv.clear already there")

s = "\n".join(lines)
try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax:", e)
    ls = s.split("\n")
    for i3 in range(max(0, (e.lineno or 0) - 4), min(len(ls), (e.lineno or 0) + 3)):
        print((">>" if i3 == (e.lineno or 0) - 1 else "  "), i3 + 1, "|", ls[i3])
    sys.exit(1)

shutil.copy(P, P + ".bak-v39")
open(P, "w", encoding="utf-8").write(s)
print()
for st in steps:
    print(" ", st)
print("\n★ CANONICAL GSHOP PATCHED ✓ — ab verify:")
print("  python3 -m py_compile ~/cutie-os.py && echo SYNTAX-OK")
print("  : > /tmp/gshop-debug.log")
