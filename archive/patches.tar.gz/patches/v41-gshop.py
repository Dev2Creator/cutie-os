import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if '"tool_gshop"' in s:
    print("already patched ✓"); sys.exit(0)

# version bump
s = s.replace('VERSION      = "v3.8.0"', 'VERSION      = "v3.9.0"', 1)
s = s.replace('EDITION      = "SANCTUARY+ SHOP"', 'EDITION      = "GLOBAL SHOP"', 1)

# registry
anchor = '    Tool("goodmorning", ["gm"], "Momo morning page 🌅", "life", tool_goodmorning),'
if anchor in s:
    s = s.replace(anchor, anchor + '\n    Tool("gshop", ["gs"], "🌍 GLOBAL SHOP page — search + cart + export", "life", tool_gshop),', 1)

# state init
s = s.replace("        self.gmpage = None",
              "        self.gmpage = None\n        self.gshop = None", 1)

# routing (gm se pehle)
s = s.replace("""        if self.gmpage:
            self.handle_gm_event(ev)
            return""",
"""        if self.gshop:
            self.handle_gshop_event(ev)
            return
        if self.gmpage:
            self.handle_gm_event(ev)
            return""", 1)

# frame hook
s = s.replace("""        if self.gmpage and not L.too_small:
            cv.clear()
            return self.build_gm_frame(t)""",
"""        if self.gshop and not L.too_small:
            cv.clear()
            return self.build_gshop_frame(t)
        if self.gmpage and not L.too_small:
            cv.clear()
            return self.build_gm_frame(t)""", 1)

FUNC = '''

def _gshop_parse_json(line):
    import json as _j
    try:
        return _j.loads(line)
    except Exception:
        return []


def tool_gshop(app, args):
    app.gshop = {"tab": 0, "q": "", "results": [], "cart": [],
                 "busy": False, "msg": "", "msg_t": 0.0,
                 "sel": 0, "open_t": time.monotonic()}
    if args:
        app.gshop["q"] = " ".join(args)
        app.gshop["busy"] = True
        scr = os.path.expanduser("~/momo-web.py")
        if os.path.isfile(scr):
            app.start_capture("python3 " + shlex.quote(scr) + " " +
                              shlex.quote(app.gshop["q"]) + " 10")
            app.cap_t0 = time.monotonic()


'''
marker = "def tool_goodmorning(app, args):"
i = s.index(marker)
s = s[:i] + FUNC + "\n\n" + s[i:]

METHODS = '''    def handle_gshop_event(self, ev):
        kind, ch = ev[0], ev[1]
        gs = self.gshop
        if kind == "EOF":
            self.running = False
            return
        if gs.get("busy"):
            if kind in ("CTRL_C",):
                self.kill_capture()
            return
        if kind in ("CTRL_C", "CTRL_Q", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
            if gs.get("tab") == 0 and gs.get("qinp"):
                gs["qinp"] = False
                return
            self.gshop = None
            return
        if gs.get("qinp"):
            if kind == "BACKSPACE":
                gs["q"] = gs["q"][:-1]
            elif kind == "CHAR" and ch and ch not in ("\\n", "\\r"):
                gs["q"] = (gs["q"] + ch)[:60]
            elif kind == "ENTER" and gs["q"].strip():
                scr = os.path.expanduser("~/momo-web.py")
                if os.path.isfile(scr):
                    gs["busy"] = True
                    gs["qinp"] = False
                    self.start_capture("python3 " + shlex.quote(scr) + " " +
                                       shlex.quote(gs["q"]) + " 10")
                    self.cap_t0 = time.monotonic()
            return
        tab = gs.get("tab", 0)
        if kind in ("LEFT",):
            gs["tab"] = (tab - 1) % 3
            return
        if kind in ("RIGHT",):
            gs["tab"] = (tab + 1) % 3
            return
        if kind == "CHAR":
            low = ch.lower()
            if low == "/":
                gs["qinp"] = True
                gs["q"] = ""
                return
            if tab == 0 and ch.isdigit():
                i2 = int(ch) - 1
                if 0 <= i2 < len(gs["results"]):
                    it = gs["results"][i2]
                    gs["cart"].append(it)
                    gs["msg"] = "🛒 cart me daal diya: " + it["t"][:30]
                    gs["msg_t"] = time.monotonic()
            elif tab == 1 and ch.isdigit():
                i2 = int(ch) - 1
                if 0 <= i2 < len(gs["cart"]):
                    rm = gs["cart"].pop(i2)
                    gs["msg"] = "cart se nikala: " + rm["t"][:30]
                    gs["msg_t"] = time.monotonic()
            elif tab == 2 and low == "c":
                if gs["cart"]:
                    txt = ("A Special Gift For You ✨\\n" +
                           "\\n".join("- [%s%s] %s" % (r2["c"], r2["p"],
                                                      r2["t"][:50])
                                      for r2 in gs["cart"]))
                    if shutil.which("wl-copy"):
                        subprocess.run(["wl-copy"], input=txt.encode(),
                                       stdout=subprocess.DEVNULL, timeout=4)
                        gs["msg"] = "📋 cart copied — WhatsApp-ready!"
                    else:
                        gs["msg"] = txt[:80]
                    gs["msg_t"] = time.monotonic()

    def build_gshop_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        b = C_TERM_BORDER
        cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", b)
        cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", b)
        for yy in range(1, H - 1):
            cv.put(0, yy, "│", b)
            cv.put(W - 1, yy, "│", b)
        for k in range(6):
            px2 = (k * 89 + int(t * 2.0)) % (W + 6) - 3
            py2 = (k * 53 + int(t * 1.0)) % (H + 4) - 2
            xx = int(px2 + math.sin(t + k) * 1.8)
            yy = int(py2)
            if 1 <= yy < H - 2 and 2 <= xx < W - 3:
                cv.set(xx, yy, ["·", "✿", "🌷"][k % 3], scale(C_PINK, 0.2))
        gs = self.gshop
        tabs = ("SEARCH", "CART", "EXPORT")
        segs = []
        for i2, nm in enumerate(tabs):
            cur = (i2 == gs.get("tab", 0))
            segs.append(("▸ " if cur else "  ", C_GOLD if cur else C_SLATE))
            segs.append((nm, C_GOLD if cur else C_DIM))
            segs.append(("   ", C_DIM))
        put_segs(cv, max(2, (W - disp_width("".join(x for x, _ in segs))) // 2), 1, segs)
        ttl = "🌍 GLOBAL SHOP"
        cv.put(max(2, (W - disp_width(ttl)) // 2), 2, ttl, C_TITLE)
        if gs.get("msg") and (time.monotonic() - gs.get("msg_t", 0)) < 5.0:
            cv.put(max(2, (W - disp_width(gs["msg"])) // 2), 3,
                   clip(gs["msg"], W - 6), C_GOLD)
        if gs.get("busy"):
            sp = SPIN[int(t * 10) % len(SPIN)]
            cv.put(max(2, (W - 30) // 2), H // 2,
                   sp + " momo dhoondh rahi hai…", C_CYAN)
            cv.put(max(2, (W - 30) // 2), H // 2 + 2, "CTRL+C cancel", C_SLATE)
            return cv.render()
        tab = gs.get("tab", 0)
        if tab == 0:
            qd = '🔍 press / to search' + ("   [current: " + gs["q"] + "]" if gs.get("q") else "")
            cv.put(max(2, (W - disp_width(qd)) // 2), 4, qd, C_SLATE)
            if gs.get("qinp"):
                cv.put(max(2, (W - 30) // 2), 5, "🔍 " + gs["q"] + "▌", C_WHITE)
            res = gs.get("results", [])
            if res:
                cv.put(3, 7, "GLOBAL RESULTS — %d sites (1-%d = cart me daalo):" %
                       (len(res), min(9, len(res))), C_FUCHSIA)
                for i2, it in enumerate(res[:9], 1):
                    yy = 8 + (i2 - 1) * 3
                    if yy > H - 6:
                        break
                    cv.put(3, yy, "%d. %s [%s] %s" %
                           (i2, FLAGS.get(it["r"], "🌎"), it["c"] or "  ",
                            it["t"][:W - 24]), C_VALUE)
                    if it["p"]:
                        cv.put(6, yy + 1, "💰 " + it["p"], C_GOLD)
                    cv.put(20, yy + 1, "🏪 " + it["h"], C_SLATE)
            else:
                cv.put(max(2, (W - 40) // 2), H // 2,
                       "(koi result nahi — / se search karo)", C_DIM)
        elif tab == 1:
            cart = gs.get("cart", [])
            cv.put(3, 5, "🛒 CART — %d items (1-%d nikalne ke liye):" %
                   (len(cart), min(9, len(cart))), C_FUCHSIA)
            for i2, it in enumerate(cart[:9], 1):
                yy = 6 + (i2 - 1) * 2
                cv.put(3, yy, "%d. %s%s %s" % (i2, FLAGS.get(it["r"], "🌎"),
                       it["c"] or " ", it["t"][:W - 20]), C_VALUE)
                if it["p"]:
                    cv.put(6, yy + 1, "💰 " + it["p"], C_GOLD)
            if not cart:
                cv.put(max(2, (W - 20) // 2), H // 2, "(cart khaali)", C_DIM)
        else:
            cart = gs.get("cart", [])
            cv.put(3, 5, "📤 EXPORT — %d items" % len(cart), C_FUCHSIA)
            if cart:
                yy = 7
                for it in cart[:12]:
                    cv.put(5, yy, "- [%s%s] %s" % (it["c"], it["p"],
                           it["t"][:44]), C_OUT)
                    yy += 1
                yy += 1
                cv.put(5, yy, "C dabao = clipboard copy ✨", C_GOLD)
            else:
                cv.put(max(2, (W - 24) // 2), H // 2, "(cart khaali)", C_DIM)
        cv.put(3, H - 3, "( ^ω^ )", C_PINK)
        cv.put(12, H - 3, "momo: global bazaar tere console me 🌍", C_LABEL)
        cv.put(max(2, (W - 40) // 2), H - 2,
               "/ search • 1-9 cart • ←→ tabs • C copy • Q exit", C_SLATE)
        return cv.render()


'''
marker2 = "    def handle_gm_event(self, ev):"
i2 = s.index(marker2)
s = s[:i2] + METHODS + "\n" + s[i2:]

# FLAGS constant
s = s.replace("GM_LINES = (",
              'FLAGS = {"in": "🇮🇳", "us": "🇺🇸", "uk": "🇬🇧", "de": "🇩🇪",\n'
              '        "jp": "🇯🇵", "ae": "🇦🇪", "au": "🇦🇺", "gl": "🌎"}\n\n\nGM_LINES = (', 1)

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax — NOT changed:", e)
    ls = s.split("\n")
    for i3 in range(max(0, (e.lineno or 0) - 4), min(len(ls), (e.lineno or 0) + 3)):
        print((">>" if i3 == (e.lineno or 0) - 1 else "  "), i3 + 1, "|", ls[i3])
    sys.exit(1)

shutil.copy(P, P + ".bak-v38")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v3.9.0 GLOBAL SHOP patched ✓  (backup: %s.bak-v38)" % P)
