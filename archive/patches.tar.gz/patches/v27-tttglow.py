import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "_ttt_face" in s:
    print("already patched ✓"); sys.exit(0)
fails = []

def span(a_m, b_m, new, label):
    global s
    try:
        a = s.index(a_m); b = s.index(b_m, a)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[b:]; print("  ✓", label)

span("TTT_3D = {", "def tool_music(app, args):", '''TTT_3D = {
    "X": ("███████╗", "██╔════╝", "██║  ██╗", "║  ██║", "╚█████╔╝", " ╚════╝"),
    "O": (" ██████╗ ", "██╔═══██╗", "██║   ██║", "██║   ██║", "╚██████╔╝", " ╚═════╝ "),
    " ": ("        ", "        ", "        ", "        ", "        ", "        "),
}
_TTT_L_NAMES = ("Seedhi Bacchi", "Chhoti Bacchi", "School Champion",
                "Bhavishya Darshi", "Chess Master", "IMPOSSIBLE")
_TTT_L_DEPTH = (1, 2, 4, 6, 8, 20)
_TTT_TAUNTS = (
    ("hehe yeh toh aasaan hai 😼", "dhyaan se khelo!", "=^.^= zzz…",
     "Momo so rahi thi, ab jaagi"),
    ("achha chal raha hai…", "sochne de mujhe 🤔", "hmm interesting",
     "abhi toh warmup hai"),
    ("not bad not bad 😼", "ab ghabra mat", "plan B nikalo",
     "dekho aur seekho"),
    ("strong move 🔥", "main bhi soch rahi hoon", "trap dekha maine",
     "attack best defence hai"),
    ("ooh dhang se khel rahi ho", "mere neurons jal rahe ⚡",
     "ab atka tum", "grandmaster vibes"),
    ("IMPOSSIBLE mode: thoda mushkil hoga 😼",
     "main jeetungi, bas time ki baat", "sos: udd raha hai",
     "tumhara confidence dekho!"),
)


def _ttt_winner(bd):
    wins = ((0, 1, 2), (3, 4, 5), (6, 7, 8),
            (0, 3, 6), (1, 4, 7), (2, 5, 8),
            (0, 4, 8), (2, 4, 6))
    for a, b, c2 in wins:
        if bd[a] != " " and bd[a] == bd[b] == bd[c2]:
            return bd[a], (a, b, c2)
    if all(x != " " for x in bd):
        return "draw", None
    return None, None


def _ttt_minimax(bd, turn, depth, lvl, me, opp, alpha, beta):
    w, _l = _ttt_winner(bd)
    if w == me:
        return 10 - depth, None
    if w == opp:
        return depth - 10, None
    if w == "draw":
        return 0, None
    best = (-99, None) if turn == me else (99, None)
    for i in range(9):
        if bd[i] != " ":
            continue
        bd[i] = turn
        sc, _m = _ttt_minimax(bd, opp, depth + 1, lvl, me, opp, alpha, beta)
        bd[i] = " "
        if turn == me:
            if sc > best[0]:
                best = (sc, i)
            alpha = max(alpha, sc)
        else:
            if sc < best[0]:
                best = (sc, i)
            beta = min(beta, sc)
        if beta <= alpha:
            break
    return best


def _ttt_momo_pick(bd, lvl, me, opp):
    empty = [i for i in range(9) if bd[i] == " "]
    if not empty:
        return None
    depth = _TTT_L_DEPTH[min(lvl, 5)]
    if depth <= 2:
        if random.random() < 0.65:
            return random.choice(empty)
    elif depth <= 4:
        if random.random() < 0.30:
            return random.choice(empty)
    elif depth <= 6:
        if random.random() < 0.12:
            return random.choice(empty)
    _sc, mv = _ttt_minimax(list(bd), me, 0, lvl, me, opp, -99, 99)
    return mv if mv is not None else random.choice(empty)


def _ttt_face(state, t):
    if state == "think":
        f = "( o.o )" if (int(t * 2.5) % 2) else "( -.- )"
    elif state == "happy":
        f = "( ^ω^ )"
    elif state == "sad":
        f = "( ;_; )"
    else:
        f = "( ^..^ )" if (t % 4.0) < 3.4 else "( =ω= )"
    return (" /\\_/\\ ", f, " > ~ < ")


def _ttt_paint(cv, x0, y0, bd, win_line, t, last_move):
    CW, CH = 11, 8
    fw, fh = 3 * CW, 3 * CH
    dim = scale(C_SLATE, 0.55)
    for i in range(fw):
        col = scale(grad(i / max(1, fw - 1)), 0.95)
        cv.set(x0 + i, y0 - 1, "─", col)
        cv.set(x0 + i, y0 + fh, "─", col)
    for j in range(fh):
        col = scale(grad(j / max(1, fh - 1)), 0.95)
        cv.set(x0 - 1, y0 + j, "│", col)
        cv.set(x0 + fw, y0 + j, "│", col)
    cv.set(x0 - 1, y0 - 1, "╭", scale(grad(0.0), 0.95))
    cv.set(x0 + fw, y0 - 1, "╮", scale(grad(0.5), 0.95))
    cv.set(x0 - 1, y0 + fh, "╰", scale(grad(0.5), 0.95))
    cv.set(x0 + fw, y0 + fh, "╯", scale(grad(1.0), 0.95))
    for k in (1, 2):
        gx2 = x0 + k * CW
        cv.set(gx2, y0 - 1, "┬", dim)
        cv.set(gx2, y0 + fh, "┴", dim)
        for j in range(fh):
            cv.set(gx2, y0 + j, "│", dim)
        gy2 = y0 + k * CH
        cv.set(x0 - 1, gy2, "├", dim)
        cv.set(x0 + fw, gy2, "┤", dim)
        for i in range(fw):
            cv.set(x0 + i, gy2, "─", dim)
        for k2 in (1, 2):
            cv.set(x0 + k2 * CW, gy2, "┼", dim)
    midx = [x0 + CW // 2, x0 + CW + CW // 2, x0 + 2 * CW + CW // 2]
    midy = [y0 + CH // 2, y0 + CH + CH // 2, y0 + 2 * CH + CH // 2]
    if win_line:
        for cell_i in win_line:
            r, c2 = divmod(cell_i, 3)
            px2 = x0 + c2 * CW + CW // 2
            py2 = y0 + r * CH + CH // 2
            if (t * 6.0 + cell_i) % 2.0 < 1.2:
                cv.set(px2 - 1, py2 - 1, "✦", C_GOLD)
                cv.set(px2 + 1, py2 + 1, "✦", C_GOLD)
    for cell_i in range(9):
        r, c2 = divmod(cell_i, 3)
        ox = x0 + c2 * CW + 1
        oy = y0 + r * CH + 1
        mark = bd[cell_i]
        glyph = TTT_3D.get(mark, TTT_3D[" "])
        is_win = bool(win_line and cell_i in win_line)
        is_last = (cell_i == last_move) and not win_line
        if mark == " ":
            sh = 0.42 + 0.22 * math.sin(t * 2.0 + cell_i * 1.3)
            cv.put(ox + CW - 4, oy + CH - 2, str(cell_i + 1), scale(C_SLATE, sh))
            continue
        if mark == "X":
            base = mix(C_GOLD, C_PINK, (r * 3 + c2) / 8.0)
        else:
            base = mix(C_CYAN, C_VIOLET, (r * 3 + c2) / 8.0)
        for ry, line in enumerate(glyph):
            for i, ch in enumerate(line):
                if ch != " ":
                    cv.set(ox + i + 1, oy + ry + 1, ch, scale(base, 0.22))
        for ry, line in enumerate(glyph):
            for i, ch in enumerate(line):
                if ch == " ":
                    continue
                if is_win:
                    pulse = 0.65 + 0.35 * math.sin(t * 6.0 + cell_i)
                    cc = mix(base, C_WHITE, pulse * 0.75)
                elif is_last:
                    cc = mix(base, C_WHITE, 0.30 + 0.22 * math.sin(t * 5.0))
                else:
                    cc = base
                cv.set(ox + i, oy + ry, ch, cc)
    if win_line:
        a, b, c3 = win_line
        if b == a + 1 and c3 == a + 2:
            yy = y0 + (a // 3) * CH + CH // 2
            for k in range(fw - 1):
                if (k + int(t * 12)) % 4 == 0:
                    cv.set(x0 + 1 + k, yy, "·", C_GOLD)
        elif b == a + 3 and c3 == a + 6:
            xx = x0 + (a % 3) * CW + CW // 2
            for k in range(fh - 1):
                if (k + int(t * 12)) % 4 == 0:
                    cv.set(xx, y0 + 1 + k, "·", C_GOLD)
        else:
            for k in range(1, fw - 1):
                if (k + int(t * 12)) % 4 == 0:
                    if a == 0:
                        yy = y0 + int(k / (fw - 1.0) * (fh - 1))
                    else:
                        yy = y0 + (fh - 1) - int(k / (fw - 1.0) * (fh - 1))
                    cv.set(x0 + k, yy, "·", C_GOLD)


def tool_ttt(app, args):
    T = app.term
    lvl = 2
    if args and args[0].isdigit():
        lvl = clamp(int(args[0]), 1, 6) - 1
    stats = load_profile().get("ttt_stats") or {"w": 0, "l": 0, "d": 0}
    app.suspend_hud()
    try:
        enter_raw(app.fd)
        app.keys.pend = b""
        W, H = app.size()
        out = app.out
        out.write(ALT_ON + CUR_HIDE)
        out.flush()
        me, opp = "X", "O"
        CW, CH = 11, 8
        fw, fh = 3 * CW, 3 * CH
        side_w = 24 if W >= 108 else 0
        gx0 = max(3, (W - fw - 2 - side_w) // 2)
        gy0 = max(3, (H - fh - 8) // 2)
        bd = [" "] * 9
        over = False
        win_line = None
        res = None
        quitf = False
        msg = "❯ 1-9 = move • L = level • Q = quit"
        taunt = _TTT_TAUNTS[lvl][0]
        taunt_i = 0
        last_move = -1
        thinking = False
        cv = Canvas(W, H)

        def render(t2):
            cv.clear()
            bcol = C_TERM_BORDER
            cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", bcol)
            cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", bcol)
            for yy in range(1, H - 1):
                cv.put(0, yy, "│", bcol)
                cv.put(W - 1, yy, "│", bcol)
            for k in range(7):
                sx = (k * 67 + int(t2 * 1.6) + k * k * 17) % max(4, W - 6) + 3
                sy = (k * 41 + int(t2 * 0.9)) % max(1, H - 6) + 2
                cv.set(sx, sy, "✦", scale(C_VIOLET, 0.30 + 0.14 * math.sin(t2 * 1.8 + k)))
            head = "✦ TIC ✦ TAC ✦ TOE ✦"
            hx2 = max(2, (W - disp_width(head)) // 2)
            for i, c2 in enumerate(head):
                cv.put(hx2 + i, 1, c2, grad(i / max(1, len(head) - 1)))
            lv = "LVL %d • %s" % (lvl + 1, _TTT_L_NAMES[lvl])
            cv.put(max(2, (W - disp_width(lv)) // 2), 2, lv,
                   C_GOLD if lvl == 5 else C_LABEL)
            _ttt_paint(cv, gx0, gy0, bd, win_line, t2, last_move)
            side_x = gx0 + fw + 4
            if side_w:
                st2 = ("think" if thinking else
                       ("happy" if (res or "").startswith("✦") else
                        ("sad" if (res or "").startswith("MOMO") else "idle")))
                av = _ttt_face(st2, t2)
                for j, al in enumerate(av):
                    cv.put(side_x, gy0 + 2 + j, al, C_PINK)
                cv.put(side_x + 9, gy0 + 3, "Momo", C_FUCHSIA)
                cv.put(side_x, gy0 + 7, clip(taunt, side_w - 2), C_LABEL)
                cv.put(side_x, gy0 + 9, clip(taunt[len(taunt) // 2:] if len(taunt) > side_w - 2 else "", side_w - 2), C_LABEL)
                if over:
                    sp2 = "  "
                elif thinking:
                    sp2 = SPIN[int(t2 * 10) % len(SPIN)] + " MOMO soch rahi…"
                else:
                    sp2 = "❯ TUMHARI BAARI"
                cv.put(side_x, gy0 + 12, clip(sp2, side_w - 2),
                       C_CYAN if thinking else C_GOLD)
                put_segs(cv, side_x, gy0 + 15,
                         [("✗ ", C_GOLD), (str(stats.get("w", 0)), C_VALUE),
                          ("  ◉ ", C_SLATE), (str(stats.get("d", 0)), C_VALUE),
                          ("  ○ ", C_RED), (str(stats.get("l", 0)), C_VALUE)])
                for li in range(6):
                    cur = (li == lvl)
                    cv.put(side_x, gy0 + 18 + li,
                           ("● L%d " % (li + 1)) if cur else ("○ L%d " % (li + 1)),
                           C_GOLD if cur else scale(C_SLATE, 0.7))
                    if cur:
                        cv.put(side_x + 5, gy0 + 18 + li, _TTT_L_NAMES[li], C_VALUE)
            ry0 = gy0 + fh + 2
            if over and res:
                rw = max(30, min(W - 10, 46))
                rx0 = max(2, (W - rw) // 2)
                for i in range(rw):
                    col = grad((i / rw + 0.25 * math.sin(t2 * 2.0)) % 1.0)
                    cv.set(rx0 + i, ry0, "━", scale(col, 1.0))
                txt = res
                tx0 = rx0 + (rw - disp_width(txt)) // 2
                for i, c2 in enumerate(txt):
                    cv.put(tx0 + i, ry0, c2,
                           C_WHITE if i not in (0, len(txt) - 1) else C_GOLD)
            cv.put(max(2, (W - disp_width(msg)) // 2), ry0 + 2, msg, C_SLATE)
            try:
                out.write(HOME + cv.render())
                out.flush()
            except Exception:
                pass

        def finish(winner, line):
            nonlocal over, res, win_line, msg, taunt
            over = True
            win_line = line
            if winner == me:
                stats["w"] = stats.get("w", 0) + 1
                res = "✦ TUM JEET GAYI! ✦"
                msg = "ENTER = phir se • Q quit"
                app.add_xp(6)
                if stats["w"] >= 5:
                    app.award("ttt_win5")
                if lvl >= 2:
                    app.award("ttt_l3")
                if lvl == 5:
                    app.award("ttt_l6")
                app.confetti_until = time.monotonic() + 3.5
                cols = list(GRAD_STOPS) + [C_GOLD, C_WHITE]
                app.confetti = [{"x": random.uniform(0, W), "y": random.uniform(-24, 0),
                                 "vy": random.uniform(10, 26),
                                 "c": random.choice(cols),
                                 "ch": random.choice("✦*·+•")} for _ in range(70)]
                taunt = "nyaa?! kaise?! 😿"
            elif winner == opp:
                stats["l"] = stats.get("l", 0) + 1
                res = "MOMO JEET GAYI 😼"
                msg = "ENTER = revenge • Q quit"
                taunt = "hehehe 😼😌"
            else:
                stats["d"] = stats.get("d", 0) + 1
                res = "DRAW — dono solid!"
                msg = "ENTER = phir se • Q quit"
                taunt = "theek hai… barabari 🤝"
            save_profile_field("ttt_stats", stats)

        def momo_turn():
            nonlocal taunt_i, thinking, last_move
            thinking = True
            t0 = time.monotonic()
            while time.monotonic() - t0 < 0.45:
                render(time.monotonic())
                time.sleep(0.03)
            mv = _ttt_momo_pick(bd, lvl, opp, me)
            thinking = False
            if mv is not None:
                bd[mv] = opp
                last_move = mv
            taunt_i = (taunt_i + 1) % len(_TTT_TAUNTS[lvl])
            taunt = _TTT_TAUNTS[lvl][taunt_i]
            w, ln = _ttt_winner(bd)
            if w:
                finish(w, ln)

        render(time.monotonic())
        while not quitf:
            now = time.monotonic()
            for ev in app.keys.poll(0.03):
                kind, ch = ev[0], ev[1]
                if kind == "EOF":
                    quitf = True
                elif kind in ("CTRL_C", "ESC") or (kind == "CHAR" and ch in ("q", "Q")):
                    quitf = True
                elif over and kind == "ENTER":
                    bd = [" "] * 9
                    over = False
                    win_line = None
                    res = None
                    last_move = -1
                    taunt = "naya round! 😼"
                    msg = "❯ 1-9 = move • L = level • Q = quit"
                elif over or thinking:
                    continue
                elif kind == "CHAR" and ch and ch.isdigit() and ch != "0":
                    i = int(ch) - 1
                    if bd[i] != " ":
                        msg = "✗ wo cell bhara hai!"
                        continue
                    bd[i] = me
                    last_move = i
                    render(now)
                    w, ln = _ttt_winner(bd)
                    if w:
                        finish(w, ln)
                    elif not all(x != " " for x in bd):
                        momo_turn()
                        msg = "❯ 1-9 = move • L = level • Q = quit"
                elif kind == "CHAR" and ch in ("l", "L"):
                    lvl = (lvl + 1) % 6
                    taunt = _TTT_TAUNTS[lvl][0]
                    msg = "→ LVL %d: %s" % (lvl + 1, _TTT_L_NAMES[lvl])
            render(now)
            if app.confetti:
                app._confetti_tick(0.03)
            time.sleep(0.005)
    finally:
        app.resume_hud()
    T.push([("  ⭕ tic-tac-toe » ", C_DIM),
            ("✗ %d  ◉ %d  ○ %d" % (stats.get("w", 0), stats.get("d", 0),
                                   stats.get("l", 0)), C_VALUE),
            ("  •  LVL %d" % (lvl + 1), C_SLATE)])


''', "ttt glow rebuild")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v26")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v27 GLOW BOARD patched ✓  (backup: %s.bak-v26)" % P)
