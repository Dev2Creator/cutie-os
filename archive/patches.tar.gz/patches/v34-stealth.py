import re
import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "tool_buy" in s:
    print("already patched ✓")
    sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label)
        print("  ✗", label)
        return
    s = s.replace(old, new, 1)
    print("  ✓", label)

def rx(pat, repl, label):
    global s
    s2, n = re.subn(pat, repl, s, count=1)
    if n == 0:
        fails.append(label)
        print("  ✗", label)
        return
    s = s2
    print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label)
        print("  ✗", label)
        return
    s = s[:a] + new + s[a:]
    print("  ✓", label)

rx(r'VERSION\s*=\s*"[^"]*"', 'VERSION      = "v3.4.0"', "version")
rx(r'EDITION\s*=\s*"[^"]*"', 'EDITION      = "STEALTH SHOP"', "edition")

rep('''    ("future_me", "Time Traveler", "future self ko letter likha"),''',
    '''    ("future_me", "Time Traveler", "future self ko letter likha"),
    ("first_buy", "Code Queen", "pehla stealth order banaya 🛒"),''',
    "stealth achievements")

rep('''    Tool("pride", ["trans", "nb"], "🏳️‍⚧️ HRT tracker + affirm journal + pronouns", "life", tool_pride),''',
    '''    Tool("pride", ["trans", "nb"], "🏳️‍⚧️ HRT tracker + affirm journal + pronouns", "life", tool_pride),
    Tool("buy", ["shop"], "stealth shopping code — buy o(wish(nu(ul(nap(m)))))", "life", tool_buy),''',
    "stealth registry")

DATA = '''BUY_BRANDS = {"nu": "Whisper", "stay": "Stayfree", "fi": "Sofy",
              "ma": "Maxi", "fe": "Pee-Safe", "eve": "Everteen",
              "ine": "Nine", "plu": "Plush"}
BUY_SUBS = {"ul": "Ultra", "dr": "Dry-Max", "bo": "Bodyfit",
            "ch": "Choice", "co": "Cotton", "xl": "XL-type"}
BUY_SIZES = {"s": "Small", "m": "Medium", "l": "Large", "xl": "Extra Large"}
BUY_ITEMS = {"nap": "Pad", "pan": "Period Panty", "tie": "Panty"}
BUY_PRICE = {"low": "budget option", "high": "premium option"}
BUY_HELP = (
    "╭─ 🛒 CUTIE BUY — secret order language ─────────────╮",
    "│ o(...)            order shuru karta hai            │",
    "│ wish(<brand>)     brand: nu stay fi ma fe eve ine plu│",
    "│ <sub>(...)        type: ul dr bo ch co xl          │",
    "│ nap/pan/tie(<sz>) product: s m l xl                │",
    "│ br(<num>(<cup>))  bra: br(32(m)) — 28 se 42        │",
    "│ lin(...)          bra+panty ka dabba               │",
    "│ pri(low/high(...)) price filter                    │",
    "│ A + B             do orders jodo                   │",
    "│ r()               last order repeat                │",
    "│ buy copy          clipboard pe list                │",
    "│ buy list          purane orders                    │",
    "╰────────────────────────────────────────────────────╯",
)

_BUY_TOK = re.compile(r"\\s*([A-Za-z]+\\(|[+)]|\\d+)")


def _buy_parse(text, pos, depth=0):
    items = []
    meta = {}
    n = len(text)
    while pos < n:
        m = _BUY_TOK.match(text, pos)
        if not m:
            if text[pos:].strip() == "":
                break
            raise ValueError("galat cheez: " + text[pos:pos + 12])
        tok = m.group(1)
        pos = m.end()
        if tok == ")":
            if depth == 0:
                raise ValueError("extra ) mila")
            return items, meta, pos
        if tok == "+":
            more, meta2, pos = _buy_parse(text, pos, depth)
            items.extend(more)
            meta.update(meta2)
            continue
        if tok.isdigit():
            continue
        if not tok.endswith("("):
            raise ValueError("anjaan shabd: " + tok)
        fn = tok[:-1].lower()
        if fn == "o":
            inner, meta2, pos = _buy_parse(text, pos, depth + 1)
            items.extend(inner)
            meta.update(meta2)
            continue
        if fn == "wish":
            inner, meta2, pos = _buy_parse(text, pos, depth + 1)
            brand = BUY_BRANDS.get(inner[0] if inner else "")
            if not brand:
                raise ValueError("brand code? (nu/stay/fi/ma/fe/eve/ine/plu)")
            meta["brand"] = brand
            continue
        if fn == "pri":
            inner, meta2, pos = _buy_parse(text, pos, depth + 1)
            pf = inner[0] if inner else ""
            if pf in BUY_PRICE:
                meta["price"] = BUY_PRICE[pf]
            continue
        if fn == "lin":
            inner, meta2, pos = _buy_parse(text, pos, depth + 1)
            items.extend(inner)
            meta.update(meta2)
            continue
        if fn == "br":
            inner, meta2, pos = _buy_parse(text, pos, depth + 1)
            num = None
            cup = None
            for it in inner:
                if isinstance(it, int):
                    num = it
                elif isinstance(it, str):
                    cup = it
            if num is None or not (28 <= num <= 42):
                raise ValueError("bra size 28-42 me do: br(32(m))")
            cup = (cup or "m").lower()
            if cup not in BUY_SIZES:
                raise ValueError("cup: s/m/l/xl")
            items.append("Bra %d (%s)" % (num, BUY_SIZES[cup]))
            continue
        if fn in BUY_ITEMS:
            inner, meta2, pos = _buy_parse(text, pos, depth + 1)
            sz = (inner[0] if inner else "m")
            sz = sz.lower()
            if sz not in BUY_SIZES:
                raise ValueError("size: s/m/l/xl")
            prod = BUY_ITEMS[fn]
            if "brand" in meta and fn == "nap":
                sub = meta.get("sub", "")
                prod = ("%s %s %s" % (meta["brand"], sub, prod)).strip()
            items.append("%s — %s" % (prod, BUY_SIZES[sz]))
            continue
        if fn in BUY_SUBS:
            meta["sub"] = BUY_SUBS[fn]
            inner, meta2, pos = _buy_parse(text, pos, depth + 1)
            items.extend(inner)
            continue
        raise ValueError("anjaan code: " + fn)
    if depth > 0:
        raise ValueError(") missing hai")
    return items, meta, pos


def tool_buy(app, args):
    T = app.term
    if not args or args[0] == "help":
        for ln in BUY_HELP:
            T.push([(ln, C_SLATE if ln.startswith("╰") else
                     (C_FUCHSIA if ln.startswith("╭") else C_OUT))])
        return
    hist = _jload("buy.json", [])
    if args[0] == "copy":
        if not hist:
            T.dim("  abhi koi order nahi — pehle banao")
            return
        last = hist[-1]["items"]
        txt = "A Special Gift For You ✨\\n" + "\\n".join(
            "- " + it for it in last)
        if shutil.which("wl-copy"):
            subprocess.run(["wl-copy"], input=txt.encode(),
                           stdout=subprocess.DEVNULL, timeout=4)
            T.push([("  📋 copied! ", C_GOLD), ("WhatsApp pe paste karo", C_DIM)])
        else:
            T.push([("  copy is text ko:", C_DIM)])
            T.push([(txt, C_VALUE)])
        return
    if args[0] == "list":
        T.head("◆ ORDER HISTORY")
        if not hist:
            T.dim("  (khaali)")
            return
        for e2 in reversed(hist[-8:]):
            T.push([("  🛒 ", C_GOLD), (e2["d"], C_SLATE)])
            for it in e2["items"]:
                T.push([("      • ", C_DIM), (it, C_VALUE)])
        return
    if args[0] == "r":
        if not hist:
            T.dim("  repeat ke liye pehla order to banao")
            return
        items = hist[-1]["items"]
    else:
        code = " ".join(args)
        try:
            items, meta, _p = _buy_parse(code, 0)
        except ValueError as e2:
            T.push([("  ✗ ", C_RED), (str(e2), C_VALUE)])
            T.dim("  help ke liye: buy")
            return
        if not items:
            T.dim("  order khaali nikla — check karo")
            return
        hist.append({"d": time.strftime("%Y-%m-%d %H:%M"), "items": items,
                     "code": code})
        _jsave("buy.json", hist[-20:])
        app.award("first_buy")
        app.add_xp(4)
    momo_says = random.choice((
        "momo: list ready — maasi ko bhejo 😻",
        "momo: bahar se maths lag rahi na? 🤭",
        "momo: queen move thi ye 💜",
        "momo: ghar pe 'gift' likhwa dena ✨",
    ))
    T.push([("  ╭─", C_SLATE), (" 🛒 CUTIE BUY ", C_FUCHSIA),
            ("─" * 26, C_SLATE)])
    for i2, it in enumerate(items, 1):
        T.push([("  │  %d. " % i2, C_SLATE), (it, C_VALUE)])
    if len(items) == 1:
        T.push([("  │  1 item ", C_DIM), ("— ekdum focused order", C_SLATE)])
    else:
        T.push([("  │  ", C_DIM), ("%d items" % len(items), C_VALUE),
                (" — sab ek gift box me ✨", C_DIM)])
    T.push([("  ╰", C_SLATE), ("─" * 40, C_SLATE), ("╯", C_SLATE)])
    T.push([("  " + momo_says, C_PINK)])
    T.push([("  ", C_DIM), ("buy copy", C_GOLD), (" = clipboard • ", C_DIM),
            ("buy list", C_GOLD), (" = history", C_DIM)])


'''

block("def tool_music(app, args):", DATA, "stealth tools")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v335")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v3.4.0 STEALTH SHOP patched ✓  (backup: %s.bak-v335)" % P)
