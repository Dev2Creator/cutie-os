import re, shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()

# 0) pehle TRIPLE-divider saaf karo
s = s.replace("# ───────────────────────────── toolkit registry# ───────────────────────────── toolkit registry# ───────────────────────────── toolkit registry# ───────────────────────────── toolkit registry ────────────────────────────",
              "# ───────────────────────────── toolkit registry")
s = s.replace("# ───────────────────────────── toolkit registry# ───────────────────────────── toolkit registry",
              "# ───────────────────────────── toolkit registry")

if '"tool_lang2"' in s:
    print("already patched ✓"); sys.exit(0)
lines = s.split("\n")
done = []

def find_line(substr):
    for i, ln in enumerate(lines):
        if substr in ln:
            return i
    return -1

for i, ln in enumerate(lines):
    if ln.startswith("VERSION"):
        lines[i] = 'VERSION      = "v3.8.0"'; done.append("version"); break
for i, ln in enumerate(lines):
    if ln.startswith("EDITION"):
        lines[i] = 'EDITION      = "SANCTUARY+ SHOP"'; done.append("edition"); break

if '"first_buy"' not in s:
    i = find_line('"dysncare"')
    if i >= 0:
        lines.insert(i + 1, '    ("first_buy", "Code Queen", "pehla stealth order banaya 🛒"),')
        done.append("achievements")

FUNCS = open("/home/cutie/f-all.py").read()
di = find_line("# ───────────────────────────── toolkit registry")
if di < 0:
    print("✗ divider nahi mila"); sys.exit(1)
lines[di:di] = FUNCS.split("\n") + ["", ""]
done.append("FUNCS inserted (before registry)")

if '"tool_lang2"' not in s:
    i = find_line('Tool("pkginfo"')
    if i >= 0 and lines[i].strip().endswith("),"):
        for j, t2 in enumerate([
            '    Tool("buy", ["shop"], "stealth shopping - buy o(wish(nu(nap(m))))", "life", tool_buy),',
            '    Tool("lang2", ["sl"], "FULL stealth lang v2 - q3 now del gift bud no or #", "life", tool_lang2),',
            '    Tool("web", ["search"], "free web search - web <query>", "life", tool_web),',
            '    Tool("goodmorning", ["gm"], "Momo morning page", "life", tool_goodmorning),',
        ]):
            lines.insert(i + 1 + j, t2)
        done.append("registry x4")
    else:
        print("✗ pkginfo line"); sys.exit(1)

if "self.gmpage" not in s:
    i = find_line("self.pridepage = None")
    if i >= 0:
        lines.insert(i + 1, "        self.gmpage = None")
        done.append("gmpage init")

if "handle_gm_event" not in s:
    i = find_line("if self.pridepage:")
    if i >= 0:
        lines[i:i] = ["        if self.gmpage:",
                      "            self.handle_gm_event(ev)",
                      "            return"]
        done.append("gm routing")
if "build_gm_frame" not in s:
    i = find_line("if self.pridepage and not L.too_small:")
    if i < 0:
        i = find_line("if self.pridepage:")
    if i >= 0:
        lines[i:i] = ["        if self.gmpage and not L.too_small:",
                      "            cv.clear()",
                      "            return self.build_gm_frame(t)"]
        done.append("gm frame")

if "def build_gm_frame" not in s:
    GM = open("/home/cutie/f-gmmethods.py").read()
    di2 = find_line("# ───────────────────────────── self check / main")
    if di2 < 0:
        print("✗ self-check divider nahi mila"); sys.exit(1)
    lines[di2:di2] = GM.split("\n") + [""]
    done.append("gm methods")

s = "\n".join(lines)
try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax — NOT changed:", e)
    ls = s.split("\n")
    for i2 in range(max(0, (e.lineno or 0) - 4), min(len(ls), (e.lineno or 0) + 3)):
        print((">>" if i2 == (e.lineno or 0) - 1 else "  "), i2 + 1, "|", ls[i2])
    sys.exit(1)

shutil.copy(P, P + ".bak-v33")
open(P, "w", encoding="utf-8").write(s)
print()
for d2 in done:
    print("  ✓", d2)
print("\n★ v3.8.0 v40c patched ✓")
