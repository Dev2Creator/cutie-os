import re, shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "_ai_worker" in s:
    print("already patched ✓"); sys.exit(0)
for ln in s.splitlines():
    if ln.startswith("VERSION") or ln.startswith("EDITION"):
        print("  base file:", ln.strip())
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

def rx(pat, repl, label):
    global s
    s2, n = re.subn(pat, repl, s, count=1)
    if n == 0:
        fails.append(label); print("  ✗", label); return
    s = s2; print("  ✓", label)

def span(a_m, b_m, new, label):
    global s
    try:
        a = s.index(a_m); b = s.index(b_m, a)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[b:]; print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[a:]; print("  ✓", label)

rx(r'VERSION\s*=\s*"[^"]*"', 'VERSION      = "v25"', "version")
rx(r'EDITION\s*=\s*"[^"]*"', 'EDITION      = "OMEGA EDITION"', "edition")

rep('''        if c == 0x13:
            return ("CTRL_S", 1, None)''', '''        if c == 0x12:
            return ("CTRL_R", 1, None)
        if c == 0x13:
            return ("CTRL_S", 1, None)''', "ctrl-r key")

span("def _ep_check_source(path, lines):", "def tool_ed(app, args):", '''def _ep_outline(lines):
    out = []
    for i, ln in enumerate(lines):
        m = re.match(r"\\s*(def|class)\\s+([A-Za-z_]\\w*)", ln)
        if m:
            out.append((i, m.group(1), m.group(2)))
        if len(out) >= 20:
            break
    return out


def _ep_preview_info(path, lines):
    ext = os.path.splitext(path)[1].lower()
    txt = "\\n".join(lines)
    if ext == ".py":
        try:
            compile(txt, path, "exec")
            return ("✓ syntax OK", C_CYAN, _ep_outline(lines))
        except SyntaxError as e:
            return ("✗ line %d: %s" % (e.lineno or 0, e.msg or "error"), C_RED,
                    _ep_outline(lines))
        except Exception:
            return ("✗ compile error", C_RED, _ep_outline(lines))
    if ext in (".c", ".cpp"):
        incs = [l.strip() for l in lines if l.strip().startswith("#include")]
        bal = txt.count("{") - txt.count("}")
        ol = []
        for i, ln in enumerate(lines):
            m = re.match(r"^\\w[\\w\\s\\*]*?([A-Za-z_]\\w*)\\s*\\([^;{]*\\)\\s*\\{", ln)
            if m and len(ol) < 20:
                ol.append((i, "fn", m.group(1)))
        st = ("✓ braces balanced • %d includes" % len(incs)) if bal == 0 \\
            else ("✗ braces %s by %d" % ("zyada" if bal > 0 else "kam", abs(bal)))
        if any(o[2] == "main" for o in ol):
            st += " • main() ✓"
        return (st, C_CYAN if bal == 0 else C_RED, ol)
    if ext in (".html", ".htm"):
        void = {"img", "br", "hr", "input", "meta", "link", "source", "area", "col", "embed"}
        stack = []
        bad = None
        for m in re.finditer(r"<(/?)([a-zA-Z][\\w-]*)([^>]*?)(/?)>", txt):
            tag = m.group(2).lower()
            if tag in void or m.group(4) == "/":
                continue
            if m.group(1) == "/":
                if stack and stack[-1] == tag:
                    stack.pop()
                elif bad is None:
                    bad = tag
            else:
                stack.append(tag)
        cnt = {}
        for m in re.finditer(r"<([a-zA-Z][\\w-]*)", txt):
            t2 = m.group(1).lower()
            cnt[t2] = cnt.get(t2, 0) + 1
        top = sorted(cnt.items(), key=lambda x: -x[1])[:6]
        st = ("✗ unclosed <%s>" % bad) if bad else ("✓ tags balanced" if not stack else "✗ open: <%s>" % ", ".join(stack[-3:]))
        ol = []
        for i, ln in enumerate(lines):
            for t3 in re.findall(r"<(h[1-6]|div|p|img|a|ul|nav|section|button)\\b", ln):
                if len(ol) < 20:
                    ol.append((i, "tag", "<" + t3 + ">"))
        extra = " • " + ", ".join("%s×%d" % (k, v) for k, v in top)
        return (st + extra[:60], C_RED if (bad or stack) else C_CYAN, ol)
    if ext == ".json":
        try:
            j = json.loads(txt)
            keys = list(j.keys())[:10] if isinstance(j, dict) else ["[%d items]" % len(j)]
            return ("✓ valid JSON", C_CYAN, [(i, "key", str(k)) for i, k in enumerate(keys)])
        except Exception as e:
            return ("✗ invalid JSON: %s" % str(e)[:40], C_RED, [])
    if ext == ".md":
        ol = [(i, "#" * len(m.group(1)), m.group(2)) for i, ln in enumerate(lines)
              for m in [re.match(r"^(#{1,4})\\s+(.*)", ln)] if m][:20]
        return ("✓ %d headings" % len(ol), C_CYAN, ol)
    if ext == ".css":
        sels = re.findall(r"^([^{}@/]+)\\{", txt, re.M)
        return ("✓ %d rules" % len(sels), C_CYAN,
                [(i, "sel", sl.strip()[:24]) for i, sl in list(enumerate(sels))[:20]])
    if ext in (".sh", ".bash"):
        ol = [(i, "fn", m.group(1)) for i, ln in enumerate(lines)
              for m in [re.match(r"^\\s*(?:function\\s+)?([A-Za-z_]\\w*)\\s*\\(\\)\\s*\\{", ln)] if m]
        she = "shebang ✓" if txt.startswith("#!") else "✗ shebang nahi"
        return (she + " • %d fns" % len(ol), C_CYAN if txt.startswith("#!") else C_GOLD, ol)
    return ("%d lines • plain text" % len(lines), C_SLATE, [])


def _paint_lang_banner(cv, x0, y0, word, t):
    word = (word or "CODE").upper()[:9]
    if len(word.strip()) < 2:
        word = word + " LANG"
    word = "".join(ch if ch in _GLYPHS else " " for ch in word)
    rows = ["".join(r) for r in zip(*(_GLYPHS[c] for c in word))]
    n = max(1, disp_width(rows[0]))
    sweep = (t * 16.0) % (n + 24.0) - 12.0
    for ry, line in enumerate(rows):
        for i, ch in enumerate(line):
            if ch == " ":
                continue
            base = grad(i / max(1, n - 1))
            d = abs(i - sweep)
            c = mix(base, C_WHITE, 0.85 - d / 5.0) if d < 4.0 else scale(base, 0.92)
            cv.set(x0 + i, y0 + ry, ch, c)
    return len(rows)


''', "preview engine v2")

rep('''        ep["check"] = _ep_check_source(ep["path"], ep["lines"])
        ep["outline"] = _ep_outline(ep["lines"])''',
    '''        ep["check"], _, ep["outline"] = _ep_preview_info(ep["path"], ep["lines"])''',
    "refresh preview")

rep('''                if ep["path"].endswith(".py"):
                    ck = ep.get("check")
                    if ck is not None:
                        if ck[0] == "ok":
                            cv.put(px, yy, "✓ syntax OK", C_CYAN)
                        else:
                            cv.put(px, yy, clip("✗ line %d: %s" % (ck[1][0], ck[1][1]), pw), C_RED)
                else:
                    cv.put(px, yy, clip("· " + lname + " — run se check hota", pw), C_SLATE)''',
    '''                ck = ep.get("check")
                if ck:
                    cv.put(px, yy, clip(ck[0], pw), ck[1])''', "preview display")

block("def tool_music(app, args):", '''def _jload(name, default):
    try:
        with open(os.path.join(CONFIG_DIR, name)) as f:
            return json.load(f)
    except Exception:
        return default


def _jsave(name, data):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(os.path.join(CONFIG_DIR, name), "w") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
    except Exception:
        pass


def tool_todo(app, args):
    T = app.term
    td = _jload("todo.json", [])
    if args and args[0].lower() == "add" and len(args) >= 2:
        td.append({"t": " ".join(args[1:]), "d": False})
        _jsave("todo.json", td)
        T.push([("  ☑ add » ", C_DIM), (" ".join(args[1:]), C_VALUE)])
        return
    if args and args[0].lower() in ("done", "did") and args[1:]:
        i = int(args[1]) - 1 if args[1].isdigit() else -1
        if 0 <= i < len(td):
            td[i]["d"] = True
            _jsave("todo.json", td)
            app.add_xp(2)
            T.push([("  ✔ done » ", C_GOLD), (td[i]["t"], C_VALUE)])
        return
    if args and args[0].lower() in ("del", "rm") and args[1:]:
        i = int(args[1]) - 1 if args[1].isdigit() else -1
        if 0 <= i < len(td):
            T.push([("  ✗ del » ", C_DIM), (td.pop(i)["t"], C_DIM)])
            _jsave("todo.json", td)
        return
    if args and args[0].lower() == "clear":
        _jsave("todo.json", [])
        T.dim("  todo khaali ✓")
        return
    pend = [x for x in td if not x["d"]]
    T.head("◆ TODO — %d pending / %d total" % (len(pend), len(td)))
    for i, it in enumerate(td, 1):
        if it["d"]:
            T.push([("  %2d " % i, C_SLATE), ("✔ ", C_CYAN), (it["t"], C_DIM)])
        else:
            T.push([("  %2d " % i, C_GOLD), ("○ ", C_PINK), (it["t"], C_VALUE)])
    if not td:
        T.dim("  (khaali) — todo add kal ka kaam")
    T.dim("  add • done N • del N • clear")


def tool_snip(app, args):
    T = app.term
    sp = _jload("snips.json", {})
    if args and args[0] == "add" and len(args) >= 3:
        sp[args[1]] = " ".join(args[2:]).replace("\\\\n", "\\n")
        _jsave("snips.json", sp)
        T.push([("  ✿ snippet » ", C_DIM), (args[1], C_CYAN), (" saved", C_SLATE)])
        return
    if args and args[0] == "del" and args[1:]:
        sp.pop(args[1], None)
        _jsave("snips.json", sp)
        T.dim("  deleted")
        return
    if args and args[0] in sp:
        T.push([("  ╭─", C_SLATE), (" SNIP ", C_FUCHSIA), ("─" * 28, C_SLATE)])
        for ln in sp[args[0]].split("\\n"):
            T.push([("  │ ", C_SLATE), (ln, C_VALUE)])
        T.push([("  ╰", C_SLATE), ("─" * 34, C_SLATE), ("╯", C_SLATE)])
        return
    T.head("◆ SNIPPETS — %d" % len(sp))
    for k in sorted(sp):
        T.push([("  " + k.ljust(16), C_CYAN), ("» ", C_SLATE),
                (sp[k].split("\\n")[0][:50], C_DIM)])
    T.dim("  snip add <naam> <code> • snip <naam> • snip del <naam>")


def tool_book(app, args):
    T = app.term
    bk = _jload("books.json", {})
    if args and args[0] == "add" and len(args) >= 3:
        bk[args[1]] = os.path.expanduser(args[2])
        _jsave("books.json", bk)
        T.push([("  🔖 book » ", C_DIM), (args[1], C_CYAN), (" → " + bk[args[1]], C_DIM)])
        return
    if args and args[0] == "del" and args[1:]:
        bk.pop(args[1], None)
        _jsave("books.json", bk)
        return
    if args and args[0] in bk:
        app.do_cd([bk[args[0]]])
        return
    T.head("◆ BOOKMARKS")
    for k in sorted(bk):
        T.push([("  " + k.ljust(14), C_CYAN), ("» ", C_SLATE), (bk[k], C_VALUE)])
    T.dim("  book add <naam> <path> • book <naam> = jump")


def tool_proj(app, args):
    T = app.term
    pj = _jload("proj.json", {})
    if args and args[0] == "add" and len(args) >= 3:
        pj[args[1]] = os.path.expanduser(args[2])
        _jsave("proj.json", pj)
        T.push([("  📦 proj » ", C_DIM), (args[1], C_CYAN)])
        return
    if args and args[0] in pj:
        app.do_cd([pj[args[0]]])
        if shutil.which("git"):
            app.start_capture("git -C " + shlex.quote(pj[args[0]]) + " status -sb")
        return
    T.head("◆ PROJECTS")
    for k in sorted(pj):
        T.push([("  " + k.ljust(14), C_CYAN), ("» ", C_SLATE), (pj[k], C_VALUE)])
    T.dim("  proj add <naam> <path> • proj <naam> = cd + git status")


def tool_wp(app, args):
    T = app.term
    if not args:
        T.dim("  usage: wp ~/Pictures/wall.jpg  — wallpaper colors se theme banegi!")
        return
    path = os.path.expanduser(" ".join(args))
    if not os.path.isfile(path):
        T.push([("  ✗ file nahi: ", C_RED), (path, C_VALUE)])
        return
    exe = shutil.which("magick") or shutil.which("convert")
    if exe is None:
        T.dim("  imagemagick chahiye — !sudo pacman -S imagemagick")
        return
    T.push([("  🎨 wallpaper se colors nikaal rahi hoon…", C_DIM)])
    app.flush_frame()
    out = run_cmd([exe, path, "-resize", "300%", "-colors", "6",
                   "-unique-colors", "txt:"], 10)
    cols = re.findall(r"#([0-9A-Fa-f]{6})", out)
    if len(cols) < 3:
        T.dim("  colors nahi mile — dusri image try karo")
        return

    def hx(h):
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    c0, c1, c2 = hx(cols[0]), hx(cols[1]), hx(cols[2])
    THEMES["wallpaper"] = dict(
        border=c0, tborder=scale(c0, 0.7), title=c1,
        label=mix(c1, C_WHITE, 0.35), arrow=c2,
        stops=(scale(c0, 0.55), c0, mix(c0, c1, 0.5), c1, c2, mix(c2, C_WHITE, 0.4)))
    apply_theme("wallpaper")
    save_profile_field("theme", "wallpaper")
    app.info.rebuild_ui(app.layout)
    if shutil.which("swww"):
        _cap("swww img " + shlex.quote(path), 8)
        T.push([("  🖼 wallpaper set (swww) » ", C_DIM), (os.path.basename(path), C_VALUE)])
    T.push([("  ✦ WALLPAPER THEME ban gayi!", C_FUCHSIA),
            ("  — pura cutie ab is image ke colors me 💜", C_DIM)])
    app.award("themed")


def tool_clip(app, args):
    T = app.term
    if shutil.which("wl-copy") is None:
        T.dim("  wl-clipboard chahiye — !sudo pacman -S wl-clipboard")
        return
    if args:
        txt = " ".join(args)
        subprocess.run(["wl-copy"], input=txt.encode(),
                       stdout=subprocess.DEVNULL, timeout=4)
        T.push([("  📋 copied » ", C_DIM), (txt[:60], C_VALUE)])
        return
    out = run_cmd(["wl-paste", "--no-newline"], 3)
    T.push([("  📋 clipboard » ", C_DIM), ((out or "(khaali)")[:70], C_VALUE)])


def tool_share(app, args):
    T = app.term
    if not args:
        T.dim("  usage: share <file>  — 0x0.st pe upload, link milega")
        return
    path = os.path.expanduser(" ".join(args))
    if not os.path.isfile(path):
        T.push([("  ✗ nahi mila: ", C_RED), (path, C_VALUE)])
        return
    T.push([("  ☁ uploading (panel me)…", C_DIM)])
    app.start_capture("curl -sF 'file=@" + shlex.quote(path) + "' https://0x0.st")
    app.cap_t0 = time.monotonic()


def tool_sync(app, args):
    T = app.term
    if args and args[0].lower() == "import":
        src = os.path.expanduser(args[1] if len(args) > 1 else "~/cutie-omega-backup.json")
        try:
            with open(src) as f:
                j = json.load(f)
        except Exception as e:
            T.push([("  ✗ import fail: ", C_RED), (str(e)[:50], C_DIM)])
            return
        for k in ("profile.json", "macros.txt", "todo.json", "snips.json",
                  "books.json", "proj.json"):
            if k in j:
                _jsave(k, j[k])
        pf = j.get("profile.json") or {}
        if pf.get("theme") in THEMES:
            apply_theme(pf["theme"])
            save_profile_field("theme", pf["theme"])
        app.term.macros = load_macros()
        app.term.nick = load_nick()
        app.info.nick = load_nick()
        app.info.rebuild_ui(app.layout)
        T.push([("  ♻ import done ✓ ", C_CYAN), ("(backup se sab wapas)", C_DIM)])
        return
    dump = {"profile.json": load_profile(), "macros.txt": load_macros(),
            "todo.json": _jload("todo.json", []), "snips.json": _jload("snips.json", {}),
            "books.json": _jload("books.json", {}), "proj.json": _jload("proj.json", {}),
            "exported": time.strftime("%Y-%m-%d %H:%M")}
    dst = os.path.expanduser("~/cutie-omega-backup.json")
    with open(dst, "w") as f:
        json.dump(dump, f, ensure_ascii=False, indent=1)
    T.push([("  ♻ sync export ✓ » ", C_CYAN), (dst, C_GOLD)])
    T.dim("  naye machine pe: sync import <file>")


def tool_pv(app, args):
    T = app.term
    if not args:
        T.dim("  usage: pv file.html  — browser me khol dega")
        return
    path = os.path.expanduser(args[0])
    if not os.path.isabs(path):
        path = os.path.join(T.cwd, path)
    if not os.path.isfile(path):
        T.push([("  ✗ nahi mila: ", C_RED), (args[0], C_VALUE)])
        return
    if shutil.which("xdg-open") is None:
        T.dim("  xdg-open nahi mila")
        return
    try:
        subprocess.Popen(["xdg-open", path], stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
        T.push([("  🌐 browser me khul gaya » ", C_DIM), (os.path.basename(path), C_VALUE)])
    except Exception as e:
        T.push([("  ✗ ", C_RED), (str(e)[:50], C_DIM)])


def tool_ask(app, args):
    T = app.term
    if run_cmd(["curl", "-s", "--max-time", "3",
                "http://localhost:11434/api/tags"], 4).strip() == "":
        T.dim("  Ollama nahi/band hai — !sudo pacman -S ollama && systemctl start ollama")
        T.dim("  model: ollama pull llama3.2")
        return
    app.open_chatpage()
    if args:
        app._chat_send(" ".join(args))


def tool_chat(app, args):
    return tool_ask(app, args)


def tool_aimodel(app, args):
    T = app.term
    out = run_cmd(["curl", "-s", "--max-time", "4",
                   "http://localhost:11434/api/tags"], 6)
    names = []
    try:
        j = json.loads(out)
        names = [m.get("name") for m in j.get("models", []) if m.get("name")]
    except Exception:
        pass
    if args:
        save_profile_field("ai_model", args[0])
        app.ai_model = args[0]
        T.push([("  🧠 model set » ", C_DIM), (args[0], C_GOLD)])
        return
    T.head("◆ OLLAMA MODELS")
    for n in names:
        cur = (n == app.ai_model)
        T.push([("  %s " % ("●" if cur else "○"), C_CYAN if cur else C_SLATE),
                (n, C_VALUE if cur else C_OUT)])
    if not names:
        T.dim("  koi model nahi — ollama pull llama3.2")
    T.dim("  aimodel <name> = set • abhi: " + (app.ai_model or "auto"))


def tool_dash(app, args):
    app.open_dash()


''', "omega tools")

rep('''        self.epage = None''', '''        self.epage = None
        self.chat = None
        self.ai_q = None
        self.ai_model = load_profile().get("ai_model")
        self.dash = False
        self.fz = None
        self.wx = ""
        threading.Thread(target=self._wx_loop, daemon=True).start()''', "omega init")

rep('''        if saved.get("theme") in THEMES:
            apply_theme(saved["theme"])''', '''        if saved.get("theme") in THEMES:
            apply_theme(saved["theme"])
        elif saved.get("seasonal", "on") == "on":
            _sm = {12: "ice", 1: "ice", 2: "ice", 3: "sakura", 4: "sakura",
                   10: "sunset"}.get(time.localtime().tm_mon)
            if _sm:
                apply_theme(_sm)''', "seasonal")

rep('''        if self.epage:
            self.handle_epage_event(ev)
            return''', '''        if self.dash:
            self.dash = False
            if kind == "EOF":
                self.running = False
            return
        if self.fz is not None:
            self.handle_fz_event(ev)
            return
        if self.chat is not None:
            self.handle_chat_event(ev)
            return
        if self.epage:
            self.handle_epage_event(ev)
            return''', "omega routing")

rep('''        if self.epage and not L.too_small:
            cv.clear()
            return self.build_epage_frame(t)''', '''        if self.dash and not L.too_small:
            cv.clear()
            return self.build_dash_frame(t)
        if self.chat is not None and not L.too_small:
            cv.clear()
            return self.build_chat_frame(t)
        if self.epage and not L.too_small:
            cv.clear()
            return self.build_epage_frame(t)''', "omega frames")

rep('''        elif kind == "CTRL_L":
            T.clear()
            self.seed_lines()''', '''        elif kind == "CTRL_L":
            T.clear()
            self.seed_lines()
        elif kind == "CTRL_R":
            self.fz = {"q": "", "sel": 0}''', "ctrl-r open")

rep('''            if self.running and not self.no_intro:
                self._intro()''', '''            if self.running and not self.no_intro:
                self._boot_seq()
                self._intro()''', "boot call")

rep('''        if kind == "CTRL_Q":
            if ep["dirty"] and not ep.get("confirm"):''', '''        if kind in ("CHAR", "ENTER", "BACKSPACE", "DEL", "TAB",
                    "CTRL_D", "CTRL_K", "CTRL_T"):
            ep.setdefault("undo", []).append((list(lines), ep["cy"], ep["cx"]))
            if len(ep["undo"]) > 150:
                del ep["undo"][:50]
            ep.setdefault("redo", [])
        if kind == "CTRL_Q":
            if ep["dirty"] and not ep.get("confirm"):''', "undo snapshot")

rep('''        if kind == "CTRL_D":
            ln = lines[ep["cy"]]''', '''        if kind == "CTRL_Z":
            u = ep.get("undo") or []
            if not u:
                ep["msg"] = "✧ kuch undo nahi bacha"
                ep["msg_t"] = time.monotonic()
                return
            st = u.pop()
            ep.setdefault("redo", []).append((list(lines), ep["cy"], ep["cx"]))
            lines[:] = st[0]
            ep["cy"], ep["cx"] = st[1], st[2]
            ep["dirty"] = True
            ep["msg"] = "↶ undo — CTRL+Y redo"
            ep["msg_t"] = time.monotonic()
            self._epage_ensure_visible()
            return
        if kind == "CTRL_Y":
            r = ep.get("redo") or []
            if not r:
                ep["msg"] = "✧ redo khaali"
                ep["msg_t"] = time.monotonic()
                return
            st = r.pop()
            ep.setdefault("undo", []).append((list(lines), ep["cy"], ep["cx"]))
            lines[:] = st[0]
            ep["cy"], ep["cx"] = st[1], st[2]
            ep["dirty"] = True
            ep["msg"] = "↷ redo"
            ep["msg_t"] = time.monotonic()
            self._epage_ensure_visible()
            return
        if kind == "CTRL_D":
            ln = lines[ep["cy"]]''', "undo/redo keys")

rep('''    else:
        mood, mcol = "so raha hai… zzz", C_SLATE''', '''    else:
        mood, mcol = "so raha hai… zzz", C_SLATE
    if app.info.bat and isinstance(app.info.bat[0], int):
        _bc, _bs = app.info.bat
        if _bc <= 15 and "charg" not in str(_bs).lower():
            mood, mcol = "battery khatam 🙀 charge karo!", C_RED
        elif "charg" in str(_bs).lower() and _bc >= 95:
            mood, mcol = "full charge — party! 😻⚡", C_GOLD''', "pet battery mood")

rep('''    Tool("ed", ["write"], "CUTIE EDITOR — ed file.py • multi-line • F1 run", "dev", tool_ed),''',
    '''    Tool("ed", ["write"], "CUTIE EDITOR — ed file.py ya bas: python c html sh js", "dev", tool_ed),
    Tool("ask", [], "AI se poochho — ask why linux (offline Ollama)", "ai", tool_ask),
    Tool("chat", ["ai"], "FULL-SCREEN AI CHAT — offline, streaming", "ai", tool_chat),
    Tool("aimodel", ["model"], "ollama models — aimodel <name> set", "ai", tool_aimodel),
    Tool("dash", ["cockpit"], "cockpit dashboard — bada clock + sab kuch", "core", tool_dash),
    Tool("todo", ["task"], "todo add/done/list — saved rehta hai", "life", tool_todo),
    Tool("snip", ["snippet"], "code snippets — snip add py-main 'def main()…'", "life", tool_snip),
    Tool("book", ["bm"], "bookmarks — book add naam path", "life", tool_book),
    Tool("proj", ["project"], "projects — proj add naam path • proj naam", "life", tool_proj),
    Tool("wp", ["wall"], "wallpaper → CUTIE theme magic 🎨", "style", tool_wp),
    Tool("clip", ["copy"], "clipboard — clip text | clip (dekh)", "life", tool_clip),
    Tool("share", ["up"], "file share — link milega (0x0.st)", "net", tool_share),
    Tool("pv", ["preview"], "pv file.html — browser preview", "dev", tool_pv),
    Tool("sync", ["backup"], "cutie setup export/import — naya PC same cutie", "core", tool_sync),''',
    "registry")

rep('"hint": "↑↓ history   TAB complete   PGUP/PGDN scroll   CTRL+C kill job   !cmd → real tty (sudo!)   tools → {n} tools   help",',
    '"hint": "↑↓ history • CTRL+R fuzzy • TAB • CTRL+C kill • !cmd sudo • dash • ask (AI) • tools → {n}",',
    "hint en")

rep('''                 ("text", "games/fun: snake • hack • icat  (kitty preview)", "", "", None)]''',
    '''                 ("text", "games/fun: snake • hack • icat  (kitty preview)", "", "", None),
                 ("text", "ai: ask <sawal> • chat (offline ollama) • aimodel", "", "", None),
                 ("text", "life: dash • todo • snip • book • proj • wp • clip • share • sync • pv", "", "", None),
                 ("text", "editor: python/c/html likho → khud khulega • CTRL+Z undo • CTRL+R fuzzy", "", "", None)]''',
    "help rows")

DIV2 = "# ───────────────────────────── self check / main"
block(DIV2, '''    # ── v25 OMEGA: ai / chat / dash / fuzzy / boot / weather ──

    def _wx_loop(self):
        while True:
            out = run_cmd(["curl", "-s", "--max-time", "8",
                           "https://wttr.in/?format=%c+%t"], 10)
            if out.strip():
                self.wx = out.strip()[:18]
            time.sleep(600)

    def _boot_seq(self):
        if load_profile().get("boot") == "off" or os.environ.get("CUTIE_NO_BOOT") == "1":
            return
        out = self.out
        try:
            out.write(CLEAR_SCR + CUR_HIDE)
            out.flush()
        except Exception:
            return
        user = getattr(self.info, "user", "cutie")
        host = getattr(self.info, "hostname", "pc")
        lines = [
            ("CUTIE BIOS v25 — memory check ✓ 16384MB ok", C_SLATE),
            ("[ OK ] mounted /home/%s ❤" % user, C_DIM),
            ("[ OK ] loaded %d tools • %d themes" % (len(TOOLS), len(THEMES)), C_DIM),
            ("[ OK ] pet daemon: %s online =^..^=" % getattr(self, "_pet_name", "momo"), C_DIM),
            ("[ OK ] sudo bridge armed", C_DIM),
            ("[ OK ] vibes calibrated ✦", C_GOLD),
            ("Starting CUTIE OS %s on %s…" % (VERSION, host), C_LABEL),
        ]
        try:
            for i, (ln, col) in enumerate(lines):
                out.write(ESC + "[%d;1H" % (min(20, 4 + i)) + fg(col) + ln + RESET)
                out.flush()
                time.sleep(0.14)
            time.sleep(0.25)
            out.write(CLEAR_SCR)
            out.flush()
        except Exception:
            pass

    def open_dash(self):
        self.dash = True

    _DIGL = {
        "0": (" ███ ", "█   █", "█   █", "█   █", "█   █", " ███ "),
        "1": ("  █  ", " ██  ", "  █  ", "  █  ", "  █  ", " ███ "),
        "2": (" ███ ", "█   █", "   ██", "  █  ", " █   ", "█████"),
        "3": (" ███ ", "█   █", "  ██ ", "   █ ", "█   █", " ███ "),
        "4": ("   ██", "  █ █", " █  █", "█████", "    █", "    █"),
        "5": ("█████", "█    ", "████ ", "    █", "█   █", " ███ "),
        "6": (" ███ ", "█    ", "████ ", "█   █", "█   █", " ███ "),
        "7": ("█████", "    █", "   █ ", "  █  ", " █   ", " █   "),
        "8": (" ███ ", "█   █", " ███ ", "█   █", "█   █", " ███ "),
        "9": (" ███ ", "█   █", " ████", "    █", "    █", " ███ "),
        ":": ("     ", "  ██ ", "  ██ ", "  ██ ", "  ██ ", "     "),
    }

    def _block_text(self, text, glyphs):
        text = "".join(ch if ch in glyphs else " " for ch in text)
        try:
            return ["".join(r) for r in zip(*(glyphs[c] for c in text))]
        except Exception:
            return []

    def build_dash_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        b = C_TERM_BORDER
        cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", b)
        cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", b)
        for yy in range(1, H - 1):
            cv.put(0, yy, "│", b)
            cv.put(W - 1, yy, "│", b)
        cv.put(2, 1, "◆ CUTIE DASH", C_TITLE)
        cv.put(W - 2 - 10, 1, "cockpit ✦", C_SLATE)
        clk = time.strftime("%H:%M")
        rows = self._block_text(clk, self._DIGL)
        n = max(1, disp_width(rows[0]) if rows else 1)
        x0 = max(2, (W - n) // 2)
        for ry, line in enumerate(rows[:6]):
            for i, ch in enumerate(line):
                if ch != " ":
                    cv.set(x0 + i, 3 + ry, ch, grad((i + ry * 3) / float(n + 12)))
        if self.wx:
            cv.put(max(2, (W - disp_width(self.wx)) // 2), 10, self.wx, C_CYAN)
        y = 12
        half = max(18, (W - 8) // 2)
        self._dash_row(cv, 2, y, half, "CPU", getattr(self.info, "cpu_pct", 0.0))
        if self.info.mem:
            self._dash_row(cv, 2 + half + 2, y, half, "MEM", self.info.mem[2])
        if self.info.disk:
            self._dash_row(cv, 2, y + 2, half, "DSK", self.info.disk[2])
        if getattr(self.info, "net_rx", 0.0) > 1.0:
            nsegs = [("↓ ", C_CYAN), (fmt_speed(self.info.net_rx), C_VALUE),
                     (" ↑ ", C_FUCHSIA), (fmt_speed(self.info.net_tx), C_VALUE)]
        else:
            nsegs = [("net idle", C_SLATE)]
        put_segs(cv, 2 + half + 2, y + 2, [("NET ", C_LABEL)] + nsegs)
        y += 5
        mi = getattr(self, "music_info", None)
        if mi and mi.get("title"):
            sym = "▶" if mi.get("status") == "Playing" else "❚❚"
            put_segs(cv, 2, y, [(sym + " ♪ ", C_FUCHSIA),
                                (clip("%s — %s" % (mi.get("title", ""), mi.get("artist") or ""), W - 12), C_LABEL)])
            y += 1
        td = _jload("todo.json", [])
        pend = sum(1 for x in td if not x["d"])
        la = os.getloadavg()
        segs = [("UPTIME ", C_LABEL), (self.info.f_uptime, C_VALUE), ("   ", C_DIM),
                ("LOAD ", C_LABEL), ("%.2f" % la[0], C_VALUE)]
        if pend:
            segs += [("   TODO ", C_LABEL), ("%d ☐" % pend, C_GOLD)]
        if self.info.bat:
            segs += [("   BAT ", C_LABEL), (str(self.info.bat[0]) + "%", C_VALUE)]
        put_segs(cv, max(2, (W - disp_width("".join(x for x, _ in segs))) // 2), y, segs)
        y += 2
        momo = getattr(self, "_pet_name", "momo")
        cv.put(max(2, (W - 16) // 2), y, "=^..^=  " + momo, scale(C_PINK, 0.85))
        foot = "koi bhi key — wapas console"
        cv.put(max(2, (W - disp_width(foot)) // 2), H - 2, foot, C_SLATE)
        return cv.render()

    def _dash_row(self, cv, x, y, w, label, pct):
        put_segs(cv, x, y, [(label.ljust(4), C_LABEL)] + micro_bar(pct, max(6, w - 14)) +
                 [(" %3.0f%%" % pct, pct_color(pct))])

    def open_chatpage(self):
        self.chat = {"msgs": [], "hist": [], "mode": "idle", "input": ""}

    def _chat_send(self, text):
        ch = self.chat
        ch["msgs"].append(("me", text))
        ch["msgs"].append(("ai", ""))
        ch["hist"].append({"role": "user", "content": text})
        ch["mode"] = "stream"
        ch["input"] = ""
        self.ai_q = queue.Queue()
        threading.Thread(target=self._ai_worker, args=(text,), daemon=True).start()

    def _ai_worker(self, prompt):
        import urllib.request
        try:
            if not self.ai_model:
                with urllib.request.urlopen("http://localhost:11434/api/tags", timeout=6) as r:
                    j = json.loads(r.read().decode("utf-8", "replace"))
                names = [m.get("name") for m in j.get("models", []) if m.get("name")]
                if not names:
                    self.ai_q.put("✗ koi model nahi — ollama pull llama3.2")
                    self.ai_q.put(None)
                    return
                self.ai_model = names[0]
                save_profile_field("ai_model", self.ai_model)
            body = json.dumps({"model": self.ai_model,
                               "messages": self.chat["hist"][-9:],
                               "stream": True}).encode("utf-8")
            req = urllib.request.Request("http://localhost:11434/api/chat", data=body,
                                         headers={"Content-Type": "application/json"})
            acc = ""
            with urllib.request.urlopen(req, timeout=300) as r:
                for raw in r:
                    try:
                        d = json.loads(raw.decode("utf-8", "replace"))
                    except Exception:
                        continue
                    tok = (d.get("message") or {}).get("content", "")
                    if tok:
                        acc += tok
                        self.ai_q.put(tok)
                    if d.get("done"):
                        break
            self.chat["hist"].append({"role": "assistant", "content": acc})
            self.ai_q.put(None)
        except Exception as e:
            self.ai_q.put("✗ AI: %s" % str(e)[:60])
            self.ai_q.put(None)

    def _ai_pump(self):
        if self.ai_q is None or self.chat is None:
            if self.chat is None:
                self.ai_q = None
            return
        n = 0
        while n < 300:
            try:
                it = self.ai_q.get_nowait()
            except queue.Empty:
                return
            if it is None:
                self.chat["mode"] = "idle"
                self.ai_q = None
                return
            if self.chat["msgs"] and self.chat["msgs"][-1][0] == "ai":
                r_, t_ = self.chat["msgs"][-1]
                self.chat["msgs"][-1] = ("ai", t_ + it)
            n += 1

    def handle_chat_event(self, ev):
        kind, ch = ev[0], ev[1]
        if kind == "EOF":
            self.running = False
            return
        if kind in ("ESC", "CTRL_C", "CTRL_Q") or (kind == "CHAR" and ch in ("q", "Q") and self.chat["mode"] == "idle" and not self.chat["input"]):
            self.chat = None
            self.ai_q = None
            return
        if self.chat["mode"] == "stream":
            return
        if kind == "CHAR" and ch and ch not in ("\\n", "\\r"):
            self.chat["input"] = (self.chat["input"] + ch)[:400]
        elif kind == "BACKSPACE":
            self.chat["input"] = self.chat["input"][:-1]
        elif kind == "ENTER":
            q = self.chat["input"].strip()
            if q:
                self._chat_send(q)

    def build_chat_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        ch = self.chat
        for i in range(W):
            c = scale(grad(i / max(1, W - 1)), 0.8)
            cv.set(i, 0, "─", c)
            cv.set(i, H - 1, "─", c)
        for yy in range(1, H - 1):
            cv.set(0, yy, "│", scale(grad(yy / max(1, H - 1)), 0.8))
            cv.set(W - 1, yy, "│", scale(grad(yy / max(1, H - 1)), 0.8))
        cv.put(2, 0, "✦ CUTIE AI", C_TITLE)
        cv.put(13, 0, clip("— " + (self.ai_model or "auto") + " • offline • Q exit", W - 34), C_SLATE)
        wrapped = []
        for role, txt in ch["msgs"]:
            pre = "❯ " if role == "me" else "✦ "
            col = C_VALUE if role == "me" else C_CYAN
            for i2 in range(0, max(1, len(txt)), max(8, W - 8)):
                chunk = txt[i2:i2 + W - 8]
                if chunk or i2 == 0:
                    wrapped.append((pre if i2 == 0 else "  ", chunk, col, role))
        body = H - 5
        show = wrapped[-body:] if len(wrapped) > body else wrapped
        for r2, (pre, chunk, col, role) in enumerate(show):
            yy = 2 + r2
            cv.put(2, yy, pre, C_GOLD if role == "me" else C_FUCHSIA)
            cv.put(4, yy, chunk, col)
        if not wrapped:
            cv.put(4, 3, "✿ sawal likho — ENTER bhejo", C_DIM)
            cv.put(4, 4, "jaise: python decorator kya hai? / meri disk kyu bhar rahi", C_SLATE)
        ry2 = H - 3
        if ch["mode"] == "stream":
            sp = SPIN[int(t * 10) % len(SPIN)]
            cv.put(2, ry2, sp + " soch rahi hoon…", C_CYAN)
        else:
            cv.put(2, ry2, "✿ ", C_PINK)
            cv.put(4, ry2, clip(ch["input"] + "▌", W - 8), C_WHITE)
        return cv.render()

    def handle_fz_event(self, ev):
        kind, ch = ev[0], ev[1]
        if kind == "EOF":
            self.running = False
            return
        if kind in ("ESC", "CTRL_C"):
            self.fz = None
            return
        if kind == "CHAR" and ch and ch not in ("\\n", "\\r"):
            self.fz["q"] += ch
            self.fz["sel"] = 0
        elif kind == "BACKSPACE":
            self.fz["q"] = self.fz["q"][:-1]
        elif kind == "UP":
            self.fz["sel"] = max(0, self.fz["sel"] - 1)
        elif kind == "DOWN":
            self.fz["sel"] += 1
        elif kind == "ENTER":
            m = self._fz_matches()
            if m:
                pick = m[min(self.fz["sel"], len(m) - 1)][1]
                T = self.term
                T.buf = pick
                T.caret = len(pick)
            self.fz = None

    def _fz_matches(self):
        q = self.fz["q"].lower()
        items = list(reversed(self.term.history))
        if q:
            items = [h for h in items if q in h.lower()]
        return list(enumerate(items))[:40]

    def _draw_fz_overlay(self, cv, t):
        W, H = cv.w, cv.h
        h = 8
        y0 = H - 3 - h
        b = C_TERM_BORDER
        for i in range(6, W - 6):
            cv.set(i, y0, "─", b)
            cv.set(i, y0 + h, "─", b)
        for yy in range(y0 + 1, y0 + h):
            cv.set(6, yy, "│", b)
            cv.set(W - 7, yy, "│", b)
        cv.set(6, y0, "╭", b)
        cv.set(W - 7, y0, "╮", b)
        cv.set(6, y0 + h, "╰", b)
        cv.set(W - 7, y0 + h, "╯", b)
        cv.put(8, y0, "⌕ HISTORY", C_FUCHSIA)
        cv.put(20, y0, clip(self.fz["q"] + "▌", W - 30), C_GOLD)
        m = self._fz_matches()
        if not m:
            cv.put(9, y0 + 2, "(koi match nahi)", C_SLATE)
            return
        self.fz["sel"] = clamp(self.fz["sel"], 0, len(m) - 1)
        for r2 in range(h - 2):
            if r2 >= len(m):
                break
            num, ln = m[r2]
            sel = (r2 == self.fz["sel"])
            cv.put(8, y0 + 1 + r2, "▸" if sel else " ", C_GOLD if sel else C_SLATE)
            cv.put(10, y0 + 1 + r2, clip(ln, W - 22), C_WHITE if sel else C_OUT)

''' + DIV2, "omega methods")

rep('''                self.pump_capture()''', '''                self.pump_capture()
                self._ai_pump()''', "ai pump tick")

rx(r'foot = "F1 run[^"]*"', 'foot = "F1 run • CTRL+S save (untitled→naam) • CTRL+Z undo • CTRL+Y redo • CTRL+D dup • CTRL+F find • CTRL+G goto • CTRL+O jump • CTRL+E preview • CTRL+Q"', "foot")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

fails = [f for f in fails if f != "help rows"]
if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v24")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v25 OMEGA patched ✓  (backup: %s.bak-v24)" % P)
