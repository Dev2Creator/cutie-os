import sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "def _run_banner" in s:
    print("already patched ✓"); sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[a:]; print("  ✓", label)

rep('VERSION      = "v18"', 'VERSION      = "v19"', "version")
rep('EDITION      = "EDITOR EDITION"', 'EDITION      = "CUTE EDITION"', "edition")

rep('    "S": ("███████╗", "██╔════╝", "███████╗", "╚════██║", "███████║", "╚══════╝"),',
    '''    "S": ("███████╗", "██╔════╝", "███████╗", "╚════██║", "███████║", "╚══════╝"),
    "A": (" █████╗ ", "██╔══██╗", "███████║", "██╔══██║", "██║  ██║", "╚═╝  ╚═╝"),
    "B": ("██████╗ ", "██╔══██╗", "██████╔╝", "██╔══██╗", "██████╔╝", "╚═════╝ "),
    "D": ("██████╗ ", "██╔══██╗", "██║  ██║", "██║  ██║", "██████╔╝", "╚═════╝ "),
    "F": ("███████╗", "██╔════╝", "█████╗  ", "██╔══╝  ", "██║     ", "╚═╝     "),
    "G": (" ██████╗ ", "██╔════╝", "██║  ███╗", "██║   ██║", "╚██████╔╝", " ╚═════╝ "),
    "H": ("██╗  ██╗", "██║  ██║", "███████║", "██╔══██║", "██║  ██║", "╚═╝  ╚═╝"),
    "J": ("     ██╗", "     ██║", "     ██║", "██   ██║", "╚█████╔╝", " ╚════╝ "),
    "K": ("██╗  ██╗", "██║ ██╔╝", "█████╔╝ ", "██╔═██╗ ", "██║  ██╗", "╚═╝  ╚═╝"),
    "L": ("██╗     ", "██║     ", "██║     ", "██║     ", "███████╗", "╚══════╝"),
    "M": ("███╗   ███╗", "████╗ ████║", "██╔████╔██║", "██║╚██╔╝██║", "██║ ╚═╝ ██║", "╚═╝     ╚═╝"),
    "N": ("███╗   ██╗", "████╗  ██║", "██╔██╗ ██║", "██║╚██╗██║", "██║ ╚████║", "╚═╝  ╚═══╝"),
    "P": ("██████╗ ", "██╔══██╗", "██████╔╝", "██╔═══╝ ", "██║     ", "╚═╝     "),
    "Q": (" ██████╗ ", "██╔═══██╗", "██║   ██║", "██║  ██╔╝", "╚██████╔╝", " ╚═════╝ "),
    "R": ("██████╗ ", "██╔══██╗", "██████╔╝", "██╔══██╗", "██║  ██║", "╚═╝  ╚═╝"),
    "V": ("██╗   ██╗", "██║   ██║", "██║   ██║", "╚██╗ ██╔╝", " ╚████╔╝ ", "  ╚═══╝  "),
    "W": ("██╗    ██╗", "██║    ██║", "██║ █╗ ██║", "██║███╗██║", "╚███╔███╔╝", " ╚══╝╚══╝ "),
    "X": ("██╗  ██╗", "╚██╗██╔╝", " ╚███╔╝ ", " ██╔██╗ ", "██╔╝ ██╗", "╚═╝  ╚═╝"),
    "Y": ("██╗   ██╗", "╚██╗ ██╔╝", " ╚████╔╝ ", "  ╚██╔╝  ", "   ██║   ", "   ╚═╝   "),
    "Z": ("███████╗", "╚══███╔╝", "   ███╔╝", "  ███╔╝ ", " ███████╗", "╚══════╝"),''',
    "alphabet glyphs")

rep('''        self.push([("❯ ", C_ARROW), (line, C_WHITE)])''',
    '''        self.push([("✿ ", C_PINK), (line, C_WHITE)])''', "cute echo")

rep('''            cv.put(2, ry, "✏ " if self.prompt_name else "❯ ",
                   C_GOLD if self.prompt_name else C_ARROW)''',
    '''            if self.prompt_name:
                cv.put(2, ry, "✏ ", C_GOLD)
            else:
                _gi = int(t * 2.0) % 5
                _pg = ("✿", "❀", "♡", "✦", "❁")[_gi]
                _pc = (C_PINK, C_FUCHSIA, C_MAGENTA, C_VIOLET, C_PINK)[_gi]
                cv.put(2, ry, _pg + " ", _pc)''', "cute prompt")

rep('''right = ("⟳ " + SPIN[int(t * 10) % len(SPIN)] + " busy") if T.busy else "✦ cutie"''',
    '''right = ("⟳ " + SPIN[int(t * 10) % len(SPIN)] + " busy") if T.busy else "✿ " + getattr(self, "_pet_name", "cutie")''',
    "pet corner")

rep('''                if code == 0:
                    self.term.push([("▸ done" + dur, C_GOLD if dur else C_DIM)])''',
    '''                if code == 0:
                    self.term.push([("▸ done ✦" + dur, C_GOLD if dur else C_DIM)])''', "done sparkle")

rep('''        T.busy = True
        T.busy_label = line
        self.cap_q = queue.Queue()
        self.cap_colorizer = None
        self.cap_t0 = None''', '''        T.busy = True
        T.busy_label = line
        _me = re.search(r"\\.([A-Za-z]{1,4})\\b", line)
        _ext = ("." + _me.group(1).lower()) if _me else ""
        _lang = {".py": "PYTHON", ".sh": "SHELL", ".c": "C", ".cpp": "C++",
                 ".js": "NODE", ".java": "JAVA", ".rs": "RUST", ".go": "GO"}.get(_ext)
        if _lang:
            _run_banner(self, _lang, "▶ live output — CTRL+C kill")
        self.cap_q = queue.Queue()
        self.cap_colorizer = None
        self.cap_t0 = None''', "banner hook")

rep('''    elif ext == ".sh":
        cmd = "bash " + shlex.quote(path)
    else:
        T.push([("  ℹ ", C_DIM), (os.path.basename(path), C_VALUE),
                (" — .py / .sh hi chalte hain (ya !./file)", C_DIM)])
        return''', '''    elif ext == ".sh":
        cmd = "bash " + shlex.quote(path)
    elif ext in (".c", ".cpp"):
        cc = shutil.which("gcc" if ext == ".c" else "g++")
        if cc is None:
            T.push([("  ✗ ", C_RED), ("gcc/g++ nahi — ", C_VALUE),
                    ("!sudo pacman -S gcc", C_GOLD)])
            return
        outb = "/tmp/cutie-cc-%d" % os.getpid()
        cmd = (shlex.quote(cc) + " " + shlex.quote(path) + " -o " + outb +
               " && " + outb)
    elif ext == ".js":
        nd = shutil.which("node")
        if nd is None:
            T.dim("  node nahi — !sudo pacman -S nodejs")
            return
        cmd = shlex.quote(nd) + " " + shlex.quote(path)
    else:
        T.push([("  ℹ ", C_DIM), (os.path.basename(path), C_VALUE),
                (" — .py .sh .c .cpp .js chalte hain", C_DIM)])
        return''', "run langs")

rep('''        if ext == ".py":
            exe = shutil.which("python3") or shutil.which("python")
            if exe is None:
                T.dim("  python nahi mila")
                return
            self.start_capture(shlex.quote(exe) + " " + shlex.quote(full))
            self.cap_colorizer = _py_out_colorizer
        else:
            self.start_capture("bash " + shlex.quote(full))''',
    '''        if ext == ".py":
            exe = shutil.which("python3") or shutil.which("python")
            if exe is None:
                T.dim("  python nahi mila")
                return
            self.start_capture(shlex.quote(exe) + " " + shlex.quote(full))
            self.cap_colorizer = _py_out_colorizer
        elif ext in (".c", ".cpp"):
            cc = shutil.which("gcc" if ext == ".c" else "g++")
            if cc is None:
                T.dim("  gcc/g++ nahi — !sudo pacman -S gcc")
                return
            outb = "/tmp/cutie-cc-%d" % os.getpid()
            self.start_capture(shlex.quote(cc) + " " + shlex.quote(full) +
                               " -o " + outb + " && " + outb)
        elif ext == ".js" and shutil.which("node"):
            self.start_capture(shlex.quote(shutil.which("node")) + " " + shlex.quote(full))
        else:
            self.start_capture("bash " + shlex.quote(full))''', "cpage langs")

block("def tool_run(app, args):", '''def _run_banner(app, lang, sub):
    T = app.term
    word = "".join(ch if ch in _GLYPHS else " " for ch in lang.upper())[:12]
    rows = ["".join(r) for r in zip(*(_GLYPHS[c] for c in word))]
    T.push([("  ╭─", C_SLATE), (" ▶ RUNNING ", C_FUCHSIA), ("─" * 30, C_SLATE)])
    for r in rows:
        segs = []
        n = max(1, len(r))
        chunks = 6
        step = n / chunks
        for c in range(chunks):
            sseg = r[int(c * step):int((c + 1) * step)]
            if sseg:
                segs.append((sseg, grad((c + 0.5) / chunks)))
        T.push([("  ", C_OUT)] + segs)
    T.push([("  ╰─ ", C_SLATE), (sub, C_DIM)])


''', "banner def")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

fails = [f for f in fails if f != "help rows"]
if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

import shutil as _sh
_sh.copy(P, P + ".bak-v18")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v19 CUTE patched ✓  (backup: %s.bak-v18)" % P)
