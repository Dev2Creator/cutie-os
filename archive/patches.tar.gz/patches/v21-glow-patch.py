import sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "_epage_refresh_check" in s:
    print("already patched ✓"); sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

def span(start_m, end_m, new, label):
    global s
    try:
        a = s.index(start_m); b = s.index(end_m, a)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[b:]; print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[a:]; print("  ✓", label)

rep('VERSION      = "v20"', 'VERSION      = "v21"', "version")
rep('EDITION      = "SUGAR EDITION"', 'EDITION      = "GLOW EDITION"', "edition")

rep('''        self.epage = {"path": p, "lines": lines, "cy": 0, "cx": 0,
                      "scroll": 0, "hscroll": 0, "dirty": False,
                      "confirm": False,
                      "msg": "✎ CUTIE EDITOR — F1 run • CTRL+S save • CTRL+Q quit",
                      "msg_t": time.monotonic()}''',
    '''        self.epage = {"path": p, "lines": lines, "cy": 0, "cx": 0,
                      "scroll": 0, "hscroll": 0, "dirty": False,
                      "confirm": False, "banner": True, "preview": True,
                      "check": None, "check_t": 0.0, "outline": [], "out_sel": 0,
                      "msg": "✎ CUTIE EDITOR — F1 run • CTRL+S save • CTRL+Q quit",
                      "msg_t": time.monotonic()}''', "epage state")

rep('''        if kind == "CTRL_G":
            ep["mini"] = {"mode": "goto", "text": ""}
            return''', '''        if kind == "CTRL_G":
            ep["mini"] = {"mode": "goto", "text": ""}
            return
        if kind == "CTRL_E":
            ep["preview"] = not ep.get("preview", True)
            ep["msg"] = "preview " + ("on ✦" if ep["preview"] else "off")
            ep["msg_t"] = time.monotonic()
            return
        if kind == "CTRL_B":
            ep["banner"] = not ep.get("banner", True)
            return
        if kind == "CTRL_O":
            self._epage_next_outline()
            return''', "new keys")

HELPERS2 = '''def _ep_check_source(path, lines):
    if not path.endswith(".py"):
        return None
    src = "\\n".join(lines[:3000])
    try:
        compile(src, path, "exec")
        return ("ok", None)
    except SyntaxError as e:
        return ("err", (e.lineno or 0, e.msg or "syntax error"))
    except Exception:
        return ("err", (0, "compile error"))


def _ep_outline(lines):
    out = []
    for i, ln in enumerate(lines):
        m = re.match(r"\\s*(def|class)\\s+([A-Za-z_]\\w*)", ln)
        if m:
            out.append((i, m.group(1), m.group(2)))
        if len(out) >= 20:
            break
    return out


def _paint_lang_banner(cv, x0, y0, word, t):
    word = (word or "CODE").upper()[:9]
    if len(word.strip()) < 2:
        word = word + " LANG"
    word = "".join(ch if ch in _GLYPHS else " " for ch in word)
    rows = ["".join(r) for r in zip(*(_GLYPHS[c] for c in word))]
    n = max(1, disp_width(rows[0]))
    sweep = (t * 16.0) % (n + 24.0) - 12.0
    for ry, line in enumerate(rows):
        for i, ch in enumerate(line):
            if ch == " ":
                continue
            base = grad(i / max(1, n - 1))
            d = abs(i - sweep)
            if d < 4.0:
                c = mix(base, C_WHITE, 0.85 - d / 5.0)
            else:
                c = scale(base, 0.92)
            cv.set(x0 + i, y0 + ry, ch, c)
    return len(rows)


'''

block("def tool_ed(app, args):", HELPERS2, "glow helpers")

span("    def _epage_ensure_visible(self):", "    def handle_epage_event(self, ev):",
     '''    def _epage_code_w(self):
        W = self.cv.w
        ep = self.epage
        if ep.get("preview", True) and W >= 100:
            return max(40, int(W * 0.58))
        return W

    def _epage_ensure_visible(self):
        ep = self.epage
        H = self.cv.h
        W = self.cv.w
        bh = 6 if (ep.get("banner", True) and H >= 26 and W >= 70) else 0
        body = max(1, H - 6 - bh)
        if ep["scroll"] > ep["cy"]:
            ep["scroll"] = ep["cy"]
        if ep["scroll"] < ep["cy"] - body + 1:
            ep["scroll"] = ep["cy"] - body + 1
        ep["scroll"] = clamp(ep["scroll"], 0, max(0, len(ep["lines"]) - 1))
        w = max(4, self._epage_code_w() - 12)
        if ep["cx"] < ep["hscroll"]:
            ep["hscroll"] = ep["cx"]
        if ep["cx"] > ep["hscroll"] + w - 1:
            ep["hscroll"] = ep["cx"] - w + 1
        ep["hscroll"] = max(0, ep["hscroll"])

''', "ensure visible v2")

DIV2 = "# ───────────────────────────── self check / main"

NEWBUILD = '''    def _epage_refresh_check(self, ep, now):
        if now - ep.get("check_t", 0.0) < 0.45:
            return
        ep["check_t"] = now
        ep["check"] = _ep_check_source(ep["path"], ep["lines"])
        ep["outline"] = _ep_outline(ep["lines"])

    def _epage_next_outline(self):
        ep = self.epage
        ol = ep.get("outline") or []
        if not ol:
            ep["msg"] = "✧ koi def/class nahi mila"
            ep["msg_t"] = time.monotonic()
            return
        nxt = None
        for k, item in enumerate(ol):
            if item[0] > ep["cy"]:
                nxt = k
                break
        if nxt is None:
            nxt = 0
        ep["out_sel"] = nxt
        ep["cy"] = ol[nxt][0]
        ep["cx"] = 0
        ep["msg"] = "→ %s %s  (line %d)" % (ol[nxt][1], ol[nxt][2], ol[nxt][0] + 1)
        ep["msg_t"] = time.monotonic()
        self._epage_ensure_visible()

    def build_epage_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        ep = self.epage
        now = time.monotonic()
        self._epage_refresh_check(ep, now)
        show_banner = ep.get("banner", True) and H >= 26 and W >= 70
        icon, lname = _ep_lang(ep["path"])
        use_preview = ep.get("preview", True) and W >= 100
        code_w = self._epage_code_w()
        use_preview = use_preview and code_w < W - 20
        cx_max = (code_w - 3) if use_preview else (W - 3)
        for i in range(W):
            c = scale(grad(i / max(1, W - 1)), 0.8)
            cv.set(i, 0, "─", c)
            cv.set(i, H - 1, "─", c)
        for yy in range(1, H - 1):
            c = scale(grad(yy / max(1, H - 1)), 0.8)
            cv.set(0, yy, "│", c)
            cv.set(W - 1, yy, "│", c)
        cv.set(0, 0, "╭", scale(grad(0.0), 0.8))
        cv.set(W - 1, 0, "╮", scale(grad(1.0), 0.8))
        cv.set(0, H - 1, "╰", scale(grad(0.0), 0.8))
        cv.set(W - 1, H - 1, "╯", scale(grad(1.0), 0.8))
        for k in range(6):
            sx = (k * 57 + int(t * 2.2) + k * k * 11) % max(4, W - 6) + 3
            sy = (k * 31 + int(t * 1.1)) % max(1, H - 14) + (9 if show_banner else 3)
            cv.set(sx, sy, "✦", scale(C_VIOLET, 0.32 + 0.15 * math.sin(t * 1.9 + k * 1.3)))
        tt = "✿ edit " + icon + " "
        cv.put(2, 0, tt, C_PINK)
        x = 2 + disp_width(tt)
        nm = os.path.basename(ep["path"])
        for i, chx in enumerate(nm):
            if x >= W - 30:
                break
            cv.put(x, 0, chx, grad(i / max(1, len(nm) - 1)))
            x += char_width(chx)
        cv.put(x + 1, 0, "●" if ep["dirty"] else "○", C_GOLD if ep["dirty"] else C_SLATE)
        pos = "Ln %d, Col %d " % (ep["cy"] + 1, ep["cx"] + 1)
        cv.put(W - 2 - disp_width(pos), 0, pos, C_LABEL)
        if show_banner:
            _paint_lang_banner(cv, 4, 1, lname.upper(), t)
            cv.put(2, 7, "·" * max(0, (code_w if use_preview else W) - 5),
                   scale(C_SLATE, 0.65))
        content_top = 8 if show_banner else 2
        body = max(1, H - 5 - content_top)
        lines = ep["lines"]
        top = clamp(ep["scroll"], 0, max(0, len(lines) - 1))
        nl = len(lines)
        if use_preview:
            for yy in range(content_top, H - 4):
                cv.set(code_w, yy, "│", scale(C_SLATE, 0.55))
        for r in range(body):
            idx = top + r
            if idx >= nl:
                break
            yy = content_top + r
            cur = (idx == ep["cy"])
            cv.put(1, yy, "❯" if cur else " ", C_GOLD if cur else C_SLATE)
            ncol = grad(idx / max(1, nl))
            if cur:
                ncol = scale(ncol, 1.45)
            cv.put(2, yy, "%4d " % (idx + 1), ncol)
            ln = lines[idx]
            hs = ep["hscroll"]
            x = 7
            for seg, col in _pyhl(ln):
                segw = disp_width(seg)
                endx = x + segw
                if endx <= 7 + hs:
                    x = endx
                    continue
                if x < 7 + hs:
                    cutd = hs - (x - 7)
                    seg, segw = substr_width(seg, cutd, max(0, segw - cutd))
                if x + segw > cx_max:
                    seg, segw = substr_width(seg, 0, max(0, cx_max - x))
                if seg:
                    cv.put(x, yy, seg, col)
                x += segw
                if x >= cx_max:
                    break
            ind = len(re.match(r"[ ]*", ln).group(0))
            for g in range(3, ind, 4):
                gx = 7 + g - hs
                if 7 <= gx < cx_max:
                    cv.set(gx, yy, "┊", scale(C_SLATE, 0.5))
        cury = content_top + (ep["cy"] - top)
        if content_top <= cury < content_top + body:
            curline = lines[ep["cy"]]
            visx = 7 + max(0, ep["cx"] - ep["hscroll"])
            if visx < cx_max:
                if (t % 1.1) < 0.6:
                    chb = curline[ep["cx"]] if ep["cx"] < len(curline) else " "
                    cv.put(visx, cury, chb if chb != " " else "█", C_WHITE)
                elif ep["cx"] < len(curline):
                    cv.put(visx, cury, curline[ep["cx"]], C_WHITE)
        if use_preview:
            px = code_w + 2
            pw = W - px - 2
            if pw > 12:
                cv.put(px, content_top, "◆ LIVE PREVIEW", C_TITLE)
                yy = content_top + 1
                if ep["path"].endswith(".py"):
                    ck = ep.get("check")
                    if ck is not None:
                        if ck[0] == "ok":
                            cv.put(px, yy, "✓ syntax OK", C_CYAN)
                        else:
                            cv.put(px, yy, clip("✗ line %d: %s" % (ck[1][0], ck[1][1]), pw), C_RED)
                else:
                    cv.put(px, yy, clip("· " + lname + " — run se check hota", pw), C_SLATE)
                yy += 2
                cv.put(px, yy, "◆ OUTLINE", C_FUCHSIA)
                yy += 1
                ol = ep.get("outline") or []
                if not ol:
                    cv.put(px, yy, "(khaali — def/class likho)", C_SLATE)
                    yy += 1
                else:
                    for k2, (li, kd, nm2) in enumerate(ol):
                        if yy >= H - 9 or k2 > 16:
                            break
                        selm = (k2 == ep.get("out_sel", 0))
                        cv.put(px, yy, "❯ " if selm else "  ", C_GOLD if selm else C_SLATE)
                        cc = C_GOLD if selm else (C_VIOLET if kd == "class" else C_CYAN)
                        cv.put(px + 2, yy, clip("%-5s %s" % (kd, nm2), max(4, pw - 9)), cc)
                        cv.put(px + max(6, pw - 6), yy, "%4d" % (li + 1), C_SLATE)
                        yy += 1
                sy2 = max(yy + 1, H - 9)
                if sy2 < H - 6:
                    cv.put(px, sy2, "◆ STATS", C_FUCHSIA)
                    stt = "%d lines • %d ch" % (nl, sum(len(l) for l in lines))
                    cv.put(px, sy2 + 1, clip(stt, pw), C_LABEL)
                    cv.put(px, sy2 + 2, clip("CTRL+O jump • CTRL+E hide", pw), C_SLATE)
        idle = now - getattr(self, "_ep_last_key", now)
        pname = getattr(self, "_pet_name", "momo").lower()
        if idle > 45:
            mx = max(4, W - 18)
            my2 = max(4, H // 2)
            cv.put(mx, my2, "=︿=", scale(C_PINK, 0.65))
            cv.put(mx, my2 + 1, pname + " so rahi hai…", scale(C_SLATE, 0.75))
        my = H - 4
        mini = ep.get("mini")
        msg = ep.get("msg") or ""
        show_msg = msg and (now - ep.get("msg_t", 0)) < 5.0
        if mini:
            lab = "/ find: " if mini["mode"] == "find" else "/ goto: "
            cv.put(2, my, lab, C_FUCHSIA)
            cv.put(2 + disp_width(lab), my, mini["text"] + "▌", C_WHITE)
        else:
            left = "%s %s%s  %d ch" % (icon, lname, "  ●" if ep["dirty"] else "", nl)
            cv.put(2, my, clip(left, 34), C_LABEL)
            if show_msg:
                cv.put(max(2, (W - disp_width(msg)) // 2), my, clip(msg, W - 40), C_GOLD)
            else:
                rot = _CUTE_MSGS[int(t / 5.0) % len(_CUTE_MSGS)]
                cv.put(max(2, (W - disp_width(rot)) // 2), my, clip(rot, W - 40),
                       scale(C_PINK, 0.9))
        pd = ep["path"]
        home = os.path.expanduser("~")
        if pd.startswith(home):
            pd = pd.replace(home, "~", 1)
        cv.put(2, my + 1, clip(pd, W - 6), scale(C_SLATE, 0.85))
        foot = "F1 run • CTRL+S save • CTRL+D dup • CTRL+K cut • CTRL+F find • CTRL+G goto • CTRL+T template • CTRL+O outline • CTRL+E preview • CTRL+B banner • CTRL+Q"
        cv.put(max(2, (W - disp_width(foot)) // 2), H - 2, clip(foot, W - 4), C_SLATE)
        return cv.render()


'''

span("    def build_epage_frame(self, t):", DIV2, NEWBUILD, "build v3 glow")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

fails = [f for f in fails if f != "help rows"]
if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

import shutil as _sh
_sh.copy(P, P + ".bak-v20")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v21 GLOW patched ✓  (backup: %s.bak-v20)" % P)
