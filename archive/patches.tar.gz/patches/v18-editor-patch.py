import sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "def build_epage_frame" in s:
    print("already patched ✓"); sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label); print("  ✗", label); return
    s = s[:a] + new + s[a:]; print("  ✓", label)

rep('VERSION      = "v17"', 'VERSION      = "v18"', "version")
rep('EDITION      = "DEV EDITION"', 'EDITION      = "EDITOR EDITION"', "edition")

rep('''        if c == 0x17:
            return ("CTRL_W", 1, None)
        if c < 0x20:
            return ("UNKNOWN", 1, None)''', '''        if c == 0x17:
            return ("CTRL_W", 1, None)
        if c == 0x13:
            return ("CTRL_S", 1, None)
        if c == 0x11:
            return ("CTRL_Q", 1, None)
        if c < 0x20:
            return ("UNKNOWN", 1, None)''', "ctrl s/q keys")

rep('''        if kind == "F1":
            if self.cpage:
                self.handle_cpage_event(ev)
            else:
                self.open_cpage()
            return''', '''        if kind == "F1":
            if self.epage:
                self._epage_run()
            elif self.cpage:
                self.handle_cpage_event(ev)
            else:
                self.open_cpage()
            return''', "F1 editor run")

rep('''        if self.cpage:
            self.handle_cpage_event(ev)
            return''', '''        if self.epage:
            self.handle_epage_event(ev)
            return
        if self.cpage:
            self.handle_cpage_event(ev)
            return''', "epage routing")

rep('''        if self.cpage and not L.too_small:
            cv.clear()
            return self.build_cpage_frame(t)''', '''        if self.epage and not L.too_small:
            cv.clear()
            return self.build_epage_frame(t)
        if self.cpage and not L.too_small:
            cv.clear()
            return self.build_cpage_frame(t)''', "epage frame")

rep('''        self.cpage = None
        self.cap_colorizer = None
        self.cap_t0 = None''', '''        self.cpage = None
        self.cap_colorizer = None
        self.cap_t0 = None
        self.epage = None''', "epage init")

rep('''        elif kind == "CHAR" and ch in ("e", "E"):
            if n:
                self._cpage_edit(ents[min(cp["sel"], n - 1)])''',
    '''        elif kind == "CHAR" and ch in ("e", "E"):
            if n:
                self.open_epage(os.path.join(cp["cwd"], ents[min(cp["sel"], n - 1)]))''',
    "cpage E internal")

rep('''    Tool("code", ["ide"], "F1 browser — enter run • V preview • E edit • 1-9 quick", "dev", tool_code),''',
    '''    Tool("code", ["ide"], "F1 browser — enter run • V preview • E edit • 1-9 quick", "dev", tool_code),
    Tool("ed", ["write"], "CUTIE EDITOR — ed file.py • multi-line • F1 run", "dev", tool_ed),''', "ed registry")

DEFS = '''def tool_ed(app, args):
    if not args:
        app.term.dim("  usage: ed file.py   (CUTIE editor — type karo, F1 se run)")
        return
    app.open_epage(" ".join(args))


'''

block("def tool_music(app, args):", DEFS, "ed tool")

DIV2 = "# ───────────────────────────── self check / main"
block(DIV2, '''    # ── v18: CUTIE EDITOR (mini VS Code, HUD ke andar) ──

    def open_epage(self, path):
        p = os.path.expanduser(path)
        if os.path.isdir(p):
            self.term.dim("  ye folder hai — file ka naam do")
            return
        lines = [""]
        try:
            with open(p, "rb") as f:
                txt = f.read(400000).decode("utf-8", "replace")
            lines = txt.split("\\n")
            if len(lines) > 5000:
                lines = lines[:5000]
        except FileNotFoundError:
            pass
        except Exception as e:
            self.term.push([("  ✗ read fail: ", C_RED), (str(e)[:60], C_DIM)])
            return
        if not lines:
            lines = [""]
        self.epage = {"path": p, "lines": lines, "cy": 0, "cx": 0,
                      "scroll": 0, "hscroll": 0, "dirty": False,
                      "confirm": False,
                      "msg": "✎ CUTIE EDITOR — F1 run • CTRL+S save • CTRL+Q quit",
                      "msg_t": time.monotonic()}

    def _epage_save(self, quiet=False):
        ep = self.epage
        try:
            d = os.path.dirname(ep["path"])
            if d:
                os.makedirs(d, exist_ok=True)
            with open(ep["path"], "w", encoding="utf-8") as f:
                f.write("\\n".join(ep["lines"]) + "\\n")
            ep["dirty"] = False
            ep["msg"] = "saved ✓ " + ep["path"]
            ep["msg_t"] = time.monotonic()
            if not quiet:
                self.term.push([("  ✎ saved » ", C_DIM), (ep["path"], C_GOLD)])
            return True
        except Exception as e:
            ep["msg"] = "✗ save fail: " + str(e)[:50]
            ep["msg_t"] = time.monotonic()
            return False

    def _epage_run(self):
        ep = self.epage
        if not self._epage_save(quiet=True):
            return
        path = ep["path"]
        self.term.push([("  ✎ " + path, C_DIM), ("  (saved)", C_SLATE)])
        self.epage = None
        ext = os.path.splitext(path)[1].lower()
        exe = shutil.which("python3") or shutil.which("python")
        if ext == ".py" and exe:
            self.start_capture(shlex.quote(exe) + " " + shlex.quote(path))
            self.cap_colorizer = _py_out_colorizer
        elif ext == ".sh":
            self.start_capture("bash " + shlex.quote(path))
        else:
            self.term.push([("  ℹ ", C_DIM), (path, C_VALUE),
                            (" — .py/.sh hi run hote hain (F2 se save ho gaya)", C_DIM)])
            return
        self.cap_t0 = time.monotonic()
        self.term.push([("  ▶ F1 run » ", C_CYAN), ("output panel me aa raha hai", C_DIM)])
        self.cmd_tick()
        self.add_xp(2)

    def _epage_enter(self):
        ep = self.epage
        lines = ep["lines"]
        ln = lines[ep["cy"]]
        indent = re.match(r"[ \\t]*", ln).group(0)
        if ln[:ep["cx"]].rstrip().endswith(":"):
            indent += "    "
        rest = ln[ep["cx"]:]
        lines[ep["cy"]] = ln[:ep["cx"]]
        lines.insert(ep["cy"] + 1, indent + rest)
        ep["cy"] += 1
        ep["cx"] = len(indent)
        ep["dirty"] = True

    def _epage_ensure_visible(self):
        ep = self.epage
        body = max(1, self.cv.h - 6)
        if ep["scroll"] > ep["cy"]:
            ep["scroll"] = ep["cy"]
        if ep["scroll"] < ep["cy"] - body + 1:
            ep["scroll"] = ep["cy"] - body + 1
        ep["scroll"] = clamp(ep["scroll"], 0, max(0, len(ep["lines"]) - 1))
        w = max(4, self.cv.w - 12)
        if ep["cx"] < ep["hscroll"]:
            ep["hscroll"] = ep["cx"]
        if ep["cx"] > ep["hscroll"] + w - 1:
            ep["hscroll"] = ep["cx"] - w + 1
        ep["hscroll"] = max(0, ep["hscroll"])

    def handle_epage_event(self, ev):
        kind, ch = ev[0], ev[1]
        ep = self.epage
        lines = ep["lines"]
        if kind == "EOF":
            self.running = False
            return
        if kind == "CTRL_Q":
            if ep["dirty"] and not ep.get("confirm"):
                ep["confirm"] = True
                ep["msg"] = "⚠ modified! CTRL+Q dobara = bina save chhodo"
                ep["msg_t"] = time.monotonic()
                return
            self.epage = None
            return
        ep["confirm"] = False
        if kind == "CTRL_S":
            self._epage_save()
            return
        if kind == "F2":
            self._epage_save()
            return
        if kind == "F1":
            self._epage_run()
            return
        if kind == "ESC":
            if ep["dirty"]:
                ep["msg"] = "dirty — CTRL+S save • CTRL+Q ×2 discard"
                ep["msg_t"] = time.monotonic()
            else:
                self.epage = None
            return
        if kind == "CHAR":
            if ch in ("\\n", "\\r"):
                self._epage_enter()
                self._epage_ensure_visible()
                return
            if ch == "\\t":
                ln = lines[ep["cy"]]
                lines[ep["cy"]] = ln[:ep["cx"]] + "    " + ln[ep["cx"]:]
                ep["cx"] += 4
            else:
                ln = lines[ep["cy"]]
                lines[ep["cy"]] = ln[:ep["cx"]] + ch + ln[ep["cx"]:]
                ep["cx"] += len(ch)
            ep["dirty"] = True
        elif kind == "ENTER":
            self._epage_enter()
        elif kind == "BACKSPACE":
            if ep["cx"] > 0:
                ln = lines[ep["cy"]]
                lines[ep["cy"]] = ln[:ep["cx"] - 1] + ln[ep["cx"]:]
                ep["cx"] -= 1
            elif ep["cy"] > 0:
                prev = lines[ep["cy"] - 1]
                lines[ep["cy"] - 1] = prev + lines[ep["cy"]]
                lines.pop(ep["cy"])
                ep["cy"] -= 1
                ep["cx"] = len(prev)
            else:
                return
            ep["dirty"] = True
        elif kind == "DEL":
            ln = lines[ep["cy"]]
            if ep["cx"] < len(ln):
                lines[ep["cy"]] = ln[:ep["cx"]] + ln[ep["cx"] + 1:]
            elif ep["cy"] < len(lines) - 1:
                lines[ep["cy"]] = ln + lines.pop(ep["cy"] + 1)
            else:
                return
            ep["dirty"] = True
        elif kind == "LEFT":
            if ep["cx"] > 0:
                ep["cx"] -= 1
            elif ep["cy"] > 0:
                ep["cy"] -= 1
                ep["cx"] = len(lines[ep["cy"]])
        elif kind == "RIGHT":
            if ep["cx"] < len(lines[ep["cy"]]):
                ep["cx"] += 1
            elif ep["cy"] < len(lines) - 1:
                ep["cy"] += 1
                ep["cx"] = 0
        elif kind == "UP":
            if ep["cy"] > 0:
                ep["cy"] -= 1
                ep["cx"] = min(ep["cx"], len(lines[ep["cy"]]))
        elif kind == "DOWN":
            if ep["cy"] < len(lines) - 1:
                ep["cy"] += 1
                ep["cx"] = min(ep["cx"], len(lines[ep["cy"]]))
        elif kind == "HOME":
            ep["cx"] = 0
        elif kind == "END":
            ep["cx"] = len(lines[ep["cy"]])
        elif kind == "PGUP":
            ep["cy"] = max(0, ep["cy"] - 15)
            ep["cx"] = min(ep["cx"], len(lines[ep["cy"]]))
        elif kind == "PGDN":
            ep["cy"] = min(len(lines) - 1, ep["cy"] + 15)
            ep["cx"] = min(ep["cx"], len(lines[ep["cy"]]))
        self._epage_ensure_visible()

    def build_epage_frame(self, t):
        cv = self.cv
        W, H = cv.w, cv.h
        b = C_TERM_BORDER
        ep = self.epage
        cv.put(0, 0, "╭" + "─" * (W - 2) + "╮", b)
        cv.put(0, H - 1, "╰" + "─" * (W - 2) + "╯", b)
        for yy in range(1, H - 1):
            cv.put(0, yy, "│", b)
            cv.put(W - 1, yy, "│", b)
        home = os.path.expanduser("~")
        disp = ep["path"].replace(home, "~", 1) if ep["path"].startswith(home) else ep["path"]
        tt = "✎ " + os.path.basename(ep["path"])
        cv.put(2, 0, clip(tt, 26), C_TITLE)
        x = 2 + disp_width(clip(tt, 26)) + 1
        cv.put(x, 0, "●" if ep["dirty"] else "○", C_GOLD if ep["dirty"] else C_SLATE)
        x += 2
        if x < W - 34:
            cv.put(x, 0, clip(disp, W - x - 34), C_SLATE)
        pos = "Ln %d, Col %d " % (ep["cy"] + 1, ep["cx"] + 1)
        cv.put(W - 2 - disp_width(pos), 0, pos, C_LABEL)
        body = H - 6
        lines = ep["lines"]
        top = clamp(ep["scroll"], 0, max(0, len(lines) - 1))
        nl = len(lines)
        for r in range(body):
            idx = top + r
            if idx >= nl:
                break
            yy = 2 + r
            cv.put(2, yy, "%4d " % (idx + 1), grad(idx / max(1, nl)))
            ln = lines[idx]
            hs = ep["hscroll"]
            x = 7
            for seg, col in _pyhl(ln):
                segw = disp_width(seg)
                endx = x + segw
                if endx <= 7 + hs:
                    x = endx
                    continue
                if x < 7 + hs:
                    cutd = hs - (x - 7)
                    seg, segw = substr_width(seg, cutd, max(0, segw - cutd))
                if x + segw > W - 3:
                    seg, segw = substr_width(seg, 0, max(0, W - 3 - x))
                if seg:
                    cv.put(x, yy, seg, col)
                x += segw
                if x >= W - 3:
                    break
        cury = 2 + (ep["cy"] - top)
        if 0 <= cury - 2 < body:
            curline = lines[ep["cy"]]
            visx = 7 + max(0, ep["cx"] - ep["hscroll"])
            if visx < W - 3:
                if (t % 1.1) < 0.6:
                    chb = curline[ep["cx"]] if ep["cx"] < len(curline) else " "
                    cv.put(visx, cury, chb if chb != " " else "█", C_WHITE)
                elif ep["cx"] < len(curline):
                    cv.put(visx, cury, curline[ep["cx"]], C_WHITE)
        my = H - 4
        msg = ep.get("msg") or ""
        if msg and (time.monotonic() - ep.get("msg_t", 0)) < 6.0:
            cv.put(2, my, clip(msg, W - 6), C_GOLD)
        foot = "ENTER new line + auto-indent • TAB 4sp • F1 RUN • CTRL+S save • CTRL+Q quit"
        cv.put(max(2, (W - disp_width(foot)) // 2), H - 2, clip(foot, W - 4), C_SLATE)
        return cv.render()


''' + DIV2, "editor methods")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

import shutil as _sh
_sh.copy(P, P + ".bak-v17")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v18 EDITOR patched ✓  (backup: %s.bak-v17)" % P)

