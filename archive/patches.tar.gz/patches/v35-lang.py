import re
import shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "tool_lang2" in s:
    print("already patched ✓")
    sys.exit(0)
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label)
        print("  ✗", label)
        return
    s = s.replace(old, new, 1)
    print("  ✓", label)

def rx(pat, repl, label):
    global s
    s2, n = re.subn(pat, repl, s, count=1)
    if n == 0:
        fails.append(label)
        print("  ✗", label)
        return
    s = s2
    print("  ✓", label)

def block(start_m, new, label):
    global s
    try:
        a = s.index(start_m)
    except ValueError:
        fails.append(label)
        print("  ✗", label)
        return
    s = s[:a] + new + s[a:]
    print("  ✓", label)

rx(r'VERSION\s*=\s*"[^"]*"', 'VERSION      = "v3.5.0"', "version")
rx(r'EDITION\s*=\s*"[^"]*"', 'EDITION      = "CODE LANG v2"', "edition")

rep('''    ("first_buy", "Code Queen", "pehla stealth order banaya 🛒"),''',
    '''    ("first_buy", "Code Queen", "pehla stealth order banaya 🛒"),
    ("lang_master", "Language Architect", "50+ baar code use kiya 🏆"),
    ("combo_king", "Combo Master", "5+ items ka ek order"),''',
    "lang achievements")

rep('''    Tool("buy", ["shop"], "stealth shopping code — buy o(wish(nu(ul(nap(m)))))", "life", tool_buy),''',
    '''    Tool("buy", ["shop"], "stealth shopping code — buy o(wish(nu(ul(nap(m)))))", "life", tool_buy),
    Tool("lang2", ["sl"], "FULL stealth language — q3 now del gift bud no or #", "life", tool_lang2),''',
    "lang2 registry")

DATA = '''LANG2_BRANDS = {"nu": "Whisper", "stay": "Stayfree", "fi": "Sofy",
                "ma": "Maxi", "fe": "Pee-Safe", "eve": "Everteen",
                "ine": "Nine", "plu": "Plush"}
LANG2_SUBS = {"ul": "Ultra", "dr": "Dry-Max", "bo": "Bodyfit",
              "ch": "Choice", "co": "Cotton", "xl": "XL-type"}
LANG2_SIZES = {"s": "S", "m": "M", "l": "L", "xl": "XL"}
LANG2_ITEMS = {"nap": "Pad", "pan": "Period Panty", "tie": "Panty",
               "cup": "Menstrual Cup", "heat": "Heat Patch",
               "ibf": "IB Profen", "hotbag": "Hot Water Bag"}
LANG2_HELP = (
    "╭─ 🛒 STEALTH LANG v2 — full grammar ─────────────────╮",
    "│                                                     │",
    "│ CORE                                                │",
    "│   o(...)          order                             │",
    "│   wish(brand)     brand: nu stay fi ma fe eve ine plu│",
    "│   <sub>(...)      type: ul dr bo ch co xl           │",
    "│   nap/pan/tie/cup/heat/ibf/hotbag(sz)               │",
    "│   br(num(cup))    bra 28-42: br(32(m))              │",
    "│   lin(...)        lingerie dabba                    │",
    "│                                                     │",
    "│ QUANTITY & COMBOS                                   │",
    "│   q<N>(...)       N pieces: q3(nap(m))             │",
    "│   A + B + C       unlimited combos                  │",
    "│   list(A, B, C)   multi-order batch                 │",
    "│                                                     │",
    "│ FILTERS & FLAGS                                     │",
    "│   pri(low/high)   price hint                        │",
    "│   bud(<amt>, ...) budget: bud(500, ...)             │",
    "│   now(...)        urgent 🚨                         │",
    "│   del(home/stealth) delivery mode                   │",
    "│   gift(\"naam\")     gift wrap + naam                │",
    "│   no(<sub>)       ye mat lena                       │",
    "│   or(A, B)        ya to A ya B                      │",
    "│   # comment       line me note                      │",
    "│                                                     │",
    "│ COMMANDS                                            │",
    "│   lang2           ye help                           │",
    "│   buy copy        clipboard                         │",
    "│   buy list        history                           │",
    "│   buy total       sab orders ka total               │",
    "│   buy export      homework-format export            │",
    "╰─────────────────────────────────────────────────────╯",
)


def _l2_parse(text, pos, depth=0, meta=None):
    if meta is None:
        meta = {}
    items = []
    n = len(text)
    while pos < n:
        while pos < n and text[pos] in " \\t":
            pos += 1
        if pos >= n:
            break
        if text[pos] == "#":
            break
        m = re.match(r"[A-Za-z]+\\(|[+)]|\\d+|\\\"[^\\\"]*\\\"", text[pos:])
        if not m:
            raise ValueError("galat cheez: " + text[pos:pos + 14])
        tok = m.group(0)
        pos += m.end()
        if tok == ")":
            if depth == 0:
                raise ValueError("extra ) mila")
            return items, meta, pos
        if tok == "+":
            continue
        if tok.startswith("\\""):
            meta.setdefault("gift", []).append(tok.strip("\\""))
            continue
        if tok.isdigit():
            items.append(int(tok))
            continue
        if not tok.endswith("("):
            raise ValueError("anjaan shabd: " + tok)
        fn = tok[:-1].lower()
        if fn == "o":
            inner, meta, pos = _l2_parse(text, pos, depth + 1, meta)
            items.extend(inner)
            continue
        if fn == "list":
            inner, meta, pos = _l2_parse(text, pos, depth + 1, meta)
            items.extend(inner)
            continue
        if fn == "wish":
            inner, meta, pos = _l2_parse(text, pos, depth + 1, meta)
            b2 = inner[0] if inner else ""
            if b2 not in LANG2_BRANDS:
                raise ValueError("brand code galat (nu/stay/fi/ma/fe/eve/ine/plu)")
            meta["brand"] = LANG2_BRANDS[b2]
            continue
        if fn == "pri":
            inner, meta, pos = _l2_parse(text, pos, depth + 1, meta)
            if inner and inner[0] in ("low", "high"):
                meta["price"] = inner[0]
            continue
        if fn == "bud":
            inner, meta, pos = _l2_parse(text, pos, depth + 1, meta)
            amt = None
            for it in inner:
                if isinstance(it, int):
                    amt = it
                    break
            if amt is None:
                raise ValueError("bud(500, ...) — amount number do")
            meta["budget"] = amt
            continue
        if fn == "now":
            meta["urgent"] = True
            inner, meta, pos = _l2_parse(text, pos, depth + 1, meta)
            items.extend(inner)
            continue
        if fn == "del":
            inner, meta, pos = _l2_parse(text, pos, depth + 1, meta)
            d2 = inner[0] if inner else ""
            if d2 not in ("home", "stealth"):
                raise ValueError("del(home) ya del(stealth)")
            meta["delivery"] = d2
            continue
        if fn == "gift":
            inner, meta, pos = _l2_parse(text, pos, depth + 1, meta)
            for it in inner:
                if isinstance(it, str):
                    meta.setdefault("gift", []).append(it)
            continue
        if fn == "no":
            inner, meta, pos = _l2_parse(text, pos, depth + 1, meta)
            for it in inner:
                if isinstance(it, str) and it in LANG2_SUBS:
                    meta.setdefault("avoid", set()).add(LANG2_SUBS[it])
            continue
        if fn == "or":
            inner, meta, pos = _l2_parse(text, pos, depth + 1, meta)
            meta.setdefault("or_choices", []).append(inner)
            continue
        if fn == "q":
            inner, meta, pos = _l2_parse(text, pos, depth + 1, meta)
            qty = 1
            real = []
            for it in inner:
                if isinstance(it, int):
                    qty = it
                else:
                    real.append(it)
            for r2 in real:
                if isinstance(r2, str):
                    items.extend([r2] * qty)
            continue
        if fn == "br":
            inner, meta, pos = _l2_parse(text, pos, depth + 1, meta)
            num = None
            cup = None
            for it in inner:
                if isinstance(it, int):
                    num = it
                elif isinstance(it, str):
                    cup = it
            if num is None or not (28 <= num <= 42):
                raise ValueError("bra size 28-42: br(32(m))")
            cup = (cup or "m").lower()
            if cup not in LANG2_SIZES:
                raise ValueError("cup: s/m/l/xl")
            items.append("Bra %d (%s)" % (num, LANG2_SIZES[cup].upper()))
            continue
        if fn in LANG2_ITEMS:
            inner, meta, pos = _l2_parse(text, pos, depth + 1, meta)
            sz = (inner[0] if inner else "m")
            if isinstance(sz, int):
                sz = "m"
            sz = str(sz).lower()
            szfull = LANG2_SIZES.get(sz, "M")
            prod = LANG2_ITEMS[fn]
            if "brand" in meta and fn in ("nap", "pan", "tie"):
                sub = meta.get("sub", "")
                if sub and sub in meta.get("avoid", set()):
                    raise ValueError("no(%s) bola tha, phir %s li?" %
                                     (sub, sub))
                prod = ("%s %s %s" % (meta["brand"], sub, prod)).strip()
                meta.pop("brand", None)
                meta.pop("sub", None)
            items.append("%s %s" % (prod, szfull))
            continue
        if fn in LANG2_SUBS:
            meta["sub"] = LANG2_SUBS[fn]
            inner, meta, pos = _l2_parse(text, pos, depth + 1, meta)
            items.extend(inner)
            continue
        raise ValueError("anjaan code: " + fn)
    if depth > 0:
        raise ValueError(") missing hai")
    return items, meta, pos


def tool_lang2(app, args):
    T = app.term
    if not args or args[0] == "help":
        for ln in LANG2_HELP:
            T.push([(ln, C_SLATE if ln.startswith("╰") else
                     (C_FUCHSIA if ln.startswith("╭") else C_OUT))])
        return
    hist = _jload("buy.json", [])
    if args[0] == "copy":
        if not hist:
            T.dim("  abhi koi order nahi")
            return
        last = hist[-1]["items"]
        txt = "A Special Gift For You ✨\\n" + "\\n".join(
            "- " + it for it in last)
        if shutil.which("wl-copy"):
            subprocess.run(["wl-copy"], input=txt.encode(),
                           stdout=subprocess.DEVNULL, timeout=4)
            T.push([("  📋 copied! WhatsApp-ready", C_GOLD)])
        else:
            T.push([(txt, C_VALUE)])
        return
    if args[0] == "list":
        T.head("◆ ORDER HISTORY")
        if not hist:
            T.dim("  (khaali)")
            return
        for e2 in reversed(hist[-10:]):
            T.push([("  🛒 ", C_GOLD), (e2["d"], C_SLATE),
                    ("  [%s]" % e2.get("code", "")[:28], C_DIM)])
            for it in e2["items"]:
                T.push([("      • ", C_DIM), (it, C_VALUE)])
        return
    if args[0] == "total":
        cnt = sum(len(e2["items"]) for e2 in hist)
        T.push(_kv("ORDERS", str(len(hist))))
        T.push(_kv("ITEMS", str(cnt)))
        if hist:
            codes = sum(len(e2.get("code", "")) for e2 in hist)
            T.push(_kv("CODE CHARS", str(codes), "pure maths 😏"))
        return
    if args[0] == "export":
        if not hist:
            T.dim("  khaali")
            return
        lines = ["# discrete math homework", ""]
        for e2 in hist:
            lines.append("let o = [" + ", ".join(
                '"%s"' % it for it in e2["items"]) + "]")
        txt = "\\n".join(lines)
        if shutil.which("wl-copy"):
            subprocess.run(["wl-copy"], input=txt.encode(),
                           stdout=subprocess.DEVNULL, timeout=4)
            T.push([("  📋 homework-format exported", C_GOLD),
                    ("  — koi kuch nahi samjhega 😏", C_DIM)])
        else:
            T.push([(txt, C_VALUE)])
        return
    code = " ".join(args)
    try:
        items, meta, _p = _l2_parse(code, 0)
    except ValueError as e2:
        T.push([("  ✗ ", C_RED), (str(e2), C_VALUE)])
        T.dim("  help: lang2")
        return
    if not items:
        T.dim("  order khaali")
        return
    items = [str(x) for x in items]
    hist.append({"d": time.strftime("%Y-%m-%d %H:%M"), "items": items,
                 "code": code[:60]})
    _jsave("buy.json", hist[-30:])
    app.award("first_buy")
    if len(hist) >= 50:
        app.award("lang_master")
    if len(items) >= 5:
        app.award("combo_king")
    app.add_xp(4)
    T.push([("  ╭─", C_SLATE), (" 🛒 STEALTH ORDER ", C_FUCHSIA),
            ("─" * 24, C_SLATE)])
    for i2, it in enumerate(items, 1):
        T.push([("  │  %2d. " % i2, C_SLATE), (it, C_VALUE)])
    flags = []
    if meta.get("urgent"):
        flags.append(("🚨 URGENT", C_RED))
    if meta.get("delivery"):
        flags.append(("📦 " + meta["delivery"], C_DIM))
    if meta.get("budget"):
        flags.append(("💰 ≤" + str(meta["budget"]), C_GOLD))
    if meta.get("price"):
        flags.append(("🏷 " + meta["price"], C_DIM))
    if meta.get("gift"):
        flags.append(("🎁 For: " + ", ".join(meta["gift"]), C_FUCHSIA))
    if meta.get("avoid"):
        flags.append(("🚫 no " + ", ".join(meta["avoid"]), C_SLATE))
    if flags:
        T.push([("  │  ", C_DIM)] +
               [x2 for pair in [[f2, ("  ", C_DIM)] for f2 in flags]
                for x2 in pair])
    T.push([("  │  ", C_DIM), ("%d items" % len(items), C_VALUE),
            ("  •  code %d chars" % len(code), C_SLATE)])
    T.push([("  ╰", C_SLATE), ("─" * 44, C_SLATE), ("╯", C_SLATE)])
    momo = random.choice((
        "momo: poora homework lag raha hai 😼",
        "momo: queen of codes 💜",
        "momo: koi shak karne wala nahi bacha 🤭",
        "momo: ye toh thesis lag rahi hai 🎓",
    ))
    T.push([("  " + momo, C_PINK)])
    T.push([("  ", C_DIM), ("lang2 copy", C_GOLD), (" • ", C_DIM),
            ("lang2 export", C_GOLD), (" • ", C_DIM), ("lang2 total", C_GOLD)])


'''

block("def tool_music(app, args):", DATA, "lang2 tools")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v34")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v3.5.0 CODE LANG v2 patched ✓  (backup: %s.bak-v34)" % P)
