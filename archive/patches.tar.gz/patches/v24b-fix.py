import re, shutil, sys
P = "/home/cutie/cutie-os.py"
s = open(P, encoding="utf-8").read()
if "LANG_GATES" in s:
    print("already patched ✓"); sys.exit(0)
for ln in s.splitlines():
    if ln.startswith("VERSION") or ln.startswith("EDITION"):
        print("  abhi file me:", ln.strip())
fails = []

def rep(old, new, label):
    global s
    if old not in s:
        fails.append(label); print("  ✗", label); return
    s = s.replace(old, new, 1); print("  ✓", label)

def rx(pat, repl, label):
    global s
    s2, n = re.subn(pat, repl, s, count=1)
    if n == 0:
        fails.append(label); print("  ✗", label); return
    s = s2; print("  ✓", label)

rx(r'VERSION\s*=\s*"[^"]*"', 'VERSION      = "v24"', "version (regex)")
rx(r'EDITION\s*=\s*"[^"]*"', 'EDITION      = "GATE EDITION"', "edition (regex)")

rep('''def tool_ed(app, args):
    if not args:
        app.term.dim("  usage: ed file.py   (CUTIE editor — type karo, F1 se run)")
        return
    app.open_epage(" ".join(args))''',
    '''def tool_ed(app, args):
    if not args:
        app.term.dim("  usage: ed file.py   ya bas: python | c | html | sh | js")
        return
    app.open_epage(" ".join(args))


LANG_GATES = {
    "python": "untitled.py", "py": "untitled.py", "p": "untitled.py",
    "c": "untitled.c", "cpp": "untitled.cpp", "c++": "untitled.cpp",
    "html": "untitled.html", "css": "untitled.css",
    "sh": "untitled.sh", "bash": "untitled.sh", "shell": "untitled.sh",
    "js": "untitled.js", "node": "untitled.js", "j": "untitled.js",
    "json": "untitled.json", "md": "untitled.md",
    "rust": "untitled.rs", "r": "untitled.rs", "go": "untitled.go", "g": "untitled.go",
    "java": "untitled.java", "txt": "untitled.txt", "t": "untitled.txt",
}


def _gate_counter(base):
    n = 0
    root, ext = os.path.splitext(base)
    while True:
        cand = (root + ("" if n == 0 else str(n)) + ext)
        if not os.path.exists(os.path.join(os.path.expanduser("~"), cand)) and \\
                not os.path.exists(os.path.join(os.getcwd(), cand)):
            return cand
        n += 1


def _untitled_path(name):
    if os.path.isabs(name):
        return name
    desk = os.path.expanduser("~/Desktop")
    base_dir = desk if os.path.isdir(desk) else os.path.expanduser("~")
    return os.path.join(base_dir, name)''', "gates def")

rep('''        cmd, args = parts[0], parts[1:]
        if cmd in T.macros and cmd not in TOOL_MAP and cmd not in ("cd", "sudo"):''',
    '''        cmd, args = parts[0], parts[1:]
        gate = LANG_GATES.get(cmd.lower())
        if gate:
            if cmd.lower() == "c" and args:
                return self.route("ed " + " ".join(args))
            fname = _gate_counter(gate)
            self.open_epage(_untitled_path(fname))
            return
        if cmd in T.macros and cmd not in TOOL_MAP and cmd not in ("cd", "sudo"):''', "gate route")

rep('''        self.epage = {"path": p, "lines": lines, "cy": 0, "cx": 0,
                      "scroll": 0, "hscroll": 0, "dirty": False,
                      "confirm": False, "banner": True, "preview": True,
                      "check": None, "check_t": 0.0, "outline": [], "out_sel": 0,
                      "msg": "✎ CUTIE EDITOR — F1 run • CTRL+S save • CTRL+Q quit",
                      "msg_t": time.monotonic()}''',
    '''        fresh = not os.path.exists(p)
        self.epage = {"path": p, "lines": lines, "cy": 0, "cx": 0,
                      "scroll": 0, "hscroll": 0, "dirty": False,
                      "confirm": False, "banner": True, "preview": True,
                      "check": None, "check_t": 0.0, "outline": [], "out_sel": 0,
                      "fresh": fresh,
                      "msg": ("✿ naya file — likhna shuru! CTRL+T template • F1 run"
                              if fresh else
                              "✎ CUTIE EDITOR — F1 run • CTRL+S save • CTRL+Q quit"),
                      "msg_t": time.monotonic()}
        if fresh and not self.epage["lines"]:
            self.epage["lines"] = [""]''', "fresh flag")

rep('''        if kind == "CTRL_T":
            if lines == [""] and not ep["dirty"]:''',
    '''        if kind == "CTRL_T":
            if lines == [""] or (len(lines) <= 2 and not "".join(lines).strip()):''', "template easy")

rep('''        if kind in ("CTRL_S", "F2"):
            self._epage_save()
            return''', '''        if kind in ("CTRL_S", "F2"):
            base = os.path.basename(ep["path"])
            if base.startswith("untitled"):
                ep["mini"] = {"mode": "saveas", "text": base}
                ep["msg"] = "✎ naam do + ENTER (ya bas ENTER = same naam)"
                ep["msg_t"] = time.monotonic()
                return
            self._epage_save()
            return''', "save-as gate")

rep('''        mini = ep.get("mini")
        if mini:
            if kind in ("ESC", "CTRL_C"):
                ep["mini"] = None
            elif kind == "ENTER":
                q = mini["text"].strip()
                ep["mini"] = None
                if mini["mode"] == "goto":''', '''        mini = ep.get("mini")
        if mini:
            if kind in ("ESC", "CTRL_C"):
                ep["mini"] = None
            elif kind == "ENTER":
                q = mini["text"].strip()
                ep["mini"] = None
                if mini["mode"] == "saveas":
                    if not q:
                        q = os.path.basename(ep["path"])
                    if not os.path.splitext(q)[1]:
                        q += os.path.splitext(ep["path"])[1]
                    newp = q if os.path.isabs(q) else os.path.join(
                        os.path.dirname(ep["path"]), q)
                    if os.path.abspath(newp) != os.path.abspath(ep["path"]) and \\
                            os.path.exists(newp):
                        ep["mini"] = {"mode": "saveas", "text": q}
                        ep["msg"] = "✗ ye naam already hai — dusra do"
                        ep["msg_t"] = time.monotonic()
                        return
                    ep["path"] = newp
                    self._epage_save()
                    ep["fresh"] = False
                    return
                if mini["mode"] == "goto":''', "saveas handler")

rx(r'foot = "F1 run[^"]*"', 'foot = "F1 run • CTRL+S save (untitled ho to naam poochhega) • CTRL+D dup • CTRL+K cut • CTRL+F find • CTRL+G goto • CTRL+O jump • CTRL+E preview • CTRL+Q"', "foot hint (regex)")

try:
    compile(s, P, "exec")
except SyntaxError as e:
    print("✗ syntax error after patch — file NOT changed:", e)
    sys.exit(1)

if fails:
    print("✗ anchors failed — file NOT changed:", fails)
    sys.exit(1)

shutil.copy(P, P + ".bak-v22")
open(P, "w", encoding="utf-8").write(s)
print()
print("★ v24 GATE patched ✓  (backup: %s.bak-v22)" % P)
